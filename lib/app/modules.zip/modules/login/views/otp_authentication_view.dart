import 'dart:async';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:otp_text_field/style.dart';
import 'package:usoft/app/modules/login/controllers/login_controller.dart';
import 'package:usoft/app/modules/login/views/forgot_password_view.dart';
import 'package:usoft/app/widgets/custom_button.dart';
import 'package:usoft/app/widgets/custom_buttons.dart';

import '../../../constants/constants.dart';
import 'package:otp_text_field/otp_text_field.dart';

class OtpAuthenticationView extends StatefulWidget {
  String? email;

  OtpAuthenticationView({super.key, this.email});

  @override
  State<OtpAuthenticationView> createState() => _OtpAuthenticationViewState();
}

class _OtpAuthenticationViewState extends State<OtpAuthenticationView> {
  final controller = Get.put(LoginController());
  late Timer _timer;
  int remainingTime = 120;

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  void startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (remainingTime > 0) {
          remainingTime--;
        } else {
          _timer.cancel();
        }
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void sendOtp() {
    // Implement your logic to resend OTP here
    // This method will be triggered when the "Resend" text is tapped
  }

  String formatTime(int seconds) {
    int minutes = (seconds / 60).floor();
    int remainingSeconds = seconds % 60;
    String minutesStr = minutes.toString().padLeft(2, '0');
    String secondsStr = remainingSeconds.toString().padLeft(2, '0');
    return '$minutesStr:$secondsStr';
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          return await showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Exit'),
              content: Text('Do you want to exit?'),
              actions: [
                ElevatedButton(
                  child: Text('No'),
                  style: ElevatedButton.styleFrom(
                    primary:
                        AppColor.mainClr, // Set the button's background color
                  ),
                  onPressed: () {
                    Navigator.of(context)
                        .pop(false); // Return false to prevent exiting
                  },
                ),
                ElevatedButton(
                  child: Text('Yes'),
                  style: ElevatedButton.styleFrom(
                    primary:
                        AppColor.orange, // Set the button's background color
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(true); // Return true to exit
                  },
                ),
              ],
            ),
          );
        },
        child: Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 40,
                ),
                Center(
                  child: Image.asset(
                    AppImages.logo,
                    height: 100,
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Text(
                  'OTP Authentication',
                  style: headingStyle,
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  'An authentication code have been sent to  ${widget.email}',
                  style: subtitleStyle.copyWith(color: Colors.grey),
                ),
                const SizedBox(
                  height: 20,
                ),
                OTPTextField(
                  length: 5,
                  width: MediaQuery.of(context).size.width,
                  controller: controller.otpController,
                  fieldWidth: 40,
                  style: const TextStyle(fontSize: 17),
                  textFieldAlignment: MainAxisAlignment.spaceAround,
                  fieldStyle: FieldStyle.underline,
                  onCompleted: (pin) {
                    // ignore: avoid_print
                    print("Completed: $pin");
                    controller.getOtp(pin);
                  },
                  onChanged: (v) {},
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  children: [
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: 'Did not receive the code? ',
                            style: TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                    remainingTime == 0
                        ? GestureDetector(
                            onTap: () {
                              controller.sendOtp();
                            },
                            child: Text(
                              'Resend',
                              style: TextStyle(color: Colors.orange),
                            ),
                          )
                        : Text(
                            '$remainingTime seconds remaining',
                            // Display the remaining time
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w300,
                                color: AppColor.orange),
                          ),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                const SizedBox(
                  height: 20,
                ),
                SizedBox(
                  width: double.infinity,
                  child: CustomButtons(
                    label: 'Continue',
                    btnClr: AppColor.orange,
                    txtClr: Colors.white,
                    ontap: () {
                      controller.optloading.value
                          ? null
                          : controller
                              .getOtp(controller.otpController.toString());
                      // Get.to(() => const ResetPasswordView());
                    },
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
