import 'dart:developer';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/database/app_storage.dart';
import 'package:usoft/app/modules/login/views/forgot_password_view.dart';
import 'package:usoft/app/widgets/custom_button.dart';
import 'package:usoft/app/widgets/custom_buttons.dart';
import 'package:usoft/app/widgets/inputfield.dart';

import '../../../get_hash.dart';
import '../../../routes/app_pages.dart';
import '../../../utils/validators.dart';
import '../../home/views/home_view.dart';
import '../controllers/login_controller.dart';

class LoginView extends GetView<LoginController> {
  LoginView({Key? key}) : super(key: key);
  final _formKey = GlobalKey<FormState>();
  final _formKeyDialog = GlobalKey<FormState>();

  @override
  final controller = Get.put(LoginController());
  TextEditingController _facebookEmail = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 40,
                ),
                Center(
                  child: Image.asset(
                    AppImages.logo,
                    height: 100,
                  ),
                ),
                Text(
                  'Welcome to Jhigu Store',
                  style: headingStyle,
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  'Please enter the credentials below to start using the app.',
                  style: subtitleStyle,
                ),
                const SizedBox(
                  height: 40,
                ),
                MyInputField(
                  hint: 'Email',
                  controller: controller.email,
                  validator: (v) => validateEmail(string: v),
                ),
                const SizedBox(
                  height: 20,
                ),
                Obx(
                  () => MyInputField(
                    hint: 'Password',
                    controller: controller.password,
                    suffix: IconButton(
                        onPressed: () {
                          controller.viewPassword.value =
                              !controller.viewPassword.value;
                        },
                        icon: Icon(
                          controller.viewPassword.value
                              ? Icons.visibility_off
                              : Icons.visibility,
                          size: 20.sp,
                          color: AppColor.orange,
                        )),
                    obscuretext: controller.viewPassword.value,
                    validator: (v) => validatePassword(string: v),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      child: Text('Forgot password?',
                          style:
                              subtitleStyle.copyWith(color: AppColor.orange)),
                      onPressed: () {
                        Get.to(() => ForgotPasswordView());
                      },
                    ),
                    Expanded(
                      child: Obx(
                        () => CheckboxListTile(
                          value: controller.rememberMe.value,
                          onChanged: (value) {
                            print("value is $value");
                            controller.rememberMe.value =
                                !controller.rememberMe.value;
                            AppStorage.saveRememberme(value);
                            log(AppStorage.readRememberme.toString());
                          },
                          contentPadding: EdgeInsets.zero,
                          title: Text(
                            'Remember me',
                            style: subtitleStyle,
                            textAlign: TextAlign.right,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                SizedBox(
                  height: 50,
                  width: double.infinity,
                  child: CustomButtons(
                    label: 'Sign in ',
                    txtClr: Colors.white,
                    btnClr: AppColor.orange,
                    ontap: () {
                      if (_formKey.currentState!.validate()) {
                        controller.loginLoading.value
                            ? null
                            : controller.login();
                        controller.rememberMeData();
                      }
                    },
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),

                Center(
                  child: RichText(
                    text: TextSpan(
                        text: 'Not a member yet?',
                        style: subtitleStyle,
                        children: <TextSpan>[
                          TextSpan(
                              text: 'Join now',
                              style: subtitleStyle.copyWith(
                                  color: AppColor.orange),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () => Get.toNamed(Routes.REGISTER))
                        ]),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Text(
                    ' Or signup in with',
                    style: subtitleStyle,
                    textAlign: TextAlign.end,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildButton(
                      const Icon(
                        Icons.facebook,
                        color: Colors.white,
                      ),
                      'Facebook',
                      Colors.blue.shade900,
                      Colors.white,
                      () {
                        controller.facebookLogin().then((value) {
                          if (value["msg"]["email"].contains(
                              "The email must be a valid email address.")) {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return Form(
                                  key: _formKeyDialog,
                                  child: AlertDialog(
                                    title: const Text(
                                      'Email not found in your facebook account..Enter your email and try again',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w300,
                                          fontSize: 12),
                                    ),
                                    content: TextFormField(
                                      validator: (v) =>
                                          validateEmail(string: v),
                                      controller: _facebookEmail,
                                      decoration: const InputDecoration(
                                          hintText: 'Enter your email'),
                                    ),
                                    actions: <Widget>[
                                      TextButton(
                                        child: const Text('Cancel'),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                      ),
                                      TextButton(
                                        child: const Text('OK'),
                                        onPressed: () {
                                          if (_formKeyDialog.currentState!
                                              .validate()) {
                                            controller
                                                .facebookLoginWithTextField(
                                                    email: _facebookEmail.text);
                                            Navigator.of(context).pop();
                                          }
                                        },
                                      ),
                                    ],
                                  ),
                                );
                              },
                            );
                          } else {
                            // The string is not present
                            print("String is not present");
                          }
                        });
                      },
                    ),
                    _buildButton(
                      Image.asset(
                        'assets/images/google.png',
                        height: 20,
                      ),
                      'Google',
                      Colors.white,
                      Colors.black,
                      () {
                        controller.googleLogin();
                      },
                    ),
                  ],
                ),
                SizedBox(height: 10),
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.end,
                //   children: [
                //     GestureDetector(
                //       onTap: () {
                //         Get.offAll(() => const HomeView());
                //       },
                //       child: Container(
                //         width: 170,
                //         color: AppColor.mainClr,
                //         child: Row(
                //           mainAxisAlignment: MainAxisAlignment.end,
                //           children: [
                //             const Text(
                //               "Go to Dashboard",
                //               style: TextStyle(color: Colors.white),
                //             ),
                //             IconButton(
                //                 onPressed: () {},
                //                 icon: Icon(
                //                   Icons.dashboard,
                //                   color: Colors.white,
                //                 )),
                //           ],
                //         ),
                //       ),
                //     ),
                //   ],
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _buildButton(icon, label, btnClr, txtClr, ontap) {
    return SizedBox(
      height: 50,
      width: 40.w,
      child: MaterialButton(
        onPressed: ontap,
        elevation: 5,
        color: btnClr,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            icon,
            const SizedBox(
              width: 10,
            ),
            Text(
              label,
              style: titleStyle.copyWith(color: txtClr),
            ),
          ],
        ),
      ),
    );
  }
}
