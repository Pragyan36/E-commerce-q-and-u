import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/modules/login/controllers/login_controller.dart';
import 'package:usoft/app/utils/validators.dart';
import 'package:usoft/app/widgets/custom_button.dart';
import 'package:usoft/app/widgets/inputfield.dart';

import '../../../constants/constants.dart';

class ResetPasswordView extends StatelessWidget {
  ResetPasswordView({Key? key}) : super(key: key);

  final controller = Get.put(LoginController());
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          return await showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Exit'),
              content: Text('Do you want to exit?'),
              actions: [
                ElevatedButton(
                  child: Text('No'),
                  style: ElevatedButton.styleFrom(
                    primary:
                        AppColor.mainClr, // Set the button's background color
                  ),
                  onPressed: () {
                    Navigator.of(context)
                        .pop(false); // Return false to prevent exiting
                  },
                ),
                ElevatedButton(
                  child: Text('Yes'),
                  style: ElevatedButton.styleFrom(
                    primary:
                        AppColor.orange, // Set the button's background color
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(true); // Return true to exit
                  },
                ),
              ],
            ),
          );
        },
        child: Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 40,
                    ),
                    Center(
                      child: Image.asset(AppImages.logo),
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    Text(
                      'Reset Password',
                      style: headingStyle,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      'Password should contain atleast 6 characters',
                      style: subtitleStyle.copyWith(color: Colors.grey),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Obx(
                      () => MyInputField(
                        hint: 'New Password',
                        controller: controller.newpassword,
                        suffix: IconButton(
                            onPressed: () {
                              controller.viewPassword.value =
                                  !controller.viewPassword.value;
                            },
                            icon: Icon(
                              controller.viewPassword.value
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                              size: 20.sp,
                              color: AppColor.orange,
                            )),
                        obscuretext: controller.viewPassword.value,
                        validator: (v) => validatePassword(string: v),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Obx(
                      () => MyInputField(
                        hint: 'Confirm Password',
                        controller: controller.confirmpassword,
                        suffix: IconButton(
                            onPressed: () {
                              controller.viewPassword1.value =
                                  !controller.viewPassword1.value;
                            },
                            icon: Icon(
                              controller.viewPassword1.value
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                              size: 20.sp,
                              color: AppColor.orange,
                            )),
                        obscuretext: controller.viewPassword1.value,
                        validator: (v) => confirmPassword(
                            password: controller.newpassword.text,
                            cPassword: v),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: CustomButton(
                        label: 'Reset Password',
                        btnClr: AppColor.orange,
                        txtClr: Colors.white,
                        ontap: () {
                          if (_formKey.currentState!.validate()) {
                            controller.resetPassword();
                          }
                        },
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ));
  }
}
