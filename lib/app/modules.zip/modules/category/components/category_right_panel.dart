import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/data/models/parent_category_model.dart';
import 'package:usoft/app/modules/category/components/category_detail.dart';
import 'package:usoft/app/modules/category/components/category_details_sub_total.dart';
import 'package:usoft/app/modules/category/controllers/category_controller.dart';

import '../../../data/models/child_category_model.dart';

class CategoryRightPanel extends StatefulWidget {
  const CategoryRightPanel({Key? key, this.data}) : super(key: key);

  final Subcat? data;

  @override
  State<CategoryRightPanel> createState() => _CategoryRightPanelState();
}

class _CategoryRightPanelState extends State<CategoryRightPanel> {
  final controller = Get.put(CategoryController());

  // late List<bool> _isOpen;

  @override
  void initState() {
    controller.selectedindex.value = 0;
    super.initState();
  }

  @override
  void dispose() {
    // controller.selectedindex.value = 0;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // print(controller.parentcategoryList[controller.selectedindex.value].title
    //     .toString());
    return Container(
      width: 75.w,
      height: 70.h,
      color: Colors.white,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          children: [
            Obx(
              () => controller
                          .parentcategoryList[controller.selectedindex.value]
                          .subcat ==
                      null
                  ? Text(
                      'No data',
                      style: titleStyle,
                    )
                  : ExpansionPanelList(
                      animationDuration: const Duration(milliseconds: 400),
                      elevation: 1,
                      expandedHeaderPadding: EdgeInsets.zero,
                      children: controller
                          .parentcategoryList[controller.selectedindex.value]
                          .subcat!
                          .asMap()
                          .entries
                          .map<ExpansionPanel>((entry) {
                        final index = entry.key;
                        final element = entry.value;
                        return ExpansionPanel(
                          headerBuilder:
                              (BuildContext context, bool isExpanded) {
                            return ListTile(
                              title: Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Text(
                                  element.title.toString(),
                                  style: subtitleStyle,
                                ),
                              ),
                              trailing: VerticalDivider(
                                color: Colors.black45,
                                width: 10,
                                thickness: 0.5,
                                indent: 10,
                                endIndent:
                                    10, //Spacing at the bottom of divider.
                              ),
                              onTap: () {
                                Get.to(SecondCategory(
                                  title: element.title,
                                  slug: element.slug,
                                ));
                              },
                            );
                          },
                          body: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 400),
                            child: controller.selectedExpand.value == index
                                ? CustomGrid(
                                    data: controller.childcategoryList,
                                  )
                                : Container(),
                          ),
                          canTapOnHeader: false,
                          isExpanded: controller.selectedExpand.value == index,
                        );
                      }).toList(),
                      expansionCallback: (int index, bool isExpanded) async {
                        final element = controller
                            .parentcategoryList[controller.selectedindex.value]
                            .subcat![index];
                        await controller.fetchChildCategory(element.slug);
                        await controller.fetchChildCategory(element.slug);
                        if (controller.childcategoryList.isNotEmpty) {
                          print(controller.childcategoryList.first.title);
                        }
                        setState(() {
                          controller.selectedExpand.value = index;
                        });
                      }),
            ),
          ],
        ),
      ),
    );
    //  Expanded(
    //     flex: 3,
    //     child: Container(
    //         height: (100 - 20).h, color: Colors.red, child: Text('data')

    //         )

    //     // SizedBox(
    //     //   height: 100.sp,
    //     //   child:
    //     //   Obx(() => ListView.builder(
    //     //       shrinkWrap: true,
    //     //       itemCount: controller
    //     //           .parentcategoryList[controller.selectedindex.value]
    //     //           .subcat!
    //     //           .length,
    //     //       itemBuilder: (context, index) {
    //     //         return CustomExpansionTile(
    //     //           title: controller
    //     //               .parentcategoryList[controller.selectedindex.value]
    //     //               .subcat![index]
    //     //               .title
    //     //               .toString(),
    //     //           slug: controller
    //     //               .parentcategoryList[controller.selectedindex.value]
    //     //               .subcat![index]
    //     //               .slug
    //     //               .toString(),
    //     //         );
    //     //       })),
    //     // ),

    //     );
  }
}

// class CustomExpansionTile extends StatefulWidget {
//   const CustomExpansionTile({Key? key, required this.title, required this.slug})
//       : super(key: key);

//   final String title;
//   final String slug;

//   @override
//   State<CustomExpansionTile> createState() => _CustomExpansionTileState();
// }

// class _CustomExpansionTileState extends State<CustomExpansionTile> {
//   final controller = Get.put(CategoryController());

//   @override
//   void initState() {
//     controller.fetchChildCategory(widget.slug);
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     print(controller.childcategoryList);
//     return ExpansionTile(
//       title: Text(
//         widget.title,
//         style: subtitleStyle,
//       ),
//       onExpansionChanged: null,

//       // (val) {
//       //   if (val == true) {
//       //     controller.fetchChildCategory(widget.slug);
//       //   }
//       // },
//       children: [
//         Obx(
//           () => controller.childcategoryList.first.products!.isEmpty
//               ? Text('no data')
//               : controller.loading.isTrue
//                   ? const SizedBox(
//                       height: 60,
//                       child: Center(child: CircularProgressIndicator()))
//                   : GridView.builder(
//                       shrinkWrap: true,
//                       gridDelegate:
//                           const SliverGridDelegateWithFixedCrossAxisCount(
//                               crossAxisCount: 3,
//                               childAspectRatio: 0.8,
//                               crossAxisSpacing: 15,
//                               mainAxisSpacing: 15),
//                       itemCount: controller.childcategoryList.length,
//                       itemBuilder: (context, index) {
//                         return Column(
//                           children: [
//                             GestureDetector(
//                                 onTap: () {
//                                   // print(controller.childcategoryList1.length);
//                                   // controller.categoryTap(true);
//                                   Get.to(() => CategoryDetail(
//                                         data:
//                                             controller.childcategoryList[index],
//                                       ));
//                                 },
//                                 child: CircleAvatar(
//                                     radius: 30,
//                                     backgroundImage: CachedNetworkImageProvider(
//                                         '${controller.childcategoryList[index].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}')
//                                     //     NetworkImage(
//                                     //   'https://assets.adidas.com/images/w_600,f_auto,q_auto/ce8a6f3aa6294de988d7abce00c4e459_9366/Breaknet_Shoes_White_FX8707_01_standard.jpg',
//                                     // ),
//                                     )),
//                             Text(
//                               controller.childcategoryList[index].title
//                                   .toString(),
//                               style: subtitleStyle,
//                               overflow: TextOverflow.ellipsis,
//                               maxLines: 2,
//                             )
//                           ],
//                         );
//                       },
//                     ),
//         )
//       ],
//     );
//   }
// }

class CustomGrid extends StatefulWidget {
  const CustomGrid({super.key, required this.data});

  final List<Category> data;

  @override
  State<CustomGrid> createState() => _CustomGridState();
}

class _CustomGridState extends State<CustomGrid> {
  final controller = Get.put(CategoryController());
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const BouncingScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 0.8,
          crossAxisSpacing: 15,
          mainAxisSpacing: 15),
      itemCount: widget.data.length,
      // controller.childcategoryList.length,
      itemBuilder: (context, index) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            GestureDetector(
                onTap: () {
                  // print(controller.childcategoryList1.length);
                  // controller.categoryTap(true);
                  controller.selectedSortingItem.value = "1";

                  Get.to(() => CategoryDetail(
                        data: widget.data[index],
                      ));
                },
                child: CircleAvatar(
                    radius: 30,
                    backgroundImage: CachedNetworkImageProvider(
                        '${widget.data[index].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}')
                    //     NetworkImage(
                    //   'https://assets.adidas.com/images/w_600,f_auto,q_auto/ce8a6f3aa6294de988d7abce00c4e459_9366/Breaknet_Shoes_White_FX8707_01_standard.jpg',
                    // ),
                    )),
            const SizedBox(
              height: 10,
            ),
            Text(
              // 'data',
              widget.data[index].title.toString(),
              textAlign: TextAlign.center,
              style: subtitleStyle,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            )
          ],
        );
      },
    );
  }
}
