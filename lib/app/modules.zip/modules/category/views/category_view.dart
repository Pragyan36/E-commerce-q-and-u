import 'dart:developer';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/modules/category/components/category_right_panel.dart';
import 'package:usoft/app/modules/home/controllers/home_controller.dart';
import 'package:usoft/app/widgets/custom_shimmer.dart';
import 'package:usoft/app/widgets/loading_widget.dart';
import 'package:usoft/app/widgets/searchbar.dart';

import '../../../widgets/no_internet.dart';
import '../controllers/category_controller.dart';

class CategoryView extends StatefulWidget {
  const CategoryView({Key? key}) : super(key: key);

  @override
  State<CategoryView> createState() => _CategoryViewState();
}

class _CategoryViewState extends State<CategoryView> {
  final controller = Get.put(CategoryController());

  final homecon = Get.put(HomeController());
  var hasInternet = false.obs;

  @override
  void dispose() {
    controller.selected.value = controller.parentcategoryList[0].id!.toInt();
    print('dispose used');

    super.dispose();
  }

  void checkInternet() async {
    log("LandingView:checkInternet");
    if (await Connectivity().checkConnectivity() == ConnectivityResult.none) {
      hasInternet.value = false;
    } else {
      hasInternet.value = true;
    }
  }

  @override
  void initState() {
    checkInternet();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: Obx(() => hasInternet.value
          ? SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  _buildCategoryTop(),
                  const SizedBox(
                    height: 10,
                  ),
                  Obx(
                    () => controller.parentLoading.isTrue
                        ? ListView.builder(
                            itemCount: 5,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              return CustomShimmer(
                                baseColor: Colors.grey.shade300,
                                highlightColor: Colors.grey.shade100,
                                widget: Container(
                                  margin: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 10),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                  ),
                                  height: 100,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    color: Colors.grey,
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                ),
                              );
                            })
                        : SingleChildScrollView(
                            physics: const AlwaysScrollableScrollPhysics(
                                parent: BouncingScrollPhysics()),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildCategorySideLeft(),
                                // Expanded(
                                //     flex: 3,
                                //     child: Container(
                                //       color: Colors.red,
                                //     ))
                                CategoryRightPanel()
                                // _buildCategorySideRight()
                              ],
                            ),
                          ),
                  )
                  // Obx(() => controller.categoryTap.isFalse
                  //     ? Container()
                  //     : Padding(
                  //         padding:
                  //             const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  //         child: Row(
                  //           mainAxisSize: MainAxisSize.min,
                  //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //           children: [
                  //             Text(
                  //               '22 Results',
                  //               style: titleStyle,
                  //             ),
                  //             const Spacer(),
                  //             Row(
                  //               mainAxisSize: MainAxisSize.min,
                  //               children: [
                  //                 Obx(
                  //                   () => _buildbutton(
                  //                       icon: controller.isListview.value
                  //                           ? Icons.list
                  //                           : Icons.grid_view_outlined,
                  //                       title: 'View',
                  //                       ontap: () {
                  //                         _buildCategoryFilter();
                  //                       }),
                  //                 ),
                  //                 const SizedBox(
                  //                   width: 10,
                  //                 ),
                  //                 _buildbutton(
                  //                     icon: Icons.sort,
                  //                     title: 'Sort',
                  //                     ontap: () {
                  //                       _buildSortBottomSheet();
                  //                     }),
                  //                 const SizedBox(
                  //                   width: 10,
                  //                 ),
                  //                 _buildbutton(
                  //                     icon: Icons.filter_list,
                  //                     title: 'Filter',
                  //                     ontap: () {
                  //                       _buildFilterBottomSheet();
                  //                     }),
                  //               ],
                  //             )
                  //           ],
                  //         ),
                  //       )),
                  // Obx(() => controller.categoryTap.isFalse
                  //     ? Row(
                  //         mainAxisAlignment: MainAxisAlignment.start,
                  //         crossAxisAlignment: CrossAxisAlignment.start,
                  //         children: [
                  //           _buildCategorySideLeft(),
                  //           // Expanded(
                  //           //     flex: 3,
                  //           //     child: Container(
                  //           //       color: Colors.red,
                  //           //     ))
                  //           CategoryRightPanel()
                  //           // _buildCategorySideRight()
                  //         ],
                  //       )
                  //     : _buildCategoryDetails()),
                ],
              ),
            )
          : const NoInternetLayout()),
    ));
  }

  _buildCategoryTop() {
    return SizedBox(
      width:
          //  controller.categoryTap.isTrue ? 80.w :
          95.w,
      child: const CustomSearchBar(),
    );
    //  Obx(
    //   () => Row(
    //     mainAxisAlignment: MainAxisAlignment.center,
    //     children: [
    //       controller.categoryTap.isTrue
    //           ? IconButton(
    //               onPressed: () {
    //                 controller.categoryTap(false);
    //               },
    //               padding: const EdgeInsets.only(right: 20),
    //               icon: const Icon(
    //                 Icons.arrow_back_ios_rounded,
    //                 size: 20,
    //               ))
    //           : Container(),
    //       SizedBox(
    //         width: controller.categoryTap.isTrue ? 80.w : 95.w,
    //         child: const CustomSearchBar(),
    //       ),
    //     ],
    //   ),
    // );
  }

  _buildCategorySideLeft() {
    return Obx(
      () => SingleChildScrollView(
        child: Container(
          color: Colors.blue,
          width: 25.w,
          child: ListView.builder(
            primary: false,
            itemCount: controller.parentcategoryList.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return SizedBox(
                width: double.infinity,
                child: Obx(
                  () => MaterialButton(
                    onPressed: () async {
                      await controller.fetchChildCategory(
                          controller.parentcategoryList[index].slug);
                      controller.selected.value =
                          controller.parentcategoryList[index].id!.toInt();
                      controller.selectedindex.value = index.toInt();

                      print(controller.selectedindex.value);
                      // controller.fetchChildCategory(
                      //     controller.parentcategoryList[index].slug);
                    },
                    elevation: 0,
                    color: controller.selected.value ==
                            controller.parentcategoryList[index].id!.toInt()
                        ? Colors.white
                        : Colors.grey.shade200,
                    height: 50,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0)),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        controller.parentcategoryList[index].title.toString(),
                        style: subtitleStyle,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
