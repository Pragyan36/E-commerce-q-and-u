class OrderDetailFromNotification {
  bool? error;
  NotificaitonOrderDetailsData? data;
  String? msg;

  OrderDetailFromNotification({this.error, this.data, this.msg});

  OrderDetailFromNotification.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    data = json['data'] != null
        ? new NotificaitonOrderDetailsData.fromJson(json['data'])
        : null;
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['error'] = this.error;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['msg'] = this.msg;
    return data;
  }
}

class NotificaitonOrderDetailsData {
  int? id;
  int? userId;
  int? shippingCharge;
  int? totalQuantity;
  int? totalPrice;
  String? refId;
  int? totalDiscount;
  String? couponName;
  String? couponDiscountPrice;
  String? couponCode;
  int? pending;
  int? readyToShip;
  int? paymentStatus;
  int? deletedByCustomer;
  int? failedDelivery;
  String? merchantName;
  String? paymentWith;
  String? transactionRefId;
  String? paymentDate;
  String? mobile;
  int? approved;
  String? name;
  String? email;
  String? phone;
  String? province;
  String? district;
  String? area;
  String? additionalAddress;
  String? zip;
  String? bName;
  String? bEmail;
  String? bPhone;
  String? bProvince;
  String? bDistrict;
  String? bArea;
  String? bAdditionalAddress;
  String? bZip;
  String? status;
  int? isNew;
  String? createdAt;
  String? updatedAt;
  int? vatAmount;
  bool? cancelReasonStatus;
  bool? refundStatus;
  bool? refundStatusValue;
  bool? refundRejectReason;
  String? statusValue;
  bool? cancelStatus;
  List<OrderAssets>? orderAssets;

  NotificaitonOrderDetailsData({
    this.id,
    this.userId,
    this.shippingCharge,
    this.totalQuantity,
    this.totalPrice,
    this.refId,
    this.totalDiscount,
    this.couponName,
    this.couponDiscountPrice,
    this.couponCode,
    this.pending,
    this.readyToShip,
    this.paymentStatus,
    this.deletedByCustomer,
    this.failedDelivery,
    this.merchantName,
    this.paymentWith,
    this.transactionRefId,
    this.paymentDate,
    this.mobile,
    this.approved,
    this.name,
    this.email,
    this.phone,
    this.province,
    this.district,
    this.area,
    this.additionalAddress,
    this.zip,
    this.bName,
    this.bEmail,
    this.bPhone,
    this.bProvince,
    this.bDistrict,
    this.bArea,
    this.bAdditionalAddress,
    this.bZip,
    this.status,
    this.isNew,
    this.createdAt,
    this.updatedAt,
    this.vatAmount,
    this.cancelReasonStatus,
    this.refundStatus,
    this.refundStatusValue,
    this.refundRejectReason,
    this.statusValue,
    this.cancelStatus,
    this.orderAssets,
  });

  NotificaitonOrderDetailsData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    shippingCharge = json['shipping_charge'];
    totalQuantity = json['total_quantity'];
    totalPrice = json['total_price'];
    refId = json['ref_id'];
    totalDiscount = json['total_discount'];
    couponName = json['coupon_name'];
    couponDiscountPrice = json['coupon_discount_price'];
    couponCode = json['coupon_code'];
    pending = json['pending'];
    readyToShip = json['ready_to_ship'];
    paymentStatus = json['payment_status'];
    deletedByCustomer = json['deleted_by_customer'];
    failedDelivery = json['failed_delivery'];
    merchantName = json['merchant_name'];
    paymentWith = json['payment_with'];
    transactionRefId = json['transaction_ref_id'];
    paymentDate = json['payment_date'];
    mobile = json['mobile'];
    approved = json['approved'];
    name = json['name'];
    email = json['email'];
    phone = json['phone'];
    province = json['province'];
    district = json['district'];
    area = json['area'];
    additionalAddress = json['additional_address'];
    zip = json['zip'];
    bName = json['b_name'];
    bEmail = json['b_email'];
    bPhone = json['b_phone'];
    bProvince = json['b_province'];
    bDistrict = json['b_district'];
    bArea = json['b_area'];
    bAdditionalAddress = json['b_additional_address'];
    bZip = json['b_zip'];
    status = json['status'];
    isNew = json['is_new'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    vatAmount = json['vat_amount'];
    cancelReasonStatus = json['cancelReasonStatus'];
    refundStatus = json['refundStatus'];
    refundStatusValue = json['refundStatusValue'];
    refundRejectReason = json['refundRejectReason'];
    statusValue = json['status_value'];
    cancelStatus = json['cancelStatus'];
    if (json['order_assets'] != null) {
      orderAssets = <OrderAssets>[];
      json['order_assets'].forEach((v) {
        orderAssets!.add(new OrderAssets.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['shipping_charge'] = this.shippingCharge;
    data['total_quantity'] = this.totalQuantity;
    data['total_price'] = this.totalPrice;
    data['ref_id'] = this.refId;
    data['total_discount'] = this.totalDiscount;
    data['coupon_name'] = this.couponName;
    data['coupon_discount_price'] = this.couponDiscountPrice;
    data['coupon_code'] = this.couponCode;
    data['pending'] = this.pending;
    data['ready_to_ship'] = this.readyToShip;
    data['payment_status'] = this.paymentStatus;
    data['deleted_by_customer'] = this.deletedByCustomer;
    data['failed_delivery'] = this.failedDelivery;
    data['merchant_name'] = this.merchantName;
    data['payment_with'] = this.paymentWith;
    data['transaction_ref_id'] = this.transactionRefId;
    data['payment_date'] = this.paymentDate;
    data['mobile'] = this.mobile;
    data['approved'] = this.approved;
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['province'] = this.province;
    data['district'] = this.district;
    data['area'] = this.area;
    data['additional_address'] = this.additionalAddress;
    data['zip'] = this.zip;
    data['b_name'] = this.bName;
    data['b_email'] = this.bEmail;
    data['b_phone'] = this.bPhone;
    data['b_province'] = this.bProvince;
    data['b_district'] = this.bDistrict;
    data['b_area'] = this.bArea;
    data['b_additional_address'] = this.bAdditionalAddress;
    data['b_zip'] = this.bZip;
    data['status'] = this.status;
    data['is_new'] = this.isNew;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['vat_amount'] = this.vatAmount;
    data['cancelReasonStatus'] = this.cancelReasonStatus;
    data['refundStatus'] = this.refundStatus;
    data['refundStatusValue'] = this.refundStatusValue;
    data['refundRejectReason'] = this.refundRejectReason;
    data['status_value'] = this.statusValue;
    data['cancelStatus'] = this.cancelStatus;
    if (this.orderAssets != null) {
      data['order_assets'] = this.orderAssets!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class OrderAssets {
  int? id;
  int? orderId;
  int? productId;
  String? productName;
  int? price;
  int? qty;
  int? subTotalPrice;
  String? color;
  String? image;
  int? discount;
  String? createdAt;
  String? updatedAt;
  String? cancelStatus;
  int? vatamountfield;
  Product? product;

  OrderAssets(
      {this.id,
      this.orderId,
      this.productId,
      this.productName,
      this.price,
      this.qty,
      this.subTotalPrice,
      this.color,
      this.image,
      this.discount,
      this.createdAt,
      this.updatedAt,
      this.cancelStatus,
      this.vatamountfield,
      this.product});

  OrderAssets.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderId = json['order_id'];
    productId = json['product_id'];
    productName = json['product_name'];
    price = json['price'];
    qty = json['qty'];
    subTotalPrice = json['sub_total_price'];
    color = json['color'];
    image = json['image'];
    discount = json['discount'];

    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    cancelStatus = json['cancel_status'];
    vatamountfield = json['vatamountfield'];
    product =
        json['product'] != null ? new Product.fromJson(json['product']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['order_id'] = this.orderId;
    data['product_id'] = this.productId;
    data['product_name'] = this.productName;
    data['price'] = this.price;
    data['qty'] = this.qty;
    data['sub_total_price'] = this.subTotalPrice;
    data['color'] = this.color;
    data['image'] = this.image;
    data['discount'] = this.discount;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['cancel_status'] = this.cancelStatus;
    data['vatamountfield'] = this.vatamountfield;
    if (this.product != null) {
      data['product'] = this.product!.toJson();
    }
    return data;
  }
}

class Product {
  int? id;
  String? name;
  String? slug;
  int? vatPercent;
  String? shortDescription;
  String? longDescription;
  String? minOrder;
  String? returnableTime;
  String? returnPolicy;
  String? deliveryTime;
  String? keyword;
  String? packageWeight;
  String? dimensionLength;
  String? dimensionWidth;
  String? dimensionHeight;
  String? warrantyType;
  String? warrantyPeriod;
  String? warrantyPolicy;
  int? brandId;
  int? countryId;
  int? categoryId;
  int? userId;
  String? rating;
  bool? publishStatus;
  int? isNew;
  String? status;
  String? url;
  String? createdAt;
  String? updatedAt;
  int? sellerId;
  int? totalSell;
  String? metaTitle;
  String? metaKeywords;
  String? metaDescription;
  String? ogImage;
  String? deletedAt;
  int? policyData;
  List<Images>? images;

  Product(
      {this.id,
      this.name,
      this.slug,
      this.vatPercent,
      this.shortDescription,
      this.longDescription,
      this.minOrder,
      this.returnableTime,
      this.returnPolicy,
      this.deliveryTime,
      this.keyword,
      this.packageWeight,
      this.dimensionLength,
      this.dimensionWidth,
      this.dimensionHeight,
      this.warrantyType,
      this.warrantyPeriod,
      this.warrantyPolicy,
      this.brandId,
      this.countryId,
      this.categoryId,
      this.userId,
      this.rating,
      this.publishStatus,
      this.isNew,
      this.status,
      this.url,
      this.createdAt,
      this.updatedAt,
      this.sellerId,
      this.totalSell,
      this.metaTitle,
      this.metaKeywords,
      this.metaDescription,
      this.ogImage,
      this.deletedAt,
      this.policyData,
      this.images});

  Product.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    slug = json['slug'];
    vatPercent = json['vat_percent'];
    shortDescription = json['short_description'];
    longDescription = json['long_description'];
    minOrder = json['min_order'];
    returnableTime = json['returnable_time'];
    returnPolicy = json['return_policy'];
    deliveryTime = json['delivery_time'];
    keyword = json['keyword'];
    dimensionLength = json['dimension_length'];
    dimensionWidth = json['dimension_width'];
    dimensionHeight = json['dimension_height'];
    warrantyType = json['warranty_type'];
    warrantyPeriod = json['warranty_period'];
    warrantyPolicy = json['warranty_policy'];
    brandId = json['brand_id'];
    countryId = json['country_id'];
    categoryId = json['category_id'];
    userId = json['user_id'];
    rating = json['rating'];
    publishStatus = json['publishStatus'];
    isNew = json['is_new'];
    status = json['status'];
    url = json['url'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    sellerId = json['seller_id'];
    totalSell = json['total_sell'];
    metaTitle = json['meta_title'];
    metaKeywords = json['meta_keywords'];
    metaDescription = json['meta_description'];
    ogImage = json['og_image'];
    deletedAt = json['deleted_at'];
    policyData = json['policy_data'];
    if (json['images'] != null) {
      images = <Images>[];
      json['images'].forEach((v) {
        images!.add(new Images.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['slug'] = this.slug;
    data['vat_percent'] = this.vatPercent;
    data['short_description'] = this.shortDescription;
    data['long_description'] = this.longDescription;
    data['min_order'] = this.minOrder;
    data['returnable_time'] = this.returnableTime;
    data['return_policy'] = this.returnPolicy;
    data['delivery_time'] = this.deliveryTime;
    data['keyword'] = this.keyword;
    data['package_weight'] = this.packageWeight;
    data['dimension_length'] = this.dimensionLength;
    data['dimension_width'] = this.dimensionWidth;
    data['dimension_height'] = this.dimensionHeight;
    data['warranty_type'] = this.warrantyType;
    data['warranty_period'] = this.warrantyPeriod;
    data['warranty_policy'] = this.warrantyPolicy;
    data['brand_id'] = this.brandId;
    data['country_id'] = this.countryId;
    data['category_id'] = this.categoryId;
    data['user_id'] = this.userId;
    data['rating'] = this.rating;
    data['publishStatus'] = this.publishStatus;
    data['is_new'] = this.isNew;
    data['status'] = this.status;
    data['url'] = this.url;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['seller_id'] = this.sellerId;
    data['total_sell'] = this.totalSell;
    data['meta_title'] = this.metaTitle;
    data['meta_keywords'] = this.metaKeywords;
    data['meta_description'] = this.metaDescription;
    data['og_image'] = this.ogImage;
    data['deleted_at'] = this.deletedAt;
    data['policy_data'] = this.policyData;
    if (this.images != null) {
      data['images'] = this.images!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Images {
  int? id;
  String? image;
  int? colorId;
  int? productId;
  int? isFeatured;
  String? createdAt;
  String? updatedAt;

  Images(
      {this.id,
      this.image,
      this.colorId,
      this.productId,
      this.isFeatured,
      this.createdAt,
      this.updatedAt});

  Images.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    image = json['image'];
    colorId = json['color_id'];
    productId = json['product_id'];
    isFeatured = json['is_featured'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['image'] = this.image;
    data['color_id'] = this.colorId;
    data['product_id'] = this.productId;
    data['is_featured'] = this.isFeatured;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
