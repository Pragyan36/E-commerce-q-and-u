// ignore_for_file: avoid_print

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/modules/home/controllers/home_controller.dart';
import 'package:usoft/app/widgets/custom_appbar.dart';
import 'package:usoft/app/widgets/nodata.dart';

import '../../../data/models/payment_response_model.dart';
import '../../account/views/options/my_order.dart';
import '../controllers/notification_controller.dart';
import 'notification _detail_page.dart';
import 'package:readmore/readmore.dart';

class NotificationView extends GetView<NotificationController> {
  NotificationView({Key? key}) : super(key: key);

  final homecon = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    log("NotificationView:onBuild:notificationsLength:${homecon.notifications.length}");
    homecon.refreshNotification();
    return Scaffold(
      appBar: AppBar(
        title: const Text("Notification"),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back_ios),
        ),
        backgroundColor: Colors.white,
      ),
      floatingActionButton: Obx(() => homecon.notifications.isNotEmpty
          ? FloatingActionButton(
              backgroundColor: AppColor.mainClr,
              onPressed: () {
                homecon.deleteAllNotifications();
              },
              child: const Icon(Icons.delete_forever),
            )
          : Container()),
      body: RefreshIndicator(
        onRefresh: () async {
          await homecon.refreshNotification();
        },
        child: SingleChildScrollView(
          child: Obx(
            () => homecon.notifications.isNotEmpty
                ? Column(
                    children: [
                      ...List.generate(
                        homecon.notifications.length,
                        (index) => _buildNotificationTile(
                            title: homecon.notifications[index]['title'],
                            body: homecon.notifications[index]['body'],
                            date: homecon.notifications[index]['createdAt'],
                            image: homecon.notifications[index]['image'],
                            dialogontap: () {
                              homecon.deleteItem(
                                  homecon.notifications[index]['id']);
                              Get.back();
                            }),
                      ),
                    ],
                  )
                : const NoDataView(text: 'Empty Notifications'),
          ),
        ),
      ),
    );
  }

  _buildNotificationTile({title, body, date, image, dialogontap}) {
    return GestureDetector(
      onTap: () {
        String myString = body;
        RegExp numberRegex = RegExp(r'\d+');
        Match numberMatch = numberRegex.allMatches(myString).last;
        String? orderID = numberMatch.group(0);
        print("orderID is $orderID");
        if (myString.contains("Order Id")) {
          Get.to(() => NotificationDetailPage(
                orderID: orderID!,
              ));
        }
      },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListTile(
            contentPadding: const EdgeInsets.only(top: 5, bottom: 5, left: 5),
            // leading: CircleAvatar(
            //   radius: 18,
            //   backgroundColor: AppColor.orange,
            //   child: Icon(
            //     Iconsax.shopping_cart,
            //     size: 18.sp,
            //     color: Colors.white,
            //   ),
            // ),
            title: Text(
              title,
              style: titleStyle.copyWith(fontWeight: FontWeight.w600,fontSize: 16),
            ),
            subtitle: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 8,),
                /*Text("$body\n\n",
                    style: subtitleStyle.copyWith(color: Colors.grey)),*/
                ReadMoreText(
                  body,
                  trimLines: 2,
                  preDataTextStyle: TextStyle(fontWeight: FontWeight.w500),
                  style: TextStyle(color: Colors.black),
                  colorClickableText: Colors.pink,
                  trimMode: TrimMode.Line,
                  trimCollapsedText: '...Show more',
                  trimExpandedText: ' show less',
                ),
                image == ""
                    ? Container()
                    : Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        height: Device.height / 6,
                        width: Device.width,
                        child: Image.network(
                          "$image",
                          fit: BoxFit.fitWidth,
                        )),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(date,
                        style: subtitleStyle.copyWith(
                            color: Colors.grey, fontWeight: FontWeight.w600)),
                    IconButton(
                        onPressed: () {
                          Get.defaultDialog(
                              radius: 10,
                              title: 'Delete notification',
                              content: MaterialButton(
                                onPressed: dialogontap,
                                color: AppColor.red,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)),
                                child: Text(
                                  'Delete',
                                  style: subtitleStyle.copyWith(color: Colors.white),
                                ),
                              ));
                        },
                        icon: Icon(
                          Icons.more_horiz_rounded,
                          size: 20.sp,
                        )),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
