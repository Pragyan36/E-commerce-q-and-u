import 'package:flutter/material.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/widgets/custom_appbar.dart';

class NotificationSettings extends StatelessWidget {
  const NotificationSettings({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(title: 'Notification Settings'),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SwitchListTile(
                value: false,
                title: Text(
                  'Enable Notification',
                  style: subtitleStyle,
                ),
                onChanged: (val) {})
          ],
        ),
      ),
    );
  }
}
