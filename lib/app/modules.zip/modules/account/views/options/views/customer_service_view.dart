import 'dart:convert';

import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/data/models/customer_care.dart';
import 'package:usoft/app/modules/home/controllers/home_controller.dart';
import 'package:usoft/app/widgets/custom_appbar.dart';
import 'package:usoft/app/widgets/custom_shimmer.dart';

import '../../../../../constants/constants.dart';
import 'package:http/http.dart' as http;

class CustomerServiceView extends GetView {
  const CustomerServiceView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final homeController = Get.put(HomeController());
    homeController.fetchCustomerCare();
    return Scaffold(
      appBar: CustomAppbar(
        title: "",
        trailing: Container(),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "How can we help you?",
                style: GoogleFonts.lato(
                    textStyle: TextStyle(fontSize: 20.sp, color: Colors.black)),
              ),
              const SizedBox(
                height: 30,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Top Articles -FAQ",
                    style: GoogleFonts.lato(
                        textStyle: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.black)),
                  ),
                  // const Text(
                  //   "View All",
                  //   style: TextStyle(color: AppColor.mainClr),
                  // )
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              ListView.builder(
                  shrinkWrap: true,
                  itemCount: homeController.customCare.length,
                  physics: const BouncingScrollPhysics(),
                  itemBuilder: (context, index) {
                    return Container(
                      decoration: BoxDecoration(
                          border: Border.all(
                              width: 3.0, color: const Color(0xFFFFFFFF))),
                      child: ExpandablePanel(
                        header: Obx(
                          () => homeController.loading.isTrue
                              ? CustomShimmer(
                                  baseColor: Colors.grey.shade300,
                                  highlightColor: Colors.grey.shade100,
                                  widget: Container(
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 8),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                    ),
                                    height: 50,
                                    width: MediaQuery.of(context).size.width,
                                    decoration: BoxDecoration(
                                      color: Colors.grey,
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                  ),
                                )
                              : Text(
                                  homeController
                                      .customCare[index].data![index].title
                                      .toString(),
                                  style: titleStyle,
                                ),
                        ),
                        collapsed: Container(),
                        expanded: Column(
                          children: [
                            Html(
                              data: homeController
                                  .customCare[index].data![index].content
                                  .toString(),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      ),
                    );
                  }),
              const SizedBox(
                height: 30,
              ),
              /* ListTile(
                title: Text(
                  "Topics",
                  style: GoogleFonts.lato(
                      textStyle: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)),
                ),
                trailing: const Icon(
                  Icons.contact_mail,
                  color: AppColor.mainClr,
                ),
              ),
              _builContactLayout(),*/
            ],
          ),
        ),
      ),
    );
  }

  Future<CustomerCareModel> fetchCustomerService() async {
    final response =
        await http.get(Uri.parse('https://jhigu.store/api/customercare'));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body.toString());
      return CustomerCareModel.fromJson(data);
    } else {
      // If the server did not return a 200 OK response, throw an error.
      throw Exception('Failed to load social media links');
    }
  }

  _buildFaq(
      CustomCareHeadingModel careHeadingModel, HomeController homeController) {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(width: 3.0, color: const Color(0xFFFFFFFF))),
      child: ExpandablePanel(
        header: Obx(
          () => homeController.loading.isTrue
              ? const Center(child: CircularProgressIndicator())
              : Text(
                  careHeadingModel.title.toString(),
                  style: titleStyle,
                ),
        ),
        collapsed: Container(),
        expanded: Column(
          children: [
            const SizedBox(
              height: 20,
            ),
            Text(
              careHeadingModel.content.toString(),
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              children: [
                IconButton(onPressed: () {}, icon: const Icon(Icons.thumb_up)),
                IconButton(
                    onPressed: () {}, icon: const Icon(Icons.thumb_down)),
              ],
            )
          ],
        ),
      ),
    );
  }

  _builContactLayout() {
    var contactUsItems = ["Email", "Facebook", "Phone", "WhatsApp"];
    return GridView.count(
      crossAxisCount: 2,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      childAspectRatio: 2,
      children: List.generate(
          contactUsItems.length,
          (index) => Card(
                child: Center(
                  child: Column(
                    children: const [
                      SizedBox(
                        height: 10,
                      ),
                      Icon(
                        Icons.email,
                        color: AppColor.mainClr,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Email")
                    ],
                  ),
                ),
              )),
    );
  }
}
