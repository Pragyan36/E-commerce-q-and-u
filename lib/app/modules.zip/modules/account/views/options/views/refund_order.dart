import 'package:flutter/material.dart';

import 'package:flutter_rating_bar/flutter_rating_bar.dart' as rat;
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:usoft/app/modules/account/controllers/order_controller.dart';
import 'package:usoft/app/modules/account/views/options/views/apply_refund.dart';

import '../../../../../constants/constants.dart';
import '../../../../../widgets/custom_appbar.dart';
import '../../../../../widgets/custom_buttons.dart';
import '../../../../payment/controllers/payment_controller.dart';
import '../my_order.dart';

class RefundOrder extends StatefulWidget {
  String orderId;

  RefundOrder({super.key, required this.orderId});

  @override
  State<RefundOrder> createState() => _RefundOrderState();
}

class _RefundOrderState extends State<RefundOrder> {
  final controller = Get.put(OrderController());
  var userName = TextEditingController();
  var userID = TextEditingController();
  var userContact = TextEditingController();

  var bankName = TextEditingController();
  var branchName = TextEditingController();
  var accountType = TextEditingController();

  var accountNumber = TextEditingController();
  final List<Map> paymentTypes = [
    {
      'name': 'Cash',
      'id': 3,
      'icon': const AssetImage("assets/images/payment-method.png"),
      'subtitle': 'Refund by Debit Cash on Delivery'
    },
    {
      'name': 'Esewa',
      'id': 2,
      'icon': const AssetImage("assets/images/Esewa.png"),
      'subtitle': 'Refund by Esewa'
    },
    {
      'name': 'Khalti',
      'id': 1,
      'icon': const AssetImage("assets/images/Khalti.png"),
      'subtitle': 'Refund by Khalti'
    },
    {
      'name': 'Bank',
      'id': 4,
      'icon': const AssetImage("assets/images/payment-method.png"),
      'subtitle': 'Refund by Bank'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: CustomAppbar(title: 'Refund order'),
        body: SingleChildScrollView(
          child: Column(
            children: [
              ...List.generate(
                paymentTypes.length,
                (index) => GetBuilder<OrderController>(
                  builder: (_) {
                    return RadioListTile(
                        title: Text(
                          paymentTypes[index]['name'],
                          style: titleStyle,
                        ),
                        subtitle: Text(
                          paymentTypes[index]['subtitle'],
                          style: subtitleStyle.copyWith(color: Colors.grey),
                        ),
                        secondary: Image(
                          image: paymentTypes[index]['icon'],
                          height: 20,
                          width: 20,
                        ),
                        value: paymentTypes[index]['id'].toString(),
                        groupValue: controller.select,
                        onChanged: (val) {
                          print(val);

                          setState(() {
                            controller.setSelectedRadio(val);
                            controller.selected.value =
                                int.parse(val.toString());
                            print("selected valu $controller.selected.value");
                          });
                        });
                  },
                ),
              ),
              controller.selected.value == 2 ? esewaTextField() : SizedBox(),
              controller.selected.value == 1 ? khaltiTextField() : SizedBox(),
              controller.selected.value == 4 ? bankTextField() : SizedBox(),
              SizedBox(
                height: 20,
              ),
              CustomButtons(
                  margin: const EdgeInsets.symmetric(horizontal: 15),
                  width: double.infinity,
                  label: 'Apply for Refund',
                  btnClr: AppColor.orange,
                  txtClr: Colors.white,
                  ontap: () async {
                    String returnType = controller.selected.value == 2
                        ? "esewa"
                        : controller.selected.value == 1
                            ? "khalti"
                            : controller.selected.value == 4
                                ? "bank"
                                : "cash";
                    controller
                        .applyrefund(
                            widget.orderId,
                            userName.text,
                            returnType,
                            bankName.text,
                            branchName.text,
                            accountNumber.text,
                            userID.text,
                            userContact.text,
                            accountType.text)
                        .then((value) {
                      if (value != null) {
                        const snackBar = SnackBar(
                          content: Text('Applied Sucessfully'),
                          duration: Duration(seconds: 3),
                        );
                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                        Get.to(MyOrderView(false));
                      } else {
                        const snackBar = SnackBar(
                          content: Text('Applied failed'),
                          duration: Duration(seconds: 3),
                        );
                        ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      }
                      print("value is$value");
                    });
                  }),
              SizedBox(
                height: 50,
              ),
            ],
          ),
        ));
  }

  esewaTextField() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child:
              CustomTextfield(controller: userName, hintText: "Esewa Username"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(controller: userID, hintText: "Esewa ID"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(controller: userContact, hintText: "Contact"),
        ),
      ],
    );
  }

  khaltiTextField() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(
              controller: userName, hintText: "Khalti Username"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(controller: userID, hintText: "Khalti ID"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(controller: userContact, hintText: "Contact"),
        ),
      ],
    );
  }

  bankTextField() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(
              controller: userName, hintText: "Account Holder Username"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(controller: bankName, hintText: "Bank Name"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(
              controller: accountNumber, hintText: "Account Number"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child:
              CustomTextfield(controller: branchName, hintText: "Branch Name"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(controller: userContact, hintText: "Contact"),
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: CustomTextfield(
              controller: accountType, hintText: "Account Type"),
        ),
      ],
    );
  }
}
