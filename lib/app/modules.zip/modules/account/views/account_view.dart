import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:iconsax/iconsax.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/database/app_storage.dart';
import 'package:usoft/app/model/social_icon.dart';
import 'package:usoft/app/modules/account/views/options/my_order.dart';
import 'package:usoft/app/modules/account/views/options/views/about_us_view.dart';
import 'package:usoft/app/modules/account/views/options/views/complete_order.dart';
import 'package:usoft/app/modules/account/views/options/views/contact_us.dart';
import 'package:usoft/app/modules/account/views/options/views/privacy_policy_view.dart';
import 'package:usoft/app/modules/account/views/options/views/return_order.dart';
import 'package:usoft/app/modules/account/views/options/views/terms_view.dart';
import 'package:usoft/app/modules/home/controllers/home_controller.dart';
import 'package:usoft/app/modules/login/controllers/login_controller.dart';
import 'package:usoft/app/modules/login/views/login_view.dart';

import '../../../helper/sql_helper.dart';
import '../../home/views/home_view.dart';
import '../controllers/account_controller.dart';
import 'options/my_details.dart';
import 'options/my_review.dart';
import 'options/my_rewards.dart';
import 'options/views/custom_care.dart';
import 'options/views/customer_service_view.dart';

class AccountView extends GetView<AccountController> {
  AccountView({Key? key}) : super(key: key);

  @override
  final controller = Get.put(AccountController());

  final logincon = Get.put(LoginController());
  final homeController = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    homeController.fetchSocialIcon();
    controller.onInit();
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        backgroundColor: Colors.white10,
        body: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(
                height: 10,
              ),
              Container(
                color: Colors.white,
                child: ListTile(
                    leading: Obx(
                      () => Hero(
                        tag: 'img',
                        child: CircleAvatar(
                            radius: 25,
                            backgroundColor: Colors.grey.shade200,
                            child: Container(
                              height: 60,
                              decoration: BoxDecoration(
                                  color: Colors.orange,
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                      image: CachedNetworkImageProvider(controller
                                                  .userdata
                                                  .value
                                                  .social_avatar !=
                                              null
                                          ? controller
                                              .userdata.value.social_avatar!
                                          : controller.userdata.value.photo !=
                                                  null
                                              ? controller.userdata.value.photo!
                                              : '$url/frontend/images/avatar.png'),
                                      fit: BoxFit.cover)),
                            )
                            // ClipOval(
                            //     child: CachedNetworkImage(
                            //       fit: BoxFit.cover,
                            //       imageUrl:
                            //           '$url/Uploads/user/${controller.userdata.value.photo}',
                            //       placeholder: (context, i) {
                            //         return const CircularProgressIndicator();
                            //       },
                            //     ),
                            //   ),

                            //  const Icon(
                            //   Iconsax.user,
                            //   color: AppColor.orange,
                            // ),
                            ),
                      ),
                    ),
                    title: Text(
                      'Hi',
                      style: subtitleStyle,
                    ),
                    subtitle: Obx(
                      () => Text(
                        controller.userdata.value.name ?? '...',
                        style:
                            subtitleStyle.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                    trailing: MaterialButton(
                        shape: CircleBorder(
                            side: BorderSide(
                                color: Colors.grey.shade400, width: 1)),
                        child: Icon(Iconsax.edit,
                            size: 20.sp, color: Colors.grey.shade500),
                        onPressed: () {
                          Get.to(() => MyDetails());
                        })),
              ),
              const SizedBox(
                height: 10,
              ),
              //Login card
              /*Obx(() => controller.savedToken.value == ''
                  ? Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                      margin: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 20),
                      color: Colors.white,
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        width: double.infinity,
                        child: Column(
                          children: [
                            const Text(
                                "Login to your account or register new one !"),
                            const SizedBox(
                              height: 10,
                            ),
                            ElevatedButton(
                              onPressed: () {
                                Get.to(() => LoginView());
                              },
                              style: ElevatedButton.styleFrom(
                                minimumSize: const Size.fromHeight(
                                    40), // fromHeight use double.infinity as width and 40 is the height
                              ),
                              child: const Text("Login or Register"),
                            )
                          ],
                        ),
                      ),
                    )
                  : Container()),
              Obx(
                () => logincon.savedToken.value == null
                    ? buildLoginCard()
                    : Container(),
              ),*/

              const SizedBox(
                height: 10,
              ),
              Container(height: 10, color: Color.fromARGB(255, 255, 255, 255)),
              //Profile Card
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: const [
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 20.0, vertical: 10),
                        child: Text(
                          "Account",
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              color: Colors.black54),
                        ),
                      ),
                    ],
                  ),
                  _buildAccountOptionTile(
                      'My Order', Icons.shopping_bag_outlined, () {
                    Get.to(() => MyOrderView(false));
                  }),
                  // _buildAccountOptionTile('Order History', Icons.history, () {
                  //   Get.to(() => OrderDetailsView());
                  // }),
                  _buildAccountOptionTile('My Details', Icons.event_note, () {
                    Get.to(() => MyDetails());
                  }),
                  _buildAccountOptionTile('My Rewards', Icons.star_border, () {
                    Get.to(() => MyRewards());
                  }),
                  /* _buildAccountOptionTile('Payment method', Icons.payment,
                      () {
                    Get.to(() => PaymentMethods());
                  }),*/
                  /*_buildAccountOptionTile('Notification setting',
                      Icons.notifications_none_rounded, () {
                    Get.to(() => const NotificationSettings());
                  }),*/
                  _buildAccountOptionTile('Reviews', Icons.messenger_outline,
                      () {
                    Get.to(() => MyReviewView());
                  }),
                  _buildAccountOptionTile(
                      'Complete Order', Icons.local_shipping, () {
                    Get.to(() => CompleteOrderScreen());
                  }),
                  _buildAccountOptionTile('Return Order', Icons.keyboard_return,
                      () {
                    Get.to(() => const ReturnOrderScreen());
                  }),
                  _buildAccountOptionTile('Logout', Icons.logout, () async {
                    AppStorage.removeStorage();
                    await SQLHelper.deleteAll();
                    Get.offAll(() => HomeView());
                    FacebookAuth.instance.logOut();
                  }),
                ],
              ),
              Container(height: 10, color: Color.fromARGB(255, 250, 247, 247)),
              //Contact Card
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: const [
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 20.0, vertical: 10),
                        child: Text(
                          "Support",
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              color: Colors.black54),
                        ),
                      ),
                    ],
                  ),
                  _buildAccountOptionTile(
                      "Customer service", Icons.phone_in_talk, () {
                    Get.to(() => const CustomerServiceView());
                  }),
                  _buildAccountOptionTile("About Us", Icons.info, () {
                    Get.to(() => AboutUsView());
                  }),
                  _buildAccountOptionTile("Terms & Conditions", Icons.list, () {
                    Get.to(() => const TermsView());
                  }),
                  _buildAccountOptionTile("Contact Us", Icons.contact_mail, () {
                    Get.to(() => ContactusView());
                  }),
                  _buildAccountOptionTile("Return Policy", Icons.policy, () {
                    Get.to(() => const PrivacyPolicyView());
                  }),
                  _buildAccountOptionTile("Customer Care", Icons.person, () {
                    Get.to(() => const CustomerCareScreen());
                  }),
                ],
              ),
              Container(height: 10, color: Color.fromARGB(255, 250, 247, 247)),
              Card(
                elevation: 4,
                margin:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      height: 10,
                    ),
                    FutureBuilder<SocialIconModel>(
                        future: fetchSocialMediaLinks(),
                        builder: (context, snapshot) {
                          var datas = snapshot.data;
                          if (snapshot.hasData) {
                            return Column(
                              children: [
                                const CircleAvatar(
                                  radius: 40,
                                  backgroundImage:
                                      AssetImage("assets/images/appicon.png"),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 60.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top: 0),
                                        child: Center(
                                          child: Text(
                                            datas!.data!.name.toString(),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                const Divider(
                                  height: 1,
                                  color: Colors.grey,
                                ),
                                buildOfficeContacts(
                                  icon: FontAwesomeIcons.phone,
                                  text: 'Phone',
                                  iconColor: Colors.blue,
                                  subtitle: '',
                                  onTap: () {
                                    homeController.makePhoneCall(
                                        "tel:${datas.data!.phone}");
                                  },
                                ),
                                buildOfficeContacts(
                                  icon: Icons.mail,
                                  text: 'Email',
                                  iconColor: Colors.blue,
                                  subtitle: '',
                                  onTap: () {
                                    final Uri emailLaunchUri = Uri(
                                      scheme: 'mailto',
                                      path: datas.data!.email,
                                    );

                                    launchUrl(emailLaunchUri);
                                  },
                                ),
                                const Divider(
                                  height: 1,
                                  color: Colors.grey,
                                ),
                                buildOfficeContacts(
                                  icon: FontAwesomeIcons.facebook,
                                  text: 'Facebook',
                                  iconColor: Colors.blue,
                                  subtitle: '',
                                  onTap: () {
                                    homeController.makePhoneCall(
                                        datas.data!.facebook.toString());
                                  },
                                ),
                                const Divider(
                                  height: 1,
                                  color: Colors.grey,
                                ),
                                buildOfficeContacts(
                                  icon: FontAwesomeIcons.instagram,
                                  text: 'Instagram',
                                  iconColor: Colors.blue,
                                  subtitle: '',
                                  onTap: () {
                                    homeController.makePhoneCall(
                                        datas.data!.instagram.toString());
                                  },
                                ),
                                const Divider(
                                  height: 1,
                                  color: Colors.grey,
                                ),
                                buildOfficeContacts(
                                  icon: FontAwesomeIcons.twitter,
                                  text: 'Twitter',
                                  iconColor: Colors.blue,
                                  subtitle: '',
                                  onTap: () {
                                    homeController.makePhoneCall(
                                        datas.data!.twitter.toString());
                                  },
                                ),
                                const Divider(
                                  height: 1,
                                  color: Colors.grey,
                                ),
                                buildOfficeContacts(
                                  icon: FontAwesomeIcons.youtube,
                                  text: 'Youtube',
                                  iconColor: Colors.blue,
                                  subtitle: '',
                                  onTap: () async {
                                    // ignore: deprecated_member_use
                                    homeController.makePhoneCall(
                                        datas.data!.youtube.toString());
                                  },
                                ),
                                const Divider(
                                  height: 1,
                                  color: Colors.grey,
                                ),
                                buildOfficeContacts(
                                  icon: FontAwesomeIcons.map,
                                  text: 'Map',
                                  iconColor: Colors.blue,
                                  subtitle: '',
                                  onTap: () async {
                                    homeController.makePhoneCall(
                                        datas.data!.address.toString());
                                  },
                                ),
                              ],
                            );
                          }
                          return const CircularProgressIndicator();
                        }),
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              )

              //
            ],
          ),
        ),
      ),
    );
  }

  Widget buildOfficeContacts({
    IconData? icon,
    String? text,
    Function()? onTap,
    Color? iconColor,
    String? subtitle,
  }) {
    return ListTile(
        onTap: onTap,
        title: Text(text!),
        leading: Icon(icon),
        subtitle: subtitle != null ? Text(subtitle) : const SizedBox());
  }

  _buildAccountOptionTile(title, icon, ontap) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 15),
      leading: Icon(
        icon,
        size: 20.sp,
        color: Colors.black,
      ),
      title: Text(
        title,
        style: titleStyle,
      ),
      trailing: Icon(
        Icons.arrow_forward_ios_rounded,
        size: 16.sp,
        color: Colors.black12,
      ),
      onTap: ontap,
    );
  }

  buildLoginCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4),
      ),
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      color: Colors.white,
      child: Container(
        padding: const EdgeInsets.all(20),
        width: double.infinity,
        child: Column(
          children: [
            const Text("Login to your account or register new one !"),
            const SizedBox(
              height: 10,
            ),
            ElevatedButton(
              onPressed: () {
                Get.to(() => LoginView());
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(
                    40), // fromHeight use double.infinity as width and 40 is the height
              ),
              child: const Text("Login or Register"),
            )
          ],
        ),
      ),
    );
  }

  Future<SocialIconModel> fetchSocialMediaLinks() async {
    final response =
        await http.get(Uri.parse('https://jhigu.store/api/social-site'));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body.toString());
      return SocialIconModel.fromJson(data);
    } else {
      // If the server did not return a 200 OK response, throw an error.
      throw Exception('Failed to load social media links');
    }
  }
}
