// ignore_for_file: unnecessary_overrides

import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:otp_text_field/otp_text_field.dart';
import 'package:smart_auth/smart_auth.dart';
import 'package:usoft/app/data/services/auth_service.dart';
import 'package:usoft/app/routes/app_pages.dart';
import 'package:usoft/app/widgets/loading_widget.dart';
import 'package:usoft/app/widgets/snackbar.dart';

import '../../../data/models/shipping_address_model.dart';
import '../components/verify_otp.dart';

class RegisterController extends GetxController {
  final count = 0.obs;

  final name = TextEditingController();
  final referalCode = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  final zip = TextEditingController();
  final password = TextEditingController();
  final confirmpassword = TextEditingController();
  final otpController = OtpFieldController();

  var addresses = <ShippingAddressData>[].obs;
  var districts = <Districts>[].obs;
  var selectedDistrict = <Districts>[].obs;
  var areas = <Localarea>[].obs;
  var loading = false.obs;
  var viewPassword = true.obs;
  var viewConPassword = true.obs;

  var selectedProvinceName = '';
  var selectedDistrictName = '';
  var selectedAreaName = '';
  var registerLoading = false.obs;

  @override
  void onInit() {
    fetchAddresses();
    getAppSignature();
    smsRetriever();
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;
  var userPhone = "".obs;

  register() async {
    registerLoading.value = true;
    log("RegisterController:register");
    Get.defaultDialog(content: const LoadingWidget(), title: 'Loading...');
    var data = await AuthService().register(
        name: name.text,
        email: email.text,
        password: password.text,
        confirmPassword: confirmpassword.text,
        phone: phone.text,
        address: address.text,
        photo: "",
        province: selectedProvinceName,
        district: selectedDistrictName,
        area: selectedAreaName,
        zip: zip.text,
        referalCode: referalCode.text);
    if (data != null) {
      await Future.delayed(const Duration(seconds: 2));
      registerLoading.value = false;
      Get.back();
      if (data['error'] == false) {
        userPhone.value = phone.text;
        getSnackbar(message: data['message']);
        // Get.offAllNamed(Routes.LOGIN);
        Get.to(() => VerifyOtpScreen());
      }
      if (data['error'] == true) {
        getSnackbar(message: data['msg']);
        // if (data['msg'] != null && data['msg']['referal_code'] != null) {
        //   getSnackbar(message: data['msg']["referal_code"][0]);
        // }
      }
    }
  }

  fetchAddresses() async {
    loading.value = true;
    var data = await AuthService().getAddresses();
    // print('object'+)
    if (data != null) {
      addresses.clear();

      data['data']
          .forEach((v) => addresses.add(ShippingAddressData.fromJson(v)));
      // log("fetchAddresses:length: ${addresses.length} data: ${data['data']}");
    }
    loading.value = false;
  }

  verifyUser(otp) async {
    var data = await AuthService().verifyRegisteredUser(
      emailorphone: userPhone.value,
      otp: otp,
    );
    print(data.toString());

    if (data != null) {
      Get.toNamed(Routes.LOGIN);

      if (data['error'] == true) {
        getSnackbar(message: data['msg'].toString());
      }
      if (data['error'] == false) {
        getSnackbar(message: data['msg'].toString());
      }
    }
  }

  resendOtp() async {
    var data = await AuthService()
        .resendOtpRegisteredUser(emailorphone: userPhone.value);
    print(data);
    otpController.clear();
    if (data != null) {
      if (data['error'] == true) {
        getSnackbar(message: data['msg'].toString());
      }
      if (data['error'] == false) {
        getSnackbar(message: data['msg'].toString());
      }
    }
  }

  final smartAuth = SmartAuth();
  final pinputController = TextEditingController();
  var smsSign = ''.obs;

  void getAppSignature() async {
    final res = await smartAuth.getAppSignature();
    smsSign.value = res!;
    debugPrint('Signature: $res');
  }

  void getSmsCode() async {
    final res = await smartAuth.getSmsCode(matcher: smsSign.toString());
    debugPrint('SMSsa: ${res}');

    if (res.codeFound) {
      debugPrint('SMS: ${res.code}');
      print('SMS: ${res.code}');
    } else {
      debugPrint('SMS Failure:');
    }
  }

  void userConsent() async {
    debugPrint('userConsent: ');
    final res = await smartAuth.getSmsCode(useUserConsentApi: true);
    userConsent();
    if (res.codeFound) {
      pinputController.text = res.code!;
    } else {
      debugPrint('userConsent failed: $res');
    }
    debugPrint('userConsent: $res');
  }

  void smsRetriever() async {
    final res = await smartAuth.getSmsCode();
    smsRetriever();
    if (res.codeFound) {
      pinputController.text = res.code!;
    } else {
      debugPrint('smsRetriever failed: $res');
    }
    debugPrint('smsRetriever: $res');
  }
}

/* data['data'][0]['districts']
          .forEach((v) => districts.add(Districts.fromJson(v)));
      data['data'][0]['districts'][0]['localarea']
          .forEach((v) => areas.add(Localarea.fromJson(v)));*/
