import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/routes/app_pages.dart';
import 'package:usoft/app/utils/validators.dart';
import 'package:usoft/app/widgets/custom_buttons.dart';
import 'package:usoft/app/widgets/custom_shimmer.dart';
import 'package:usoft/app/widgets/loading_widget.dart';
import 'package:usoft/app/widgets/snackbar.dart';

import '../../../constants/constants.dart';
import '../../../widgets/custom_button.dart';
import '../../../widgets/inputfield.dart';
import '../controllers/register_controller.dart';

class RegisterView extends GetView<RegisterController> {
  RegisterView({Key? key}) : super(key: key);
  final _formKey = GlobalKey<FormState>();
  final _districtKey = GlobalKey<FormState>();
  final _areaKey = GlobalKey<FormState>();
  final _provinceKey = GlobalKey<FormState>();
  var isValid = false;
  @override
  final controller = Get.put(RegisterController());

  final List<String> items = [
    'Item1',
    'Item2',
    'Item3',
    'Item4',
  ];

  @override
  Widget build(BuildContext context) {
    controller.fetchAddresses();

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 40),
              child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          child: Row(
                            children: [
                              Icon(Icons.arrow_back_ios),
                              Text(
                                "Back to login",
                                style: titleStyle,
                              )
                            ],
                          ),
                        ),
                      ),
                      Center(
                        child: SizedBox(
                          height: 100,
                          width: 100,
                          child: Image.asset(AppImages.logo),
                        ),
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      Text(
                        'Create a new account',
                        style: headingStyle,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Please enter the credentials below to start using the app.',
                        style: subtitleStyle,
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      MyInputField(
                          hint: 'Full Name',
                          controller: controller.name,
                          validator: (v) => validateIsEmpty(string: v)),
                      const SizedBox(
                        height: 10,
                      ),
                      MyInputField(
                        hint: 'Email',
                        controller: controller.email,
                        validator: (v) => validateEmail(string: v),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      MyInputField(
                        hint: 'Phone',
                        controller: controller.phone,
                        validator: (v) => validatePhone(
                          string: v,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      MyInputField(
                        hint: 'Additional Address (Optional)',
                        controller: controller.address,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      MyInputField(
                        hint: 'Zip Code (Optional)',
                        controller: controller.zip,
                        inputType: TextInputType.number,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      _buildAddress(),
                      Obx(
                        () => MyInputField(
                          hint: 'Password',
                          suffix: IconButton(
                              onPressed: () {
                                controller.viewPassword.value =
                                    !controller.viewPassword.value;
                              },
                              icon: controller.viewPassword.value
                                  ? Icon(
                                      Icons.visibility_off,
                                      size: 20.sp,
                                    )
                                  : Icon(
                                      Icons.password,
                                      size: 20.sp,
                                    )),
                          obscuretext: controller.viewPassword.value,
                          controller: controller.password,
                          validator: (v) => validateIsEmpty(string: v),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Obx(
                        () => MyInputField(
                          hint: 'Confirm Password',
                          suffix: IconButton(
                              onPressed: () {
                                controller.viewConPassword.value =
                                    !controller.viewConPassword.value;
                              },
                              icon: controller.viewConPassword.value
                                  ? Icon(
                                      Icons.visibility_off,
                                      size: 20.sp,
                                    )
                                  : Icon(
                                      Icons.password,
                                      size: 20.sp,
                                    )),
                          obscuretext: controller.viewConPassword.value,
                          controller: controller.confirmpassword,
                          validator: (v) => confirmPassword(
                              password: controller.password.text, cPassword: v),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      MyInputField(
                        hint: 'Referral Code (Optional)',
                        controller: controller.referalCode,
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      SizedBox(
                        height: 50,
                        width: double.infinity,
                        child: CustomButtons(
                          label: 'Sign up ',
                          txtClr: Colors.white,
                          btnClr: AppColor.mainClr,
                          ontap: () async {
                            // Get.to(() => VerifyOtpScreen());

                            if (_formKey.currentState!.validate() &&
                                _provinceKey.currentState!.validate() &&
                                _districtKey.currentState!.validate() &&
                                _areaKey.currentState!.validate()) {
                              controller.registerLoading.value
                                  ? null
                                  : await controller.register();
                            } else {
                              getSnackbar(
                                  message: "Please fill all information",
                                  bgColor: AppColor.red);
                            }
                            // if (_areaKey.currentState!.validate()) {
                            //   isValid = true;
                            // } else {
                            //   isValid = false;
                            // }

                            // if (_formKey.currentState!.validate()) {
                            //   isValid = true;
                            // } else {
                            //   isValid = false;
                            // }
                            // if (isValid) {
                            //   await controller.register();
                            // } else {
                            //   getSnackbar(
                            //       message: "Please fill all information");
                            // }
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Center(
                        child: RichText(
                          text: TextSpan(
                              text: 'Already a member? ',
                              style: subtitleStyle,
                              children: <TextSpan>[
                                TextSpan(
                                    text: 'log in',
                                    style: subtitleStyle.copyWith(
                                        color: AppColor.orange),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () => Get.toNamed(Routes.LOGIN))
                              ]),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      // Align(
                      //   alignment: Alignment.bottomCenter,
                      //   child: Text(
                      //     ' Or sign in with',
                      //     style: subtitleStyle,
                      //     textAlign: TextAlign.end,
                      //   ),
                      // ),
                      // const SizedBox(
                      //   height: 10,
                      // ),
                      // Row(
                      //   mainAxisAlignment: MainAxisAlignment.spaceAround,
                      //   children: [
                      //     _buildButton(
                      //       const Icon(
                      //         Icons.facebook,
                      //         color: Colors.white,
                      //       ),
                      //       'Facebook',
                      //       Colors.blue.shade900,
                      //       Colors.white,
                      //       () {},
                      //     ),
                      //     _buildButton(
                      //       Image.asset(
                      //         'assets/images/google.png',
                      //         height: 10,
                      //       ),
                      //       'Google',
                      //       Colors.white,
                      //       Colors.black,
                      //       () {},
                      //     ),
                      // ],
                      // ),
                    ],
                  )),
            ),
          ],
        ),
      ),
    );
  }

  _buildButton(icon, label, btnClr, txtClr, ontap) {
    return SizedBox(
      height: 50,
      width: 40.w,
      child: MaterialButton(
        onPressed: ontap,
        elevation: 5,
        color: btnClr,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            icon,
            const SizedBox(
              width: 10,
            ),
            Text(
              label,
              style: titleStyle.copyWith(color: txtClr),
            ),
          ],
        ),
      ),
    );
  }

  _buildAddress() {
    return Obx(() => controller.loading.value
        ? Container()
        : Column(
            children: [
              /*---------------Province--------*/
              Obx(() => Form(
                    key: _provinceKey,
                    child: DropdownButtonFormField2(
                      decoration: InputDecoration(
                        fillColor: Colors.grey.shade300.withOpacity(0.4),
                        filled: true,
                        isDense: true,
                        contentPadding: const EdgeInsets.only(
                            left: 0, right: 0, top: 5, bottom: 5),
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                            width: 0,
                          ),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                      isExpanded: true,
                      hint: Text(
                        'Select Province',
                        style: subtitleStyle.copyWith(color: Colors.grey),
                      ),
                      icon: const Icon(
                        Icons.arrow_drop_down,
                        color: Colors.black45,
                      ),
                      iconSize: 30,
                      buttonHeight: 40,
                      dropdownDecoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      items: controller.addresses
                          .map((item) => DropdownMenuItem<String>(
                                value: item.id.toString(),
                                onTap: () {
                                  controller.selectedProvinceName =
                                      item.engName.toString();
                                },
                                child: Text(
                                  item.engName.toString(),
                                  style: const TextStyle(
                                    fontSize: 14,
                                  ),
                                ),
                              ))
                          .toList(),
                      validator: (value) {
                        if (value == null) {
                          return 'Please select province.';
                        }
                      },
                      onChanged: (value) {
                        _districtKey.currentState!.reset();
                        _areaKey.currentState!.reset();
                        controller.districts.clear();
                        controller.addresses[int.parse(value.toString()) - 1]
                            .districts
                            ?.forEach((element) {
                          controller.districts.add(element);
                        });
                      },
                      onSaved: (value) {},
                    ),
                  )),
              const SizedBox(
                height: 10,
              ),
              /*----------District-----------*/
              Obx(() => Form(
                    key: _districtKey,
                    child: DropdownButtonFormField2(
                      decoration: InputDecoration(
                        fillColor: Colors.grey.shade300.withOpacity(0.4),
                        filled: true,
                        isDense: true,
                        contentPadding: const EdgeInsets.only(
                            left: 0, right: 0, top: 5, bottom: 5),
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                            width: 0,
                          ),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                      isExpanded: true,
                      hint: Text(
                        'Select District',
                        style: subtitleStyle.copyWith(color: Colors.grey),
                      ),
                      icon: const Icon(
                        Icons.arrow_drop_down,
                        color: Colors.black45,
                      ),
                      iconSize: 30,
                      buttonHeight: 40,

                      dropdownDecoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      items: controller.districts
                          .map((item) => DropdownMenuItem<String>(
                                onTap: () {
                                  controller.selectedDistrictName =
                                      item.npName.toString();
                                },
                                value: item.id.toString(),
                                child: Text(
                                  item.npName.toString(),
                                  style: const TextStyle(
                                    fontSize: 14,
                                  ),
                                ),
                              ))
                          .toList(),
                      validator: (value) {
                        if (value == null) {
                          return 'Please select district.';
                        }
                      },
                      onChanged: (value) {
                        _areaKey.currentState!.reset();
                        controller.selectedDistrict
                            .addAll(controller.districts);

                        controller.selectedDistrict.retainWhere((element) =>
                            element.id == int.parse(value.toString()));
                        controller.areas.clear();

                        controller.selectedDistrict[0].localarea
                            ?.forEach((element) {
                          controller.areas.add(element);
                        });
                      },
                      onSaved: (value) {},
                    ),
                  )),
              const SizedBox(
                height: 10,
              ),
              /*------------Area-----------*/
              Obx(() => Form(
                    key: _areaKey,
                    child: DropdownButtonFormField2(
                      decoration: InputDecoration(
                        fillColor: Colors.grey.shade300.withOpacity(0.4),
                        filled: true,
                        isDense: true,
                        contentPadding: const EdgeInsets.only(
                            left: 0, right: 0, top: 5, bottom: 5),
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                            width: 0,
                          ),
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                      isExpanded: true,
                      hint: Text(
                        'Select Area',
                        style: subtitleStyle.copyWith(color: Colors.grey),
                      ),
                      icon: const Icon(
                        Icons.arrow_drop_down,
                        color: Colors.black45,
                      ),
                      iconSize: 30,
                      buttonHeight: 40,
                      dropdownDecoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      items: controller.areas
                          .map((item) => DropdownMenuItem<String>(
                                onTap: () {
                                  controller.selectedAreaName =
                                      item.localName.toString();
                                },
                                value: item.id.toString(),
                                child: Text(
                                  item.localName.toString(),
                                  style: const TextStyle(
                                    fontSize: 14,
                                  ),
                                ),
                              ))
                          .toList(),
                      validator: (value) {
                        if (value == null) {
                          return 'Please select area.';
                        }
                      },
                      onChanged: (value) {},
                      onSaved: (value) {},
                    ),
                  )),
              const SizedBox(
                height: 10,
              ),
              /*-----------Others--------*/
            ],
          ));
  }
}
