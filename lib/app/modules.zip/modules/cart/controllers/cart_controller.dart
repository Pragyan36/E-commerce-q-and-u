// ignore_for_file: unnecessary_overrides

import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:usoft/app/data/products.dart';
import 'package:usoft/app/data/services/cart_service.dart';

import '../../../data/models/cart_model.dart';
import '../../../database/app_storage.dart';
import '../../../widgets/snackbar.dart';
import '../../login/controllers/login_controller.dart';

class CartController extends GetxController {
  var cartProductsList = <Products>[].obs;
  var cartAssetsList = <CartAssets>[].obs;
  @override
  void onInit() {
    fetchCart();
    super.onInit();
  }

  // @override
  // void onReady() {
  //   log("Cart Controller: onReady");
  //   super.onReady();
  // }

  @override
  void onClose() {
    super.onClose();
  }

  // addToCart(
  //   id,
  //   img,
  //   price,
  //   name,
  // ) {
  //   cartProductsList.add(Products(
  //     id: id,
  //     productImage: img,
  //     productPrice: price,
  //     productname: name,
  //   ));
  //   update();
  // }

  // deleteCartitem(int index) {
  //   cartProductsList.removeAt(index);
  //   update();
  // }

  // final _products = {}.obs;
  // void addProduct(Products product) {
  //   if (_products.containsKey(product)) {
  //     _products[product] += 1;
  //   } else {
  //     _products[product] = 1;
  //   }
  // }

  // get products => _products;

  final logcon = Get.put(LoginController());

  var cartDataList = <CartModelData>[].obs;
  var cartdata = CartModel().obs;
  var cartSummary = CartModel().obs;
  var cartLoading = false.obs;
  var addCartLoading = false.obs;
  var test = false.obs;
  Rx<int> count = 1.obs;
  RxNum defaultval = RxNum(1);

  void increment() {
    if (count >= 0) {
      count.value++;
    }
  }

  void decrement() {
    if (count >= 1) {
      count.value--;
    }
  }

  addToCart(productid, totalprice, qty, colorid) async {
    try {
      addCartLoading.value=true;
      print("CartController: Add to cart Called");
      var data = await CartService().addToCart(
          token: AppStorage.readAccessToken,
          productid: productid,
          price: totalprice,
          qty: qty,
          colorid: colorid,
          varientid: colorid);

      if (data != null) {
        addCartLoading.value=false;
        if (kDebugMode) {
          print(data);
        }
        if (data['error'] == false) {
          getSnackbar(message: 'Added to cart');
          // cartlist.clear();
          // data['data'].forEach((v) => cartlist.add(CartData.fromJson(v)));
          fetchCart();
        } else if (data['error'] == true) {
          getSnackbar(message: data['msg'], bgColor: Colors.red, error: true);
        }
      }
    } on Exception catch (e) {
      log(e.toString(), name: 'getLocationTrack Error');
    } finally {
      addCartLoading(false);
    }
  }

  fetchCart() async {
    cartLoading(true);
    // print("totla_price: ${cartdata.value.data?[0].totalPrice}");
    var data = await CartService().getCart(
      token: AppStorage.readAccessToken,
    );
    cartAssetsList.clear();
    cartDataList.clear();
    if (data != null) {
      if (data['error'] == false) {
        cartAssetsList.clear();
        cartDataList.clear();
        cartSummary.value = CartModel.fromJson(data);
        data['data']
            .forEach((v) => cartDataList.add(CartModelData.fromJson(v)));

        data['data'][0]['cart_assets']
            .forEach((v) => cartAssetsList.add(CartAssets.fromJson(v)));

        // getSnackbar(message: 'fetch cart data successfull');
      } else if (data['error'] == true) {
        getSnackbar(message: data['msg'], bgColor: Colors.red, error: true);
      }
    } else {
      log("cartController:fetchCart-> data is null");
    }
    cartLoading(false);
  }

  removeCartitem(productid) async {
    var data = await CartService().removeFromCart(
      productid: productid,
      token: AppStorage.readAccessToken,
    );
    if (data != null) {
      if (data['error'] == false) {
        getSnackbar(message: 'Item removed');
        fetchCart();
      } else {
        getSnackbar(
            message: 'Error removing item', bgColor: Colors.red, error: true);
      }
    }
  }

  updateCartitem(productid, qty) async {
    var data = await CartService().updateCart(
      productid: productid,
      qty: qty,
      token: AppStorage.readAccessToken,
    );
    print(qty);
    if (data != null) {
      if (data['error'] == false) {
        // getSnackbar(message: data['msg']);
        fetchCart();
        getSnackbar(message: 'Cart Updated !!', bgColor: Colors.green);
      } else {
        fetchCart();
        // print(count);
        getSnackbar(
            message: 'Out of Stock', bgColor: Colors.red, error: true);
      }
    }
  }

  deleteAllCart() async {
    var data = await CartService().deleteCartProducts(
      AppStorage.readAccessToken,
    );
    if (data != null) {
      if (data['error'] == false) {
        getSnackbar(message: data['msg'], error: false);
        fetchCart();
      } else {
        // print(count);
        getSnackbar(
            message: 'Sorry !! No Item in Cart',
            bgColor: Colors.red,
            error: true);
      }
    }
  }
}
