import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/data/models/cart_model.dart';
import 'package:usoft/app/modules/product_detail/views/product_detail_view.dart';
import 'package:usoft/app/routes/app_pages.dart';
import 'package:usoft/app/widgets/custom_appbar.dart';
import 'package:usoft/app/widgets/custom_button.dart';
import 'package:usoft/app/widgets/custom_shimmer.dart';
import 'package:usoft/app/widgets/nodata.dart';

import '../controllers/cart_controller.dart';
import 'package:intl/intl.dart';

class CartView extends GetView<CartController> {
  CartView({Key? key}) : super(key: key);
  @override
  final controller = Get.put(CartController());
  var formatter = NumberFormat('#,###');

  @override
  Widget build(BuildContext context) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.fetchCart();
    });

    // print(controller.cartAssetsList.length);*/
    return Obx(
      () => Scaffold(
        extendBody: true,
        appBar: CustomAppbar(
          title: 'My Cart(${controller.cartAssetsList.length})',
          leading: Container(),
          trailing: TextButton(
              onPressed: () {
                // controller.cartAssetsList.clear();
                controller.deleteAllCart();
              },
              child: Text(
                'Delete All',
                style: subtitleStyle.copyWith(color: AppColor.orange),
              )),
        ),
        body: RefreshIndicator(
          color: AppColor.orange,
          onRefresh: () async {
            await Future.delayed(const Duration(seconds: 1));
            controller.fetchCart();
          },
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(
                parent: BouncingScrollPhysics()),
            child: Column(
              children: [
                Obx(() => controller.cartLoading.isTrue
                    ? ListView.builder(
                        itemCount: 5,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return CustomShimmer(
                            baseColor: Colors.grey.shade300,
                            highlightColor: Colors.grey.shade100,
                            widget: Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 10),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                              ),
                              height: 100,
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: Colors.grey,
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          );
                        })
                    : controller.cartAssetsList.isNotEmpty
                        ? Column(
                            children: [
                              const SizedBox(
                                height: 20,
                              ),
                              ...List.generate(
                                controller.cartAssetsList.length,
                                (index) => Obx(
                                  () => controller.cartAssetsList.isNotEmpty
                                      ? GestureDetector(
                                          onTap: () {
                                            Get.to(ProductDetailView(
                                              slug: controller!.cartAssetsList!
                                                  .value![index].slug,
                                            ));
                                          },
                                          child: CartTile(
                                            img: controller
                                                .cartAssetsList[index]
                                                .productImage?[0]
                                                .image
                                                ?.replaceAll(
                                                    RegExp(
                                                        r'http://127.0.0.1:8000'),
                                                    url),
                                            name: controller
                                                .cartAssetsList[index]
                                                .productName,
                                            price: formatter.format(controller
                                                .cartAssetsList[index]
                                                .subTotalPrice),
                                            quantity: controller
                                                .cartAssetsList[index].qty,
                                            productid: controller
                                                .cartAssetsList[index]
                                                .productId,
                                            index: index,
                                            data: controller
                                                .cartAssetsList[index],
                                            ontap: () async {
                                              await controller.removeCartitem(
                                                  controller
                                                      .cartAssetsList[index]
                                                      .id);
                                              controller.cartAssetsList
                                                  .removeAt(index);
                                              // controller.deleteCartitem(controller
                                              //     .cartProductsList[index].id!
                                              //     .toInt());
                                            },
                                          ),
                                        )
                                      : Text(
                                          'no item',
                                          style: subtitleStyle,
                                        ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    // ExpansionTile(
                                    //     tilePadding: const EdgeInsets.symmetric(
                                    //         horizontal: 10),
                                    //     title: Text('Add a voucher',
                                    //         style: subtitleStyle)),
                                    _buildAmountTile(
                                      'Sub-total',
                                      'Rs.${formatter.format(controller.cartSummary.value.totalAmount)}',
                                    ),
                                    _buildAmountTile(
                                      'Vat(%)',
                                      'Rs.${formatter.format(controller.cartSummary.value.vat)}',
                                    ),
                                    // _buildAmountTile(
                                    //   'Shipping Change',
                                    //   'Rs.0',
                                    // ),
                                    const Divider(
                                      thickness: 1.5,
                                      indent: 20,
                                      endIndent: 20,
                                    ),
                                    Obx(
                                      () => _buildAmountTile(
                                        'Total',
                                        'Rs.${formatter.format(controller.cartSummary.value.grandTotal)}',
                                      ),
                                    ),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width -
                                          20,
                                      child: CustomButton(
                                          label: 'Proceed',
                                          btnClr: AppColor.orange,
                                          txtClr: Colors.white,
                                          ontap: () {
                                            Get.toNamed(
                                              Routes.SHIPPING,
                                              arguments: controller
                                                  .cartdata.value.totalAmount,
                                            );
                                          }),
                                    )
                                  ],
                                ),
                              ),
                            ],
                          )
                        : const NoDataView(text: 'Empty Cart')),

                // ...List.generate(
                //     controller.products.length,
                //     (index) => CartTileWidget(
                //         quantity: 1,
                //         product: controller.products.keys.toList()[index]))
              ],
            ),
          ),
        ),
      ),
    );
  }

  _buildAmountTile(title, total) {
    return ListTile(
      dense: true,
      visualDensity: const VisualDensity(vertical: -3),
      title: Text(
        title,
        style: subtitleStyle.copyWith(color: Colors.grey),
      ),
      trailing: Text(
        total.toString(),
        style: subtitleStyle.copyWith(fontWeight: FontWeight.w500),
      ),
    );
  }
}

class CartTile extends StatefulWidget {
  const CartTile(
      {Key? key,
      this.img,
      this.name,
      this.price,
      this.ontap,
      this.quantity,
      this.productid,
      this.index,
      this.data})
      : super(key: key);

  final CartAssets? data;
  final String? img;
  final String? name;
  final String? price;
  final int? quantity;
  final int? productid;
  final int? index;
  final VoidCallback? ontap;

  @override
  State<CartTile> createState() => _CartTileState();
}

class _CartTileState extends State<CartTile> {
  final controller = Get.put(CartController());
  int b = 0;

  @override
  Widget build(BuildContext context) {
    int a = widget.data!.qty!.toInt() + b;
    return Card(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        width: double.infinity,
        height: 120,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
                margin: const EdgeInsets.only(bottom: 10, right: 10),
                height: 80,
                width: 80,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.grey.shade200,
                ),
                child: CachedNetworkImage(
                  imageUrl: widget.data?.productImage?[0].image
                          ?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url) ??
                      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8c2hvZXN8ZW58MHx8MHx8&w=1000&q=80',
                  fit: BoxFit.contain,
                  // height: 120,
                  // width: 100,
                  placeholder: (ctx, t) {
                    // return const CircularProgressIndicator();
                    return Image.asset(
                      'assets/images/Placeholder.png',
                      fit: BoxFit.contain,
                    );
                  },
                )),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: 50.sp,
                  child: Text(
                    widget.data!.productName.toString(),
                    // name!,
                    style: subtitleStyle,
                    maxLines: 2,
                    overflow: TextOverflow.fade,
                  ),
                ),
                // const SizedBox(
                //   height: 10,
                // ),
                // Text(
                //   'Size: L',
                //   style: subtitleStyle.copyWith(color: Colors.grey),
                // ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Text(
                      "Rs. ${widget.data!.price.toString()}",
                      // "Rs. $price",
                      style:
                          subtitleStyle.copyWith(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      width: 25.w,
                    ),
                  ],
                ),
              ],
            ),
            const Spacer(),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: widget.ontap,
                  icon: const Icon(
                    Icons.close,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    // Obx(
                    //   () => ElegantNumberButton(
                    //     initialValue: controller.defaultval.value,
                    //     minValue: 1,
                    //     step: 1,
                    //     maxValue: 99,
                    //     onChanged: (value) {
                    //       controller.defaultval.value = value;
                    //       controller.updateCartitem(productid, value);
                    //     },
                    //     decimalPlaces: 0,
                    //     color: AppColor.orange,
                    //   ),
                    // ),
                    buildincdecButton(Icons.remove, () {
                      setState(() {
                        if (a >= 1) {
                          a--;
                          controller.updateCartitem(widget.data?.id, a);
                        }
                      });
                    }),
                    const SizedBox(
                      width: 5,
                    ),
                    Text(
                      //  widget.data!.qty!>a?
                      // "${widget.data!.qty!.toInt() + a}",
                      a.toString(),
                      // widget.data!.qty.toString(),
                      style: subtitleStyle.copyWith(fontSize: 16.sp),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    buildincdecButton(
                      Icons.add,
                      () {
                        // print(a);
                        setState(() {
                          a++;
                        });
                        controller.updateCartitem(widget.data?.id, a);
                      },
                    ),
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  buildincdecButton(IconData icon, ontap) {
    return SizedBox(
        width: 30,
        height: 30,
        child: OutlinedButton(
            onPressed: ontap,
            style: OutlinedButton.styleFrom(
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8))),
            child: Icon(
              icon,
              size: 16.sp,
              color: Colors.black87,
            )));
  }
}
