import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/database/app_storage.dart';
import 'package:usoft/app/modules/cart/controllers/cart_controller.dart';
import 'package:usoft/app/modules/login/controllers/login_controller.dart';
import 'package:usoft/app/modules/login/views/login_view.dart';
import 'package:usoft/app/modules/search/controllers/search_controller.dart';
import 'package:usoft/app/modules/wishlist/controllers/wishlist_controller.dart';
import 'package:usoft/app/widgets/product_card.dart';

import '../../../constants/constants.dart';
import '../../../widgets/product_tile.dart';
import '../../../widgets/toast.dart';
import '../../product_detail/views/product_detail_view.dart';

class SearchResultList extends StatelessWidget {
  SearchResultList({Key? key}) : super(key: key);

  // final Category product;

  final controller = Get.put(SearchController());
  final wishlistcontroller = Get.put(WishlistController());
  final logcon = Get.put(LoginController());
  final cartController = Get.put(CartController());

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => controller.isListview.value
          ? ListView.builder(
              itemCount: controller.searchList.length,
              itemBuilder: (context, index) {
                return const ProductTile(
                  bestseller: false,
                  price: '100',
                  productImg:
                      'https://assets.adidas.com/images/w_600,f_auto,q_auto/ce8a6f3aa6294de988d7abce00c4e459_9366/Breaknet_Shoes_White_FX8707_01_standard.jpg',
                  productName: 'Addidas',
                  rating: '2',
                );
              })
          : GridView.builder(
              physics: const ClampingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio:
                    Device.orientation == Orientation.portrait ? 2.87 / 5 : 1.4,
              ),
              itemCount: controller.searchList.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                var data = controller.searchList[index];
                return Obx(
                  () => ProductCard(
                    productImg:
                        '${data.images?[0].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}',
                    productName: data.name,
                    bestseller: false,
                    price: data.getPrice?.price.toString(),
                    rating: data.rating,
                    specialprice: data.getPrice?.specialPrice.toString(),
                    ontap: () {
                      Get.to(() => ProductDetailView(
                            productname: data.name,
                            productprice: data.id.toString(),
                            productid: data.id,
                            slug: data.slug,
                          ));
                    },
                    isFav: wishlistcontroller.wishListIdArray.contains(data.id)
                        ? true
                        : false,
                    ontapFavorite: () {
                      if (logcon.logindata.value.read('USERID') != null) {
                        if (wishlistcontroller.wishListIdArray
                            .contains(data.id)) {
                          //toastMsg(message: "remove");
                          wishlistcontroller.removeFromWishList(data.id);
                          wishlistcontroller.fetchWishlist();
                        } else {
                          //toastMsg(message: "add");
                          wishlistcontroller.addToWishList(data.id);
                          wishlistcontroller.fetchWishlist();
                        }
                      } else {
                        toastMsg(message: "Please Login to add to wishlist");
                      }
                    },
                    ontapCart: () {
                      if (AppStorage.readIsLoggedIn != true) {
                        Get.off(() => LoginView());
                      } else {
                        cartController.addToCart(
                          data.id,
                          data.getPrice!.price,
                          '1',
                          data.varientId,
                        );
                      }
                    },
                    percent: data.percent == null
                        ? Container()
                        : Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 10),
                            child: Align(
                                alignment: Alignment.topLeft,
                                child: Container(
                                  alignment: Alignment.center,
                                  height: 30,
                                  width: 40,
                                  decoration: BoxDecoration(
                                      color: Colors.red,
                                      borderRadius: BorderRadius.circular(06)),
                                  child: Text(
                                    '${data.percent}%',
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )),
                          ),
                  ),
                );
              },
            ),
    );
  }
}
