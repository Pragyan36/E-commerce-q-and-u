import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/database/app_storage.dart';
import 'package:usoft/app/modules/cart/controllers/cart_controller.dart';
import 'package:usoft/app/modules/login/controllers/login_controller.dart';
import 'package:usoft/app/modules/login/views/login_view.dart';
import 'package:usoft/app/modules/search/controllers/search_controller.dart';
import 'package:usoft/app/modules/search/views/search_items.dart';
import 'package:usoft/app/modules/wishlist/controllers/wishlist_controller.dart';
import 'package:usoft/app/widgets/product_card.dart';

import '../../../constants/constants.dart';
import '../../../widgets/product_tile.dart';
import '../../../widgets/toast.dart';
import '../../product_detail/views/product_detail_view.dart';

class SuggestionList extends StatefulWidget {
  SuggestionList({Key? key}) : super(key: key);

  @override
  State<SuggestionList> createState() => _SuggestionListState();
}

class _SuggestionListState extends State<SuggestionList> {
  // final Category product;
  final controller = Get.put(SearchController());

  final wishlistcontroller = Get.put(WishlistController());

  final logcon = Get.put(LoginController());

  final cartController = Get.put(CartController());
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        itemCount: controller.searchList.length,
        itemBuilder: (context, index) {
          var data = controller.searchList[index];
          var img=data.images?[0].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url);
          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.only(left: 50.0),
              child: GestureDetector(
                onTap: () async {
                  controller.searchList.clear();
                  controller.searchtxt.text=data.name.toString();
                  controller.fetchSearch();
                  await Get.to(() => SearchItems());
                },
                child: ListTile(
                  leading:CachedNetworkImage(
                    fit: BoxFit.cover,
                    imageUrl: img.toString(),
                    placeholder: (context, url) => Container(
                      decoration: BoxDecoration(color: Colors.grey.shade300),
                      padding: const EdgeInsets.all(50),
                      child: Image.asset("assets/images/Placeholder.png"),
                    ),
                    errorWidget: (context, a, s) {
                      return Image.asset(
                        "assets/images/Placeholder.png",
                        height: 50,
                      );
                    },
                  ),
                    title: Text(
                  data!.name!,
                  style:
                      const TextStyle(fontWeight: FontWeight.w300, fontSize: 14),
                )),
              ),
            ),
          );
        });
  }
}
