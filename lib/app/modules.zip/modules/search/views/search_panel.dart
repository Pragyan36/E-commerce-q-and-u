import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/modules/landing/components/homebody.dart';
import 'package:usoft/app/modules/landing/controllers/landing_controller.dart';
import 'package:usoft/app/modules/search/components/brand_products.dart';
import 'package:usoft/app/modules/search/components/search_result.dart';
import 'package:usoft/app/modules/search/controllers/search_controller.dart';
import 'package:usoft/app/modules/search/views/qr_scanner.dart';
import 'package:usoft/app/modules/search/views/search_items.dart';
import 'package:usoft/app/modules/search/views/suggestion_page.dart';
import 'package:usoft/app/widgets/nodata.dart';

import '../../../constants/constants.dart';

class SearchPanel extends StatefulWidget {
  SearchPanel({Key? key}) : super(key: key);

  @override
  State<SearchPanel> createState() => _SearchPanelState();
}

class _SearchPanelState extends State<SearchPanel> {
  late ScrollController scrollcontroller;

  final controller = Get.put(SearchController());

  final landingcontroller = Get.put(LandingController());
   @override
  void initState() {
     controller.searchList.clear();
    super.initState();
  }
  @override
  void dispose() {
    landingcontroller.page.value = 1;
    scrollcontroller.dispose();
    controller.searchtxt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    controller.fetchAttributes();
    return WillPopScope(
        onWillPop: () async {
      Get.back();
      controller.searchtxt.clear();
      return true; // Allow back navigation
    },
    child: Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.0,
        leading:   InkWell(
          onTap: () {
            Get.back();
            controller.searchtxt.clear();
          },
          borderRadius: BorderRadius.circular(50),
          child: const Icon(
            Icons.arrow_back_ios_new_outlined,
            color: Colors.black45,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
                width: 80.w,
                height: 40,
                child: Obx(
                      () => TextField(
                    controller: controller. searchtxt,
                        onChanged: (s) {
                          if (s.endsWith(' ')) {
                            controller.fetchSearch();
                            controller.currentSearch.value = '';
                          } else {
                            controller.currentSearch.value = s;
                          }
                        },
                    textInputAction: TextInputAction.search,
                    onSubmitted: (val) {
                      if (controller.currentSearch.value.isNotEmpty) {
                        controller.fetchSearch();
                        controller.currentSearch.value = '';
                      }
                      Get.to(() => SearchItems());

                    },
                    autofocus: true,
                    decoration: InputDecoration(
                      filled: true,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                      hintText: 'Search...',
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: AppColor.orange),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.grey),
                      ),
                      suffixIcon: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              Get.to(() => const QrScannerVIew());
                            },
                            icon: const Icon(
                              Iconsax.scan_barcode,
                              color: Colors.black45,
                            ),
                          ),
                          IconButton(
                            padding: EdgeInsets.zero,
                            onPressed: () {
                              controller.listen();
                              print(controller.isListening.toString());
                              if (controller.isListening.value) {
                                // print('listening');
                              }
                            },
                            icon: Icon(
                              controller.isListening.value
                                  ? Icons.settings_voice_outlined
                                  : Icons.keyboard_voice_outlined,
                              color: controller.isListening.value ? Colors.red : Colors.black45,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                )),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Obx(() => controller.searchList.isNotEmpty
                  ? SuggestionList()
                  : NoDataView(text: "No search result")),

            ],
          ),
        ),
      ),
    ));
  }

  _buildRecentSearch(txt) {
    return ListTile(
      leading: const Icon(Icons.youtube_searched_for_outlined),
      dense: true,
      title: Text(
        txt,
        style: subtitleStyle,
      ),
      minLeadingWidth: 5,
      contentPadding: EdgeInsets.zero,
      onTap: (() => controller.searchtxt.text = txt),
    );
  }
}
