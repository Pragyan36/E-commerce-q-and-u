import 'dart:developer';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/routes/app_pages.dart';
import 'package:usoft/app/utils/validators.dart';
import 'package:usoft/app/widgets/circular_icons.dart';
import 'package:usoft/app/widgets/custom_appbar.dart';
import 'package:usoft/app/widgets/custom_buttons.dart';
import 'package:usoft/app/widgets/inputfield.dart';
import 'package:usoft/app/widgets/snackbar.dart';

import '../../../widgets/custom_button.dart';
import '../../cart/controllers/cart_controller.dart';
import '../controllers/shipping_controller.dart';
import 'package:intl/intl.dart';

class ShippingView extends GetView<ShippingController> {
  ShippingView({Key? key}) : super(key: key);

  @override
  final controller = Get.put(ShippingController());
  final _formKey = GlobalKey<FormState>();
  final cartController = Get.put(CartController());
  final _districtKey = GlobalKey<FormState>();
  final _areaKey = GlobalKey<FormState>();
  final _additionalAreaKey = GlobalKey<FormState>();
  var formatter = NumberFormat('#,###');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(title: 'Checkout'),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 20,
            ),
            Obx(
              () => Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildButton(
                      label: 'Shipping Address',
                      borderClr: controller.isShippingAddressBtnSelected.value
                          ? AppColor.orange
                          : Colors.grey.shade200,
                      txtClr: controller.isShippingAddressBtnSelected.value
                          ? AppColor.orange
                          : Colors.black,
                      ontap: () {
                        controller.isShippingAddressBtnSelected(true);
                        controller.isBillingAddressBtnSelected(false);
                      }),
                  Obx(
                    () => IgnorePointer(
                        ignoring: controller.billingSameAsShipping.isTrue
                            ? true
                            : false,
                        child: _buildButton(
                            label: 'Billing Address',
                            borderClr:
                                controller.isBillingAddressBtnSelected.value
                                    ? AppColor.orange
                                    : Colors.grey.shade200,
                            txtClr:
                                controller.isShippingAddressBtnSelected.value
                                    ? Colors.black
                                    : AppColor.orange,
                            ontap: () {
                              controller.isBillingAddressBtnSelected(true);

                              controller.isShippingAddressBtnSelected(false);
                            })),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Obx(
              () => controller.isShippingAddressBtnSelected.value

                  ///Shipping
                  ? Column(
                      children: [
                        Obx(() => controller.loading.isTrue
                            ? const CircularProgressIndicator()
                            : Column(
                                children: [
                                  controller.userShippingdetail.isNotEmpty
                                      ? ListView.builder(
                                          shrinkWrap: true,
                                          itemCount: controller
                                              .userShippingdetail.length,
                                          itemBuilder: (context, index) {
                                            var data = controller
                                                .userShippingdetail[index];
                                            return Obx(() =>
                                                _buildRadioListtile(
                                                    '${data.additionalAddress}, ${data.area}, ${data.district}, ${data.province}',
                                                    'Your shipping address',
                                                    () {
                                                      controller.fullname.text =
                                                          data.name.toString();
                                                      controller.email.text =
                                                          data.email.toString();
                                                      controller.phone.text =
                                                          data.phone.toString();
                                                      controller.additionAddress
                                                              .text =
                                                          data.additionalAddress ==
                                                                  null
                                                              ? ""
                                                              : data
                                                                  .additionalAddress
                                                                  .toString();
                                                      controller.zip.text =
                                                          data.zip == null
                                                              ? ""
                                                              : data.zip
                                                                  .toString();
                                                      _buildBottomsheet(true,
                                                          isUpdate: true,
                                                          id: data.id!.toInt());
                                                    },
                                                    () {
                                                      controller
                                                          .deleteShippingAddress(
                                                              data.id!.toInt());
                                                    },
                                                    data.id!.toInt(),
                                                    controller
                                                        .shippingAddressSelectedId
                                                        .value,
                                                    (val) {
                                                      controller
                                                          .shippingAddressSelectedId
                                                          .value = val;
                                                      controller.charge.value =
                                                          data.charge!;
                                                    }));
                                          },
                                        )
                                      : Padding(
                                          padding: const EdgeInsets.all(20.0),
                                          child: Text(
                                            'Empty Address',
                                            style: subtitleStyle,
                                          ),
                                        ),
                                  IconButton(
                                      onPressed: () {
                                        _buildBottomsheet(true);
                                      },
                                      splashColor: AppColor.orange,
                                      padding: EdgeInsets.zero,
                                      icon: Icon(
                                        Icons.add_circle_outline_rounded,
                                        color: Colors.grey.shade500,
                                        size: 50,
                                      )),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    'Add Shipping Address',
                                    style: subtitleStyle,
                                  )
                                ],
                              )),
                        const SizedBox(
                          height: 20,
                        ),
                        /* TextButton(
                            onPressed: () {},
                            child: Text(
                              'Different Shipping Address',
                              style: titleStyle,
                            )),*/
                      ],
                    )

                  ///Billing
                  : Column(
                      children: [
                        Obx(() => controller.loading.isTrue
                                ? const CircularProgressIndicator()
                                : Column(
                                    children: [
                                      controller.userBillingDetail.isNotEmpty
                                          ? ListView.builder(
                                              itemCount: controller
                                                  .userBillingDetail.length,
                                              shrinkWrap: true,
                                              itemBuilder: (context, index) {
                                                var data = controller
                                                    .userBillingDetail[index];
                                                return Obx(() =>
                                                    _buildRadioListtile(
                                                        '${data.additionalAddress}, ${data.area}, ${data.district}, ${data.province}',
                                                        'Your billing address',
                                                        () async {
                                                          controller
                                                                  .fullnameBilling
                                                                  .text =
                                                              data.name
                                                                  .toString();
                                                          controller
                                                                  .emailBilling
                                                                  .text =
                                                              data.email
                                                                  .toString();
                                                          controller
                                                                  .phoneBilling
                                                                  .text =
                                                              data.phone
                                                                  .toString();
                                                          controller
                                                                  .additionAddressBilling
                                                                  .text =
                                                              data.additionalAddress
                                                                  .toString();
                                                          controller.zipBilling
                                                                  .text =
                                                              data.zip
                                                                  .toString();
                                                          _buildBottomsheet(
                                                              false,
                                                              isUpdate: true,
                                                              id: data.id!
                                                                  .toInt());
                                                        },
                                                        () {
                                                          controller
                                                              .deleteBillingAddress(
                                                                  data.id!
                                                                      .toInt());
                                                        },
                                                        data.id!.toInt(),
                                                        controller
                                                            .billingAddressSelectedId
                                                            .value,
                                                        (val) {
                                                          controller
                                                                  .billingAddressSelectedId
                                                                  .value =
                                                              int.parse(val
                                                                  .toString());
                                                          log(data.id
                                                              .toString());
                                                        }));
                                              },
                                            )
                                          : Padding(
                                              padding:
                                                  const EdgeInsets.all(20.0),
                                              child: Text(
                                                'Empty Address',
                                                style: subtitleStyle,
                                              ),
                                            ),
                                      IconButton(
                                          onPressed: () {
                                            _buildBottomsheet(false);
                                          },
                                          padding: EdgeInsets.zero,
                                          splashColor: AppColor.orange,
                                          icon: Icon(
                                            Icons.add_circle_outline_rounded,
                                            color: Colors.grey.shade500,
                                            size: 50,
                                          )),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        'Add Billing Address',
                                        style: subtitleStyle,
                                      )
                                    ],
                                  )
                            //  _buildRadioListtile(
                            //     controller.userBillingDetail.value
                            //                     .district ==
                            //                 null ||
                            //             controller.userBillingDetail.value
                            //                     .area ==
                            //                 null ||
                            //             controller.userBillingDetail.value
                            //                     .province ==
                            //                 null
                            //         ? 'Add Address'
                            //         : "${controller.userBillingDetail.value.name}, ${controller.userBillingDetail.value.area}, ${controller.userBillingDetail.value.province}",
                            //     "Your Billing address",
                            //     Iconsax.edit, () {
                            //     controller.onInit();
                            //     _buildBottomsheet(false);
                            //   }),
                            ),
                        /* ...List.generate(
                          2,
                          (index) => _buildRadioListtile(
                              '41441 Parker Rd, Allentown',
                              'Sundhara, Ktm ',
                              Iconsax.edit,
                              () {}),
                        ),*/
                        const SizedBox(
                          height: 10,
                        ),
                        /*TextButton(
                            onPressed: () {
                              // Get.to(() => AddNewAddress());
                            },
                            child: Text(
                              '+ Add new address', //For Different Address
                              style: titleStyle,
                            )),*/
                      ],
                    ),
            ),
            // CheckboxListTile(
            //   title: Text(
            //     'Billing address is the same as my shipping address',
            //     style: subtitleStyle,
            //   ),

            //   value: true,
            //   onChanged: (val) {},
            // ),
            ListTile(
              leading: Obx(
                () => Checkbox(
                    activeColor: AppColor.orange,
                    value: controller.billingSameAsShipping.value,
                    onChanged: (val) {
                      controller.billingSameAsShipping.value = val!;
                    }),
              ),
              title: Text(
                'Billing address is the same as my shipping address',
                style: subtitleStyle,
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 5),
              minLeadingWidth: 10,
              horizontalTitleGap: 10,
            ),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  _buildAmountTile(
                    'Sub-total',
                    'Rs.${formatter.format(cartController.cartSummary.value.totalAmount)}',
                  ),
                  _buildAmountTile(
                    'Vat(%)',
                    '${formatter.format(cartController.cartSummary.value.vat)}',
                  ),
                  Obx(() => _buildAmountTile(
                        'Shipping Change',
                        'Rs.${formatter.format(controller.charge.value)} ',
                      )),
                  const Divider(
                    thickness: 1.5,
                    indent: 20,
                    endIndent: 20,
                  ),
                  Obx(
                    () => _buildAmountTile(
                      'Total',
                      'Rs. ${formatter.format(cartController.cartSummary.value.grandTotal! + controller.charge.value)}',
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        padding: const EdgeInsets.symmetric(vertical: 30),
        child: SizedBox(
          width: MediaQuery.of(context).size.width - 20,
          child: CustomButton(
              label: 'Continue',
              btnClr: AppColor.orange,
              txtClr: Colors.white,
              ontap: () {
                /*If Billing is same as shipping*/
                if (controller.billingSameAsShipping.value) {
                  if (controller.userShippingdetail.isNotEmpty) {
                    Get.toNamed(Routes.PAYMENT, arguments: [
                      controller.shippingAddressSelectedId,
                      controller.billingAddressSelectedId,
                      controller.billingSameAsShipping,
                      controller.charge.value
                    ]);
                  } else {
                    getSnackbar(message: 'Please add shipping address first');
                  }
                }
                /*If Billing is not same as shipping*/
                else {
                  if (controller.userShippingdetail.isNotEmpty &&
                      controller.userBillingDetail.isNotEmpty) {
                    Get.toNamed(Routes.PAYMENT, arguments: [
                      controller.shippingAddressSelectedId,
                      controller.billingAddressSelectedId,
                      controller.billingSameAsShipping,
                      controller.charge.value
                    ]);
                  } else {
                    getSnackbar(
                        message: 'Please add shipping and billing address',
                        error: true,
                        bgColor: Colors.red);
                  }
                }
              }),
        ),
      ),
    );
  }

  _buildButton({label, borderClr, txtClr, ontap}) {
    return MaterialButton(
      color: Colors.white,
      height: 50,
      elevation: 0,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: borderClr, width: 1)),
      onPressed: ontap,
      child: Text(
        label,
        style: subtitleStyle.copyWith(color: txtClr),
      ),
    );
  }

  _buildRadioListtile(
      title, subtitle, ontap, ondelete, Object value, grpvalue, onChanged) {
    return RadioListTile(
      title: Text(
        title,
        style: subtitleStyle,
      ),
      selectedTileColor: AppColor.orange,
      activeColor: AppColor.orange,
      subtitle: Text(
        subtitle,
        style: subtitleStyle.copyWith(color: Colors.grey),
      ),
      secondary: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(onPressed: ontap, icon: const Icon(Iconsax.edit)),
          IconButton(onPressed: ondelete, icon: const Icon(Iconsax.trash)),
        ],
      ),
      value: value,
      groupValue: grpvalue,
      onChanged: onChanged,
    );
  }

  _buildAmountTile(title, total) {
    return ListTile(
      dense: true,
      visualDensity: const VisualDensity(vertical: -3),
      title: Text(
        title,
        style: subtitleStyle.copyWith(color: Colors.grey),
      ),
      trailing: Text(
        total,
        style: subtitleStyle.copyWith(fontWeight: FontWeight.w500),
      ),
    );
  }

  void _buildBottomsheet(isShipping, {bool isUpdate = false, int id = 0}) {
    Get.bottomSheet(
      isScrollControlled: true,
      ignoreSafeArea: false,
      Container(
        decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            )),
        child: WillPopScope(
          /*Since on Dismiss of BottomSheet everything should get cleared*/
          /*This is used to clear areas and district dropdown*/
          onWillPop: () async {
            bool isBottomSheetOpen = true;
            isBottomSheetOpen = Get.isBottomSheetOpen!;
            if (isBottomSheetOpen) {
              clearAndResetAdditionalAddress();
              controller.goBackAndClearDropDown();
            } else {
              log("Bottom Sheet is not open");
            }
            return isBottomSheetOpen;
          },
          child: SingleChildScrollView(
            child: Container(
              // height: 500,

              padding: const EdgeInsets.all(20),
              child: SafeArea(
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CustomCircularIcon(),
                      Text(
                        'Full Name',
                        style: subtitleStyle,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      MyInputField(
                        hint: 'Full name',
                        controller: isShipping
                            ? controller.fullname
                            : controller.fullnameBilling,
                        validator: (v) => validateIsEmpty(string: v),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Email',
                        style: subtitleStyle,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      MyInputField(
                          validator: (v) => validateEmail(string: v),
                          hint: 'Email',
                          controller: isShipping
                              ? controller.email
                              : controller.emailBilling),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Phone',
                        style: subtitleStyle,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      MyInputField(
                          validator: (v) => validatePhone(string: v),
                          hint: 'Phone',
                          inputType: TextInputType.number,
                          controller: isShipping
                              ? controller.phone
                              : controller.phoneBilling),
                      const SizedBox(
                        height: 10,
                      ),
                      /*==================*/
                      _buildAddressSelector(isShipping),
                      /*==================*/
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Additional Address',
                        style: subtitleStyle,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Form(
                        key: _additionalAreaKey,
                        child: MyInputField(
                          ontap: () {
                            log('object');
                            Get.defaultDialog(
                                title: 'Select Additional Address',
                                content: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: List.generate(
                                      controller.shippingCharge.length,
                                      (index) => ListTile(
                                            title: Text(
                                              controller
                                                  .shippingCharge[index].title
                                                  .toString(),
                                            ),
                                            onTap: () {
                                              if (isShipping) {
                                                controller
                                                        .additionAddress.text =
                                                    controller
                                                        .shippingCharge[index]
                                                        .title
                                                        .toString();
                                                controller.areaId.text =
                                                    controller
                                                        .shippingCharge[index]
                                                        .id
                                                        .toString();
                                              } else {
                                                controller
                                                        .additionAddressBilling
                                                        .text =
                                                    controller
                                                        .shippingCharge[index]
                                                        .title
                                                        .toString();
                                                controller.areaIdBilling.text =
                                                    controller
                                                        .shippingCharge[index]
                                                        .id
                                                        .toString();
                                              }

                                              log(controller
                                                  .shippingCharge[index].id
                                                  .toString());
                                              Get.back();
                                            },
                                          )),
                                ));
                          },
                          hint: 'Additional Address',
                          validator: (v) => validateIsEmpty(string: v),
                          inputType: TextInputType.none,
                          controller: isShipping
                              ? controller.additionAddress
                              : controller.additionAddressBilling,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Zip',
                        style: subtitleStyle,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      MyInputField(
                          inputType: TextInputType.number,
                          validator: (v) => isShipping
                              ? validateIsEmpty(string: v)
                              : validateNothing(string: v),
                          hint: 'Zip',
                          controller: isShipping
                              ? controller.zip
                              : controller.zipBilling),
                      const SizedBox(
                        height: 10,
                      ),
                      isUpdate
                          ? CustomButtons(
                              width: double.infinity,
                              label: 'Update',
                              btnClr: AppColor.orange,
                              txtClr: Colors.white,
                              ontap: () async {
                                if (!_formKey.currentState!.validate()) {
                                  return;
                                }
                                if (!_districtKey.currentState!.validate()) {
                                  return;
                                }
                                if (!_areaKey.currentState!.validate()) {
                                  return;
                                }

                                if (isShipping) {
                                  if (!_additionalAreaKey.currentState!
                                      .validate()) {
                                    return;
                                  }
                                } else {
                                  //doNothing because additional address is not required in billing
                                }

                                if (isShipping) {
                                  controller.updateShippingAddress(id);
                                } else {
                                  controller.updateBillingAddress(id);
                                }
                              })
                          : CustomButtons(
                              width: double.infinity,
                              label: 'Confirm',
                              btnClr: AppColor.orange,
                              txtClr: Colors.white,
                              ontap: () {
                                if (!_formKey.currentState!.validate()) {
                                  return;
                                }
                                if (!_districtKey.currentState!.validate()) {
                                  return;
                                }
                                if (!_areaKey.currentState!.validate()) {
                                  return;
                                }
                                if (isShipping) {
                                  if (!_additionalAreaKey.currentState!
                                      .validate()) {
                                    return;
                                  }
                                } else {
                                  //doNothing because additional address is not required in billing
                                }

                                if (isShipping) {
                                  controller.loadinshipping.value
                                      ? null
                                      : controller.addShippingAddress();
                                  controller.onInit();
                                } else {
                                  log("Confirm Button Pressed: isNotShipping");
                                  controller.loadinshipping.value
                                      ? null
                                      : controller.addBillingAddress();
                                  controller.onInit();
                                }
                              })
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  _buildAddressSelector(isShipping) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Province',
          style: subtitleStyle,
        ),
        const SizedBox(
          height: 5,
        ),
        Obx(
          () => DropdownButtonFormField2(
            decoration: InputDecoration(
              fillColor: Colors.grey.shade300.withOpacity(0.4),
              filled: true,
              isDense: true,
              contentPadding:
                  const EdgeInsets.only(left: 0, right: 0, top: 5, bottom: 5),
              enabledBorder: OutlineInputBorder(
                borderSide: const BorderSide(
                  color: Colors.transparent,
                  width: 0,
                ),
                borderRadius: BorderRadius.circular(5),
              ),
            ),
            isExpanded: true,
            hint: Text(
              'Select Province',
              style: subtitleStyle,
            ),
            icon: const Icon(
              Icons.arrow_drop_down,
              color: Colors.black45,
            ),
            iconSize: 30,
            buttonHeight: 50,
            buttonPadding: const EdgeInsets.only(left: 20, right: 10),
            dropdownDecoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
            ),
            items: controller.shippingAddressList
                .map((item) => DropdownMenuItem<String>(
                      value: item.id.toString(),
                      onTap: () {
                        controller.selectedProvinceNameShipping =
                            item.id.toString();
                        _districtKey.currentState!.reset();
                        _areaKey.currentState!.reset();

                        controller.districtsShipping.clear();
                        controller.areasShipping.clear();

                        clearAndResetAdditionalAddress();
                        log("selectedProvinceNameShipping${controller.selectedProvinceNameShipping}");
                      },
                      child: Text(
                        item.engName.toString(),
                        style: const TextStyle(
                          fontSize: 14,
                        ),
                      ),
                    ))
                .toList(),
            validator: (value) {
              if (value == null) {
                return 'Please select province.';
              }
            },
            onChanged: (value) {
              _districtKey.currentState!.reset();
              _areaKey.currentState!.reset();
              controller.districtsShipping.clear();
              clearAndResetAdditionalAddress();

              controller.shippingAddressList[int.parse(value.toString()) - 1]
                  .districts
                  ?.forEach((element) {
                controller.districtsShipping.add(element);
              });
            },
            onSaved: (v) {},
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Text(
          'District',
          style: subtitleStyle,
        ),
        const SizedBox(
          height: 5,
        ),
        Obx(
          () => Form(
              key: _districtKey,
              child: DropdownButtonFormField2(
                decoration: InputDecoration(
                  fillColor: Colors.grey.shade300.withOpacity(0.4),
                  filled: true,
                  isDense: true,
                  contentPadding: const EdgeInsets.only(
                      left: 0, right: 0, top: 5, bottom: 5),
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
                isExpanded: true,
                hint: Text(
                  'Select District',
                  style: subtitleStyle,
                ),
                icon: const Icon(
                  Icons.arrow_drop_down,
                  color: Colors.black45,
                ),
                iconSize: 30,
                buttonHeight: 50,
                buttonPadding: const EdgeInsets.only(left: 20, right: 10),
                dropdownDecoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                ),
                items: controller.districtsShipping
                    .map((item) => DropdownMenuItem<String>(
                          onTap: () {
                            controller.selectedDistrictNameShipping =
                                item.id.toString();
                            clearAndResetAdditionalAddress();
                            log("selectedDistrictNameShipping:${controller.selectedDistrictNameShipping}");
                          },
                          value: item.id.toString(),
                          child: Text(
                            item.npName.toString(),
                            style: const TextStyle(
                              fontSize: 14,
                            ),
                          ),
                        ))
                    .toList(),
                validator: (value) {
                  if (value == null) {
                    return 'Please select district.';
                  }
                },
                onChanged: (value) {
                  _areaKey.currentState!.reset();

                  clearAndResetAdditionalAddress();

                  controller.selectedDistrictShipping
                      .addAll(controller.districtsShipping);

                  controller.selectedDistrictShipping.retainWhere(
                      (element) => element.id == int.parse(value.toString()));
                  controller.areasShipping.clear();

                  controller.selectedDistrictShipping[0].localarea
                      ?.forEach((element) {
                    controller.areasShipping.add(element);
                  });
                },
                onSaved: (v) {},
              )),
        ),
        const SizedBox(
          height: 10,
        ),
        Text(
          'Area',
          style: subtitleStyle,
        ),
        const SizedBox(
          height: 5,
        ),
        Obx(
          () => Form(
              key: _areaKey,
              child: DropdownButtonFormField2(
                decoration: InputDecoration(
                  fillColor: Colors.grey.shade300.withOpacity(0.4),
                  filled: true,
                  isDense: true,
                  contentPadding: const EdgeInsets.only(
                      left: 0, right: 0, top: 5, bottom: 5),
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
                isExpanded: true,
                hint: Text(
                  'Select Area',
                  style: subtitleStyle,
                ),
                icon: const Icon(
                  Icons.arrow_drop_down,
                  color: Colors.black45,
                ),
                iconSize: 30,
                buttonHeight: 50,
                buttonPadding: const EdgeInsets.only(left: 20, right: 10),
                dropdownDecoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                ),
                items: controller.areasShipping
                    .map((item) => DropdownMenuItem<String>(
                          onTap: () {
                            controller.selectedAreaNameShipping =
                                item.localName.toString();
                            clearAndResetAdditionalAddress();
                            log("selectedAreaNameShipping:${controller.selectedAreaNameShipping}");
                          },
                          value: item.id.toString(),
                          child: Text(
                            item.localName.toString(),
                            style: const TextStyle(
                              fontSize: 14,
                            ),
                          ),
                        ))
                    .toList(),
                validator: (value) {
                  if (value == null) {
                    return 'Please select area.';
                  }
                },
                onChanged: (v) async {
                  clearAndResetAdditionalAddress();
                  await controller.getShippingCharge(v);
                },
                onSaved: (v) {},
              )),
        ),
      ],
    );
  }

  void clearAndResetAdditionalAddress() {
    controller.shippingCharge.clear();
    _additionalAreaKey.currentState!.reset();
    controller.shippingCharge.clear();
    controller.additionAddress.text = "";
    controller.additionAddressBilling.text = "";
  }
}
