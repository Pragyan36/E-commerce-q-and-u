import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:usoft/app/data/models/product_detail_model.dart';
import 'package:usoft/app/data/models/question_ans_model.dart';
import 'package:usoft/app/data/models/review_model.dart';
import 'package:usoft/app/data/services/product_service.dart';
import 'package:usoft/app/data/services/review_service.dart';
import 'package:usoft/app/modules/login/controllers/login_controller.dart';
import 'package:usoft/app/widgets/snackbar.dart';

import '../../../database/app_storage.dart';

class ProductDetailController extends GetxController {
  final count = 1.obs;
  var selectedindex = 0.obs;
  var selectedimg = 1.obs;

  // var selectedRam = "".obs;
  var selectedVarientId = 0.obs;
  var selectedColor = 0.obs;
  var selectedVariantQty = 0.obs;
  var specialPrice = 0.obs;
  var price = 0.obs;
  var sellerName = ''.obs;

  // var specialPrice = 0.obs;
  var loading = false.obs;
  var loadingReview = false.obs;

  var productId = 0.obs;
  var showLongDesc = false.obs;

  var ignorePointer = false.obs;
  final String TAG = "ProductDetailController";

  var productdetail = ProductDetailData().obs;
  var tabIndex = "1".obs;

  // var stockwise = <StockWise>[].obs;
  var reviewList = <ReviewHeadingModel>[].obs;
  var questionAnsList = <QuestionAnswerData>[].obs;

  final Logincon = Get.put(LoginController());

  final qna = TextEditingController();

  var myData;

  var dummyColor = [
    {'id': 0, 'color': const Color(0xFFE8EAF6)},
    {'id': 1, 'color': const Color(0xFF7E57C2)},
    {'id': 2, 'color': const Color(0xFF26C6DA)}
  ];

  @override
  void onInit() {
    selectedindex.value == 0;
    selectedimg.value == 0;

    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() {
    if (count > 0 && count < selectedVariantQty.value) {
      count.value++;
    }
  }

  void decrement() {
    if (count > 1) {
      count.value--;
    }
  }

  var selectedColorCode = ''.obs;

  fetchProductDetail(slug) async {
    log("ProductDetailController:fetchProductDetail");
    loading(true);
    var data = await ProductService().getProductDetail(slug);
    myData = data;
    // log("SKT:withJsonDecode:insideController:$data");
    // log(data.toString());
    if (data != null) {
      loading(false);
      productdetail.value = ProductDetailData.fromJson(data['data']);
      productId.value = productdetail.value.id!
          .toInt(); //will be used to fetch other color variants

      selectedColor.value = productdetail.value.colors![0].id!.toInt();
      selectedColorCode.value = productdetail.value.colors![0].code.toString();

      selectedVarientId.value = productdetail.value.selectedData![0].id!;
      selectedVariantQty.value = productdetail.value.selectedData![0].quantity!;

      //this count variable is used to show the value in quantity increment and decrement
      count.value = selectedVariantQty.value > 0 ? 1 : 0;

      price.value = productdetail.value.selectedData![0].price!;
      sellerName.value = productdetail.value.sellerName!;
      if (productdetail.value.selectedData![0].specialPrice != null) {
        specialPrice.value = productdetail.value.selectedData![0].specialPrice!;
      }
    }
    // log("selectedColor::${productdetail.value.colors?[0].id}");
    fetchProductAttribute(productdetail.value.colors?[0].id, productId.value);
  }

  var productattributesData;

  // = <SelectedData>[].obs;
  var productAttributeLoading = false.obs;
  var hasData = false.obs;

  fetchProductAttribute(colorId, productId) async {
    productAttributeLoading(true);

    log("ProductDetailController:fetchProductAttribute:colorId:$colorId, productId:$productId");
    var data = await ProductService().getProductAttribute(
        {"color_id": "$colorId", "product_id": "$productId"});
    if (data != null) {
      hasData(true);
      productAttributeLoading(false);

      productattributesData = data;
    }

    selectedVarientId.value =
        int.parse(productattributesData['data'][0]['id'].toString());
    selectedVariantQty.value =
        int.parse(productattributesData['data'][0]['quantity'].toString());

    price.value =
        int.parse(productattributesData['data'][0]['price'].toString());
    sellerName.value = productdetail.value.sellerName!;
    if (productattributesData['data'][0]['special_price'] != null) {
      specialPrice.value = int.parse(
          productattributesData['data'][0]['special_price'].toString());
    }
  }

  fetchReviews(int? productid) async {
    loadingReview.value = true;
    var data = await ReviewService().getReviews(productid);

    try {
      if (data != null) {
        loadingReview.value = false;
        if (kDebugMode) {
          print(data);
        }
        reviewList.clear();
        data['data']
            .forEach((v) => reviewList.add(ReviewHeadingModel.fromJson(v)));
      }
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    } finally {
      loadingReview.value = false;
    }
  }

  fetchQuesAns(productid) async {
    log("fetchQuesAns:productid:$productId");

    if (AppStorage.readIsLoggedIn == true) {
      log("LOGGED IN");
      log("LOGGED IN:fetchQuesAns:productid:$productId");
      var data = await ProductService()
          .getUserQuesAns(AppStorage.readAccessToken, productid);
      if (data != null) {
        if (data['error'] == false) {
          questionAnsList.clear();
          data['data'].forEach(
              (v) => questionAnsList.add(QuestionAnswerData.fromJson(v)));
        }
        log("questionAnsList.length2: ${questionAnsList.length}");
      }
    } else {
      log("!LOGGED IN");
      var data = await ProductService().getQuesAns(productid);
      if (data != null) {
        if (data['error'] == false) {
          questionAnsList.clear();
          data['data'].forEach(
              (v) => questionAnsList.add(QuestionAnswerData.fromJson(v)));
        }
      }
      log("questionAnsList.length3: ${questionAnsList.length}");
    }
  }

  postQues(productid) async {
    var data = await ProductService()
        .postQues(AppStorage.readAccessToken, productid, qna.text);
    print(data);

    if (data != null) {
      if (data['error'] == false) {
        getSnackbar(message: 'Question added');
        Get.back();
      }
    }
  }
}
