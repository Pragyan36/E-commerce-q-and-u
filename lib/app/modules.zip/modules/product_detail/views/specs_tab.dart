import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/modules/product_detail/controllers/product_detail_controller.dart';
import 'package:usoft/app/widgets/nodata.dart';

import '../../../constants/constants.dart';

class SpecificationTab extends StatefulWidget {
  const SpecificationTab({
    Key? key,
  }) : super(key: key);

  @override
  State<SpecificationTab> createState() => _SpecificationTabState();
}

class _SpecificationTabState extends State<SpecificationTab> {
  final controller = Get.put(ProductDetailController());

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Table(children: [
          TableRow(children: [
            const Center(
              child: Padding(
                padding: EdgeInsets.all(12.0),
                child: Text(
                  "Brand",
                  style: TextStyle(fontSize: 13.0, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(controller
                          .productdetail.value.specificationData?.brand ==
                      null
                  ? "Not Specified"
                  : controller.productdetail!.value!.specificationData!.brand!),
            ),
          ]),
          TableRow(children: [
            const Center(
              child: Padding(
                padding: EdgeInsets.all(12.0),
                child: Text(
                  "Color",
                  style: TextStyle(fontSize: 13.0, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(controller
                          .productdetail.value.specificationData?.color ==
                      null
                  ? "Not Specified"
                  : controller.productdetail!.value!.specificationData!.color!),
            ),
          ]),
        ]),
        controller.productdetail.value.specificationData!.specification != null
            ? Row(
                children: [
                  SizedBox(
                    width: 51,
                  ),
                  HtmlWidget(controller
                      .productdetail.value.specificationData!.specification
                      .toString()),
                ],
              )
            : SizedBox()
      ],
    );
  }
}
