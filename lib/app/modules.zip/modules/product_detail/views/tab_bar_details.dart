import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/modules/product_detail/controllers/product_detail_controller.dart';
import 'package:usoft/app/widgets/nodata.dart';

import '../../../constants/constants.dart';

class ProductDetailsTab extends StatefulWidget {
  const ProductDetailsTab({
    Key? key,
  }) : super(key: key);

  @override
  State<ProductDetailsTab> createState() => _ProductDetailsTabState();
}

class _ProductDetailsTabState extends State<ProductDetailsTab> {
  final controller = Get.put(ProductDetailController());

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Obx(
          () => HtmlWidget(
            controller.showLongDesc.isTrue
                ? controller.productdetail.value.longDescription.toString()
                : controller.productdetail.value.shortDescription.toString(),
          ),
        ),
      ],
    );
  }
}
