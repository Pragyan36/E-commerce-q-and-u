import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/modules/product_detail/controllers/product_detail_controller.dart';
import 'package:usoft/app/widgets/nodata.dart';

import '../../../constants/constants.dart';
import '../../../database/app_storage.dart';
import '../../../utils/validators.dart';
import '../../../widgets/circular_icons.dart';
import '../../../widgets/custom_button.dart';
import '../../../widgets/inputfield.dart';
import '../../../widgets/snackbar.dart';
import '../components/qna_view.dart';

class ReviewTab extends StatefulWidget {
  const ReviewTab({
    Key? key,
  }) : super(key: key);

  @override
  State<ReviewTab> createState() => _ReviewTabState();
}

class _ReviewTabState extends State<ReviewTab> {
  final controller = Get.put(ProductDetailController());
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Question about this product',
              style: titleStyle,
            ),
            GestureDetector(
              onTap: () {
                Get.to(() => QnAView(
                      id: controller.productdetail.value.id!.toInt(),
                    ));
              },
              child: Text(
                'View all',
                style: subtitleStyle.copyWith(color: AppColor.orange),
              ),
            )
          ],
        ),
        Obx(() => controller.questionAnsList.isNotEmpty
            ? ListView.builder(
                shrinkWrap: true,
                itemCount: controller.questionAnsList.length >= 2 ? 2 : 1,
                itemBuilder: (context, index) {
                  var data = controller.questionAnsList[index];

                  return Column(
                    children: [
                      _buildQueAnsTile(
                          questions: true,
                          ques: data.questionAnswer,
                          name: data.user?.name),
                      controller.questionAnsList[index].answer
                                  ?.questionAnswer ==
                              null
                          ? Container()
                          : _buildQueAnsTile(
                              questions: false,
                              ques: data.answer?.questionAnswer,
                              name: data.user?.name),
                    ],
                  );
                })
            : const Text('')),
        Center(
          child: TextButton(
            onPressed: () {
              // controller.fetchQuesAns(
              //     controller.productdetail.value.id);
              if (AppStorage.readIsLoggedIn != true) {
                getSnackbar(message: "Please Login to ask a question.");
                return;
              }

              Get.bottomSheet(Container(
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                    )),
                padding: const EdgeInsets.all(20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CustomCircularIcon(),
                      const SizedBox(
                        height: 10,
                      ),
                      MyInputField(
                        hint: 'Question',
                        controller: controller.qna,
                        validator: (v) => validateIsEmpty(string: v),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Center(
                        child: CustomButton(
                            label: 'Submit',
                            btnClr: AppColor.orange,
                            txtClr: Colors.white,
                            ontap: () async {
                              // log('object');
                              Get.back();

                              if (_formKey.currentState!.validate()) {
                                await controller.postQues(
                                  controller.productdetail.value.id,
                                );
                                controller.fetchQuesAns(
                                    controller.productdetail.value.id);
                              }
                            }),
                      ),
                      const SizedBox(
                        height: 50,
                      ),
                    ],
                  ),
                ),
              ));
            },
            child: Text(
              'Ask a question',
              style: titleStyle.copyWith(color: AppColor.orange),
            ),
          ),
        ),
      ],
    );
  }

  _buildQueAnsTile({required bool questions, ques, name}) {
    return ListTile(
      dense: true,
      visualDensity: const VisualDensity(horizontal: 0, vertical: -4),
      leading: CircleAvatar(
        backgroundColor: questions ? AppColor.orange : Colors.grey,
        radius: 12,
        child: Text(
          questions ? 'Q' : 'A',
          style: subtitleStyle.copyWith(color: Colors.white),
        ),
      ),
      // minVerticalPadding: -10,
      contentPadding: EdgeInsets.zero,
      minLeadingWidth: 5,
      title: Text(
        ques ?? 'null',
        style: subtitleStyle,
      ),
      subtitle: Text(
        name ?? 'null',
        style: subtitleStyle.copyWith(fontSize: 12.sp),
      ),
    );
  }
}
