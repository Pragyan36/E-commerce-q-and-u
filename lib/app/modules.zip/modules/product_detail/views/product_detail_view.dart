import 'dart:developer';

import 'package:badges/badges.dart' as bag;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';
import 'package:get/get.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/database/app_storage.dart';
import 'package:usoft/app/modules/cart/controllers/cart_controller.dart';
import 'package:usoft/app/modules/cart/views/cart_view.dart';
import 'package:usoft/app/modules/login/controllers/login_controller.dart';
import 'package:usoft/app/modules/login/views/login_view.dart';
import 'package:usoft/app/modules/product_detail/components/qna_view.dart';
import 'package:usoft/app/modules/product_detail/views/review_tab.dart';
import 'package:usoft/app/modules/product_detail/views/specs_tab.dart';
import 'package:usoft/app/modules/product_detail/views/tab_bar_details.dart';
import 'package:usoft/app/modules/product_detail/views/user_reviews_view.dart';
import 'package:usoft/app/modules/wishlist/controllers/wishlist_controller.dart';
import 'package:usoft/app/utils/validators.dart';
import 'package:usoft/app/widgets/circular_icons.dart';
import 'package:usoft/app/widgets/custom_button.dart';
import 'package:usoft/app/widgets/custom_buttons.dart';
import 'package:usoft/app/widgets/custom_shimmer.dart';
import 'package:usoft/app/widgets/snackbar.dart';

import '../../../widgets/inputfield.dart';
import '../controllers/product_detail_controller.dart';

class ProductDetailView extends StatefulWidget {
  const ProductDetailView(
      {this.productname,
      this.productprice,
      this.slug,
      Key? key,
      this.productid})
      : super(key: key);

  final String? productname;
  final String? productprice;
  final int? productid;
  final String? slug;

  @override
  State<ProductDetailView> createState() => _ProductDetailViewState();
}

class _ProductDetailViewState extends State<ProductDetailView>
    with SingleTickerProviderStateMixin {
  final buttonCarouselController = CarouselController();

  final controller = Get.put(ProductDetailController());
  final cartcontroller = Get.put(CartController());
  final wishcontroller = Get.put(WishlistController());
  final logcon = Get.put(LoginController());
  final _formKey = GlobalKey<FormState>();
  late TabController _tabController;

  // final List<Map> productImg = [
  //   {'img': AppImages.shoes, 'id': 0},
  //   {'img': AppImages.logo, 'id': 1},
  //   {'img': AppImages.shoes, 'id': 2},
  //   {'img': AppImages.shoes, 'id': 3},
  // ];

  // final List<Map> sizes = [
  //   {'size': 'S', 'id': 0},
  //   {'size': 'M', 'id': 1},
  //   {'size': 'L', 'id': 2},
  //   {'size': 'XL', 'id': 3},
  //   {'size': 'XXL', 'id': 4},
  // ];

  late int colorcode;

  @override
  void initState() {
    log("productId::${widget.productid}, productSlug::${widget.slug}");
    _tabController = TabController(length: 3, vsync: this);
    fetchAll();
    super.initState();
  }

  fetchAll() async {
    await controller.fetchProductDetail(widget.slug);
    log("ProductDetailView:fetchAll:widget.productid:${widget.productid}");
    controller.fetchQuesAns(controller.productdetail.value.id);
    log("colorsselects${controller.productdetail.value.colors}");
    controller.fetchReviews(controller.productdetail.value.id?.toInt());
    controller.selectedColorCode.value = "#92eebb";
  }

  buildDetailsTop(context) {
    return Container(
      height: Device.orientation == Orientation.portrait
          ? MediaQuery.of(context).size.height / 2 - 100
          : MediaQuery.of(context).size.height / 2,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 20),
      color: Colors.white,
      child: Stack(
        children: [
          Obx(() => controller.productdetail.value.image != null
              ? CarouselSlider(
                  carouselController: buttonCarouselController,
                  items: [
                    ...List.generate(
                        controller.productdetail.value.image!.length, (index) {
                      return CachedNetworkImage(
                        imageUrl:
                            '${controller.productdetail.value.image![index].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}',
                        placeholder: (context, url) => Padding(
                          padding: const EdgeInsets.all(50),
                          child: Image.asset("assets/images/Placeholder.png"),
                        ),
                        errorWidget: (context, url, error) =>
                            const Icon(Icons.error),
                        fit: BoxFit.fitHeight,
                      );
                    })
                  ],
                  options: CarouselOptions(
                      initialPage:
                          // 0,
                          controller.selectedimg.value,
                      autoPlay: true,
                      autoPlayCurve: Curves.fastOutSlowIn,
                      viewportFraction: 3,
                      onPageChanged: (i, reason) {
                        controller.selectedimg.value = i;
                        // log("Carousel Position: $i");
                      }),
                )
              : Container()),
          Positioned(
            top: 0,
            right: 60,
            child: MaterialButton(
                clipBehavior: Clip.hardEdge,
                enableFeedback: false,
                shape: const CircleBorder(),
                color: Colors.white,
                height: 45,
                child: Icon(
                  Icons.favorite,
                  size: 22,
                  color: wishcontroller.wishListIdArray
                          .contains(controller.productdetail.value.id)
                      ? Colors.green
                      : Colors.grey,
                ),
                onPressed: () {
                  if (AppStorage.readIsLoggedIn != true) {
                    Get.to(() => LoginView());
                  } else {
                    if (logcon.logindata.value.read('USERID') != null) {
                      if (wishcontroller.wishListIdArray
                          .contains(controller.productdetail.value.id)) {
                        //toastMsg(message: "remove");
                        wishcontroller.removeFromWishList(
                            controller.productdetail.value.id);
                        wishcontroller.fetchWishlist();
                      } else {
                        //toastMsg(message: "add");
                        wishcontroller
                            .addToWishList(controller.productdetail.value.id);
                        wishcontroller.fetchWishlist();
                      }
                    } else {
                      getSnackbar(message: "Please Login to add to wishlist");
                    }
                  }
                }),
          ),
          //Images Slider and Images Selector
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              MaterialButton(
                shape: const CircleBorder(),
                color: Colors.white,
                height: 45,
                child: const Icon(
                  Icons.arrow_back_ios_new_rounded,
                  size: 16,
                  color: Colors.black54,
                ),
                onPressed: () {
                  Get.back();
                },
              ),
              const Spacer(),
              Obx(
                () => MaterialButton(
                  shape: const CircleBorder(),
                  color: Colors.white,
                  height: 45,
                  onPressed: () {
                    Future.delayed(const Duration(seconds: 2), () {
                      Get.to(CartView());
                    });
                  },
                  child: bag.Badge(
                    badgeContent: Text(
                      '${cartcontroller.cartAssetsList.length}',
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                    ),
                    badgeAnimation: const bag.BadgeAnimation.slide(),
                    child: const Icon(
                      Icons.shopping_cart,
                      size: 30,
                    ),
                  ),
                ),
              ),
            ],
          ), // AppBar Icons
          Padding(
            padding: EdgeInsets.only(
                top: Device.orientation == Orientation.portrait
                    ? MediaQuery.of(context).size.height / 2 - 170
                    : MediaQuery.of(context).size.height / 2 - 60),
            child: Center(
              child: Obx(() => controller.productdetail.value.image != null
                  ? DotsIndicator(
                      dotsCount: controller.productdetail.value.image!.length,
                      position: controller.selectedimg.value.toDouble(),
                      onTap: (i) {
                        double selected =
                            controller.selectedimg.value.toDouble();

                        selected = i;
                        selected.toInt();
                      },
                      decorator: const DotsDecorator(
                        color: Colors.black12, // Inactive color
                        activeColor: AppColor.orange,
                      ),
                    )
                  : Container()),
            ),
          )
        ],
      ),
    );
  }

  buildProductImagesCard({img, required Color borderClr, ontap}) {
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: GestureDetector(
        onTap: ontap,
        child: Container(
          height: 40,
          width: 40,
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: borderClr, width: 1.5)),
          child: CachedNetworkImage(
            imageUrl: img,
            fit: BoxFit.contain,
            errorWidget: (context, url, error) {
              return const Icon(Icons.error);
            },
            placeholder: (context, i) {
              return Padding(
                padding: const EdgeInsets.all(5),
                child: Image.asset("assets/images/Placeholder.png"),
              );
            },
          ),
        ),
      ),
    );
  }

  buildRatingReviewtile() {
    return Row(
      children: [
        const Icon(
          Iconsax.star1,
          color: Colors.amber,
        ),
        Obx(
          () => Text(
            controller.productdetail.value.rating.toString(),
            style: subtitleStyle,
          ),
        ),
        const SizedBox(
          width: 10,
        ),
        Obx(
          () => controller.reviewList.length == 0
              ? SizedBox()
              : Row(
                  children: [
                    Text(
                      controller.reviewList.length.toString(),
                      style: subtitleStyle.copyWith(color: Colors.grey),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(() => UserReviewView(
                              productId:
                                  controller.productdetail.value.id!.toInt(),
                            ));
                      },
                      child: Text(
                        'reviews',
                        style: subtitleStyle.copyWith(color: AppColor.orange),
                      ),
                    ),
                  ],
                ),
        ),
        const Spacer(),
        Text(
          controller.selectedVariantQty.value > 0
              ? "${controller.selectedVariantQty.value} in Stock !"
              : "Out of stock!",
          style: const TextStyle(color: Colors.orange),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // print("StockLength: ${controller.stockwise.length}");
    // controller.fetchProductDetail(widget.slug);
    /*controller.selectedRam.value = controller.stockwise[1].ram.toString();
    controller.price.value = controller.stockwise[1].price!.toInt();
    controller.selectedVariantQty.value =
        controller.stockwise[1].stockQty!.toInt();*/
    log("------------${controller.selectedColor}");
    controller.fetchReviews(controller.productdetail.value.id?.toInt());
    return Obx(
      () => controller.loading.isTrue
          ? SafeArea(
              child: Container(
                  height: 200,
                  color: Colors.white,
                  child: SizedBox(
                    height: 200,
                    child: CustomShimmer(
                      baseColor: Colors.grey.shade300,
                      highlightColor: Colors.grey.shade100,
                      widget: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 10),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                            ),
                            height: 300,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Container(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 10),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                            ),
                            height: 70,
                            width: 350,
                            decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                          const Spacer(),
                          Container(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 10),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                            ),
                            height: 70,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )),
            )
          : Scaffold(
              body: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Column(
                    children: [
                      buildDetailsTop(context),
                      const SizedBox(
                        height: 20,
                      ),
                      buildImageCard(),
                      const SizedBox(
                        height: 20,
                      ),
                      buildMainBody(),
                    ],
                  ),
                ),
              ),
              bottomNavigationBar: Padding(
                padding: const EdgeInsets.only(bottom: 55),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.grey.shade200,
                      ),
                      child: Obx(
                        () => Row(
                          children: [
                            buildincdecButton(Icons.remove, () {
                              controller.decrement();
                            }),
                            const SizedBox(
                              width: 20,
                            ),
                            Text(
                              controller.count.value.toString(),
                              style: titleStyle,
                            ),
                            const SizedBox(
                              width: 20,
                            ),
                            buildincdecButton(Icons.add, () {
                              controller.increment();
                            }),
                          ],
                        ),
                      ),
                    ),
                    CustomButtons(
                      width: 200,
                      label: 'Add to Cart',
                      txtClr: Colors.white,
                      btnClr: AppColor.orange,
                      ontap: () async {
                        cartcontroller.addCartLoading.value == true
                            ? null
                            : cartcontroller.addToCart(
                                controller.productdetail.value.id.toString(),
                                controller.specialPrice.value == 0
                                    ? controller.productdetail.value.price
                                    : controller.specialPrice.toString(),
                                controller.count.toString(),
                                controller.selectedVarientId.value
                                // controller.selectedColor.toString(),
                                );
                        log("ProductDetailView: Add to Cart tapped");
                        log("controller.price ${controller.specialPrice}");
                        log("controller.count ${controller.count}");
                        log("controller.selectedColor:${controller.selectedColor}");
                        log("controller.productdetail.id:${controller.productdetail.value.id}");
                        log("Color:${controller.selectedColor.value}");
                        log("Varient:${controller.selectedVarientId.value}");
                        log("Varient.length:${controller.productdetail.value.selectedData?.length}");

                        if (await Connectivity().checkConnectivity() ==
                            ConnectivityResult.none) {
                          getSnackbar(
                              message: "No Internet Connection",
                              error: true,
                              bgColor: Colors.red);
                          return;
                        }

                        if (AppStorage.readIsLoggedIn != true) {
                          Get.to(() => LoginView());
                          return;
                        }
                        if (controller.selectedColor.value == 0) {
                          getSnackbar(message: 'Please select a color');
                          return;
                        }
                        if (controller
                                .productdetail.value.selectedData!.isNotEmpty &&
                            controller.selectedVarientId.value == 0) {
                          getSnackbar(message: 'Please select a variant');
                          return;
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  buildSizeCard(isactive, size, ontap) {
    return Padding(
      padding: const EdgeInsets.only(left: 10),
      child: GestureDetector(
        onTap: ontap,
        child: Card(
          color: isactive ? AppColor.mainClr : Colors.grey.shade200,
          elevation: 5,
          borderOnForeground: false,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          child: SizedBox(
            height: 50,
            width: 50,
            child: Center(
              child: Text(
                size,
                style: titleStyle.copyWith(
                    color: isactive ? Colors.white : Colors.blueGrey),
              ),
            ),
          ),
        ),
      ),
    );
  }

  buildincdecButton(IconData icon, ontap) {
    return SizedBox(
      width: 40,
      child: MaterialButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        onPressed: ontap,
        onLongPress: ontap,
        padding: const EdgeInsets.all(5),
        color: Colors.white,
        child: Icon(icon),
      ),
    );
  }

  _buildQueAnsTile({required bool questions, ques, name}) {
    return ListTile(
      dense: true,
      visualDensity: const VisualDensity(horizontal: 0, vertical: -4),
      leading: CircleAvatar(
        backgroundColor: questions ? AppColor.orange : Colors.grey,
        radius: 12,
        child: Text(
          questions ? 'Q' : 'A',
          style: subtitleStyle.copyWith(color: Colors.white),
        ),
      ),
      // minVerticalPadding: -10,
      contentPadding: EdgeInsets.zero,
      minLeadingWidth: 5,
      title: Text(
        ques ?? 'null',
        style: subtitleStyle,
      ),
      subtitle: Text(
        name ?? 'null',
        style: subtitleStyle.copyWith(fontSize: 12.sp),
      ),
    );
  }

  _buildColorContainer(color, code, {int? id}) {
    return GestureDetector(
      onTap: () async {
        controller.hasData(true);

        controller.selectedColor.value = id!;
        controller.selectedColorCode.value = code;
        controller.fetchProductAttribute(id, widget.productid);
        // log(controller.productattributesData);
        // controller.price.value =
        //     controller.productattributesData['data'][0]['price'];
        controller.selectedVarientId.value = 0;
        // log(controller.selectedVarientId.value.toString());
      },
      child: Container(
        height: 30,
        width: 30,
        decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: controller.selectedColor.value == id
                ? Border.all(
                    color: AppColor.orange,
                    width: 1,
                  )
                : Border.all(color: color, width: 0),
            boxShadow: [
              BoxShadow(
                  blurRadius: 5,
                  color: color.withOpacity(0.6),
                  offset: const Offset(0, 4))
            ]),
      ),
    );
  }

  buildImageCard() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Obx(() => controller.productdetail.value.image != null
          ? Row(
              children: [
                ...List.generate(
                  controller.productdetail.value.image!.length,
                  (index) => buildProductImagesCard(
                    img: controller.productdetail.value.image?[index].image
                        ?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url),
                    borderClr: controller.selectedimg.value == index
                        ? AppColor.mainClr
                        : Colors.transparent,
                    ontap: () {
                      log("${controller.productdetail.value.image?[index].id}");
                      controller.selectedimg.value = index;
                      // .toInt();
                      buttonCarouselController.jumpToPage(
                          /*controller.productdetail.value
                                                        .images![index].id!
                                                        .toInt() -
                                                    1*/
                          index);
                    },
                  ),
                ),
              ],
            )
          : Container()),
    );
  }

  Widget buildMainBody() {
    var formatter = NumberFormat('#,###');
    var specialPrice =
        thousandSepretor.format(controller.productdetail.value.specialPrice);
    // var specialPrice = addThousandSeparators(controller.specialPrice.value);
    var price = formatter.format(controller.productdetail.value.price);
    // controller.selectedColor.value =
    //     controller.productdetail.value.colors![0].id!.toInt ();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildRatingReviewtile(),
          // const SizedBox(
          //   height: 20,
          // ),
          SizedBox(height: 10,),
          Obx(
            () => SizedBox(
              width: double.infinity,
              child: Text(
                controller.productdetail.value.name.toString(),
                style: titleStyle.copyWith(
                    fontSize: 16.sp, fontWeight: FontWeight.w500),
              ),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Obx(
            () => RichText(
              text: TextSpan(children: <TextSpan>[
                /*initially specialPrice is 0,
                so it  checks in productDetail if specialPrice is null,
                if null it shows price otherwise it shows specialPrice*/
                /*specialPrice gets selected variant specialPrice
                on Variant Selection */
                TextSpan(
                  text:
                      "Rs. ${controller.productdetail.value.specialPrice == 0 || controller.productdetail.value.specialPrice == null ? price : specialPrice} ",
                  style: titleStyle.copyWith(
                      fontSize: 20.sp, fontWeight: FontWeight.bold),
                ),
                TextSpan(
                  text: controller.productdetail.value.vat,
                  style: titleStyle.copyWith(
                      color: Colors.grey, fontWeight: FontWeight.bold),
                ),
              ]),
            ),
          ),
          //specialPrice=0, means there's no specialPrice
          Obx(() => controller.specialPrice.value == 0 ||
                  controller.specialPrice.value == controller.price.value
              ? Container()
              : Text(
                  "Original Price: $price",
                  style: subtitleStyle.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.red,
                      decoration: TextDecoration.lineThrough),
                )),

          Obx(() => Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  const Text(
                    'Fulfilled by: ',
                    style: TextStyle(color: Colors.red, fontSize: 15),
                  ),
                  GestureDetector(
                    onTap: () {
                      launch(controller.productdetail.value.sellerUrl!);
                    },
                    child: Text(
                      controller.sellerName.value,
                      style: const TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              )),
          const SizedBox(
            height: 20,
          ),

          //Color Selector
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                    flex: 3,
                    child: Text(
                      'Color:',
                      style: titleStyle,
                    )),
                controller.productdetail.value.colors != null
                    ? Expanded(
                        flex: 5,
                        child: Wrap(
                            runSpacing: 10,
                            spacing: 10,
                            children: List.generate(
                                controller.productdetail.value.colors!.length,
                                (index) => Obx(
                                      () => IgnorePointer(
                                        ignoring:
                                            controller.ignorePointer.value,
                                        child: _buildColorContainer(
                                          HexColor(
                                              '${controller.productdetail.value.colors?[index].code}'),
                                          controller.productdetail.value
                                              .colors?[index].code
                                              .toString(),
                                          id: controller.productdetail.value
                                              .colors?[index].id,
                                        ),
                                      ),
                                    ))))
                    : SizedBox()
              ],
            ),
          ),
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          controller.tabIndex.value = "1";
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text("Product Details"),
                        ),
                      ),
                      Obx(() => controller.tabIndex == "1"
                          ? Container(
                              height: 3,
                              width: 100,
                              color: AppColor.orange,
                            )
                          : SizedBox()),
                    ],
                  ),
                  Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          controller.tabIndex.value = "2";
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text("Specification"),
                        ),
                      ),
                      Obx(() => controller.tabIndex == "2"
                          ? Container(
                              height: 3,
                              width: 100,
                              color: AppColor.orange,
                            )
                          : SizedBox()),
                    ],
                  ),
                  Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          controller.tabIndex.value = "3";
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text("Review"),
                        ),
                      ),
                      Obx(() => controller.tabIndex == "3"
                          ? Container(
                              height: 3,
                              width: 100,
                              color: AppColor.orange,
                            )
                          : SizedBox()),
                    ],
                  ),
                ],
              ),
              SizedBox(
                height: 50,
              ),
              Obx(() => controller.tabIndex == "1"
                  ? const ProductDetailsTab()
                  : SizedBox()),
              Obx(() => controller.tabIndex == "2"
                  ? const SpecificationTab()
                  : SizedBox()),
              Obx(() =>
                  controller.tabIndex == "3" ? const ReviewTab() : SizedBox()),
            ],
          ),

          // DefaultTabController(
          //     length: 3,
          //     child: Column(
          //       crossAxisAlignment: CrossAxisAlignment.start,
          //       children: [
          //         SingleChildScrollView(
          //           child: Row(
          //             mainAxisAlignment: MainAxisAlignment.start,
          //             children: [
          //               TabBar(
          //                   indicatorColor: AppColor.red,
          //                   indicatorSize: TabBarIndicatorSize.label,
          //                   indicatorWeight: 4,
          //                   labelStyle: subtitleStyle.copyWith(
          //                       fontSize: 16.sp,
          //                       color: Colors.black,
          //                       fontWeight: FontWeight.bold),
          //                   unselectedLabelStyle: subtitleStyle.copyWith(
          //                       fontSize: 16.sp,
          //                       color: Colors.white,
          //                       fontWeight: FontWeight.normal),
          //                   isScrollable: true,
          //                   tabs: const [
          //                     Tab(
          //                       child: Text(
          //                         "Product Details",
          //                         style: TextStyle(color: Colors.black),
          //                       ),
          //                     ),
          //                     Tab(
          //                       child: Text(
          //                         "Specification",
          //                         style: TextStyle(color: Colors.black),
          //                       ),
          //                     ),
          //                     Tab(
          //                       child: Text(
          //                         "Comments",
          //                         style: TextStyle(color: Colors.black),
          //                       ),
          //                     ),
          //                   ]),
          //             ],
          //           ),
          //         ),
          //         SizedBox(
          //           height: 30,
          //         ),
          //         Container(
          //           height: 300,
          //           child: TabBarView(children: [
          //             SingleChildScrollView(
          //               child: Column(
          //                 crossAxisAlignment: CrossAxisAlignment.start,
          //                 children: [
          //                   Obx(
          //                         () => HtmlWidget(
          //                       controller.showLongDesc.isTrue
          //                           ? controller
          //                           .productdetail.value.longDescription
          //                           .toString()
          //                           : controller
          //                           .productdetail.value.shortDescription
          //                           .toString(),
          //                     ),
          //                   ),
          //                 ],
          //               ),
          //             ),
          //             Column(
          //               crossAxisAlignment: CrossAxisAlignment.start,
          //               children: [
          //                 Table(children: [
          //                   TableRow(children: [
          //                     const Center(
          //                       child: Padding(
          //                         padding: EdgeInsets.all(12.0),
          //                         child: Text(
          //                           "Brand",
          //                           style: TextStyle(
          //                               fontSize: 13.0,
          //                               fontWeight: FontWeight.bold),
          //                         ),
          //                       ),
          //                     ),
          //                     Padding(
          //                       padding: const EdgeInsets.all(8.0),
          //                       child: Text(controller.productdetail.value
          //                           .specificationData?.brand ==
          //                           null
          //                           ? "Not Specified"
          //                           : controller.productdetail!.value!
          //                           .specificationData!.brand!),
          //                     ),
          //                   ]),
          //                   TableRow(children: [
          //                     const Center(
          //                       child: Padding(
          //                         padding: EdgeInsets.all(12.0),
          //                         child: Text(
          //                           "Color",
          //                           style: TextStyle(
          //                               fontSize: 13.0,
          //                               fontWeight: FontWeight.bold),
          //                         ),
          //                       ),
          //                     ),
          //                     Padding(
          //                       padding: const EdgeInsets.all(8.0),
          //                       child: Text(controller.productdetail.value
          //                           .specificationData?.color ==
          //                           null
          //                           ? "Not Specified"
          //                           : controller.productdetail!.value!
          //                           .specificationData!.color!),
          //                     ),
          //                   ]),
          //                 ]),
          //                 controller.productdetail.value.specificationData!
          //                     .specification !=
          //                     null
          //                     ? Row(
          //                   children: [
          //                     SizedBox(
          //                       width: 51,
          //                     ),
          //                     HtmlWidget(controller.productdetail.value
          //                         .specificationData!.specification
          //                         .toString()),
          //                   ],
          //                 )
          //                     : SizedBox()
          //               ],
          //             ),
          //             Column(
          //               children: [
          //                 Row(
          //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //                   children: [
          //                     Text(
          //                       'Question about this product',
          //                       style: titleStyle,
          //                     ),
          //                     GestureDetector(
          //                       onTap: () {
          //                         Get.to(() => QnAView(
          //                           id: controller.productdetail.value.id!
          //                               .toInt(),
          //                         ));
          //                       },
          //                       child: Text(
          //                         'View all',
          //                         style: subtitleStyle.copyWith(
          //                             color: AppColor.orange),
          //                       ),
          //                     )
          //                   ],
          //                 ),
          //                 Obx(() => controller.questionAnsList.isNotEmpty
          //                     ? ListView.builder(
          //                     shrinkWrap: true,
          //                     itemCount:
          //                     controller.questionAnsList.length >= 2
          //                         ? 2
          //                         : 1,
          //                     itemBuilder: (context, index) {
          //                       var data =
          //                       controller.questionAnsList[index];
          //
          //                       return Column(
          //                         children: [
          //                           _buildQueAnsTile(
          //                               questions: true,
          //                               ques: data.questionAnswer,
          //                               name: data.user?.name),
          //                           controller.questionAnsList[index].answer
          //                               ?.questionAnswer ==
          //                               null
          //                               ? Container()
          //                               : _buildQueAnsTile(
          //                               questions: false,
          //                               ques:
          //                               data.answer?.questionAnswer,
          //                               name: data.user?.name),
          //                         ],
          //                       );
          //                     })
          //                     : const Text('')),
          //                 Center(
          //                   child: TextButton(
          //                     onPressed: () {
          //                       // controller.fetchQuesAns(
          //                       //     controller.productdetail.value.id);
          //                       if (AppStorage.readIsLoggedIn != true) {
          //                         getSnackbar(
          //                             message:
          //                             "Please Login to ask a question.");
          //                         return;
          //                       }
          //
          //                       Get.bottomSheet(Container(
          //                         decoration: const BoxDecoration(
          //                             color: Colors.white,
          //                             borderRadius: BorderRadius.only(
          //                               topLeft: Radius.circular(20),
          //                               topRight: Radius.circular(20),
          //                             )),
          //                         padding: const EdgeInsets.all(20),
          //                         child: Form(
          //                           key: _formKey,
          //                           child: Column(
          //                             crossAxisAlignment:
          //                             CrossAxisAlignment.start,
          //                             mainAxisSize: MainAxisSize.min,
          //                             children: [
          //                               const CustomCircularIcon(),
          //                               const SizedBox(
          //                                 height: 10,
          //                               ),
          //                               MyInputField(
          //                                 hint: 'Question',
          //                                 controller: controller.qna,
          //                                 validator: (v) =>
          //                                     validateIsEmpty(string: v),
          //                               ),
          //                               const SizedBox(
          //                                 height: 20,
          //                               ),
          //                               Center(
          //                                 child: CustomButton(
          //                                     label: 'Submit',
          //                                     btnClr: AppColor.orange,
          //                                     txtClr: Colors.white,
          //                                     ontap: () async {
          //                                       // log('object');
          //                                       Get.back();
          //
          //                                       if (_formKey.currentState!
          //                                           .validate()) {
          //                                         await controller.postQues(
          //                                           controller
          //                                               .productdetail.value.id,
          //                                         );
          //                                         controller.fetchQuesAns(
          //                                             controller.productdetail
          //                                                 .value.id);
          //                                       }
          //                                     }),
          //                               ),
          //                               const SizedBox(
          //                                 height: 50,
          //                               ),
          //                             ],
          //                           ),
          //                         ),
          //                       ));
          //                     },
          //                     child: Text(
          //                       'Ask a question',
          //                       style:
          //                       titleStyle.copyWith(color: AppColor.orange),
          //                     ),
          //                   ),
          //                 ),
          //               ],
          //             )
          //           ]),
          //         ),
          //       ],
          //     )),
          ...List.generate(
              controller.productdetail.value.attribute!.length - 5,
              (index) => Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Text(
                            '${controller.productdetail.value.attribute![index]}:',
                            style: titleStyle,
                            textAlign: TextAlign.left,
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Obx(
                              () => Wrap(
                                spacing: 10,
                                children:
                                    // controller.productattributesData !=
                                    //             null &&
                                    //         controller.hasData.isTrue &&

                                    controller.selectedColor.value != 0
                                        ? controller
                                                .productAttributeLoading.isFalse
                                            ? List.generate(
                                                controller
                                                    .productattributesData[
                                                        'data']
                                                    .length,
                                                (i) => Obx(
                                                  () => Container(
                                                    decoration:
                                                        const BoxDecoration(
                                                            boxShadow: [
                                                          BoxShadow(
                                                              blurRadius: 5,
                                                              offset:
                                                                  Offset(0, 2),
                                                              color: Colors
                                                                  .black12)
                                                        ]),
                                                    child:

                                                        // Center(
                                                        //   child: Text(
                                                        //     controller.productattributesData[
                                                        //             'data'][i][
                                                        //         controller
                                                        //             .productdetail
                                                        //             .value
                                                        //             .attribute![
                                                        //                 index]
                                                        //             .toString()],
                                                        //     style: subtitleStyle
                                                        //         .copyWith(
                                                        //             color: AppColor
                                                        //                 .orange),
                                                        //   ),
                                                        // )

                                                        MaterialButton(
                                                      //selectedVarient
                                                      onPressed: () async {
                                                        if (controller.productattributesData[
                                                                    'data'][i]
                                                                ['color'] ==
                                                            controller
                                                                .selectedColorCode
                                                                .value) {
                                                          controller
                                                                  .selectedVarientId
                                                                  .value =
                                                              int.parse(controller
                                                                  .productattributesData[
                                                                      'data'][i]
                                                                      ['id']
                                                                  .toString());

                                                          controller
                                                              .specialPrice
                                                              .value = controller
                                                                          .productattributesData[
                                                                      'data'][i]
                                                                  [
                                                                  'special_price'] ??
                                                              0;

                                                          controller.price
                                                              .value = controller
                                                                  .productattributesData[
                                                              'data'][i]['price'];
                                                          controller
                                                              .selectedVariantQty
                                                              .value = controller
                                                                      .productattributesData[
                                                                  'data'][i]
                                                              ['quantity'];
                                                        }
                                                      },
                                                      minWidth: 80,
                                                      color: Colors.white,
                                                      elevation: 5,
                                                      shape:
                                                          RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                        side: BorderSide(
                                                            color:
                                                                //  AppColor.orange,
                                                                controller.selectedVarientId
                                                                            .value ==
                                                                        controller
                                                                                .productattributesData['data'][i]
                                                                            [
                                                                            'id']
                                                                    ? AppColor
                                                                        .orange
                                                                    : Colors
                                                                        .white,
                                                            width: 2),
                                                      ),
                                                      padding: EdgeInsets.zero,
                                                      child: Text(
                                                          controller.productattributesData[
                                                                  'data'][i][
                                                              controller
                                                                  .productdetail
                                                                  .value
                                                                  .attribute![
                                                                      index]
                                                                  .toString()],
                                                          style: subtitleStyle
                                                              .copyWith(
                                                                  color:
                                                                      //  AppColor.orange
                                                                      controller.selectedVarientId.value == controller.productattributesData['data'][i]['id']
                                                                          ? AppColor.orange
                                                                          : Colors.black)),
                                                    ),
                                                  ),
                                                ),
                                              )
                                            : [const Text('-----')]
                                        : List.generate(
                                            controller.productdetail.value
                                                .selectedData!.length,
                                            (i) => Obx(() => Container(
                                                  decoration:
                                                      const BoxDecoration(
                                                          boxShadow: [
                                                        BoxShadow(
                                                            blurRadius: 5,
                                                            offset:
                                                                Offset(0, 2),
                                                            color:
                                                                Colors.black12)
                                                      ]),
                                                  child: MaterialButton(
                                                    onPressed: () async {
                                                      if (controller.myData[
                                                                      'data'][
                                                                  'selected_data']
                                                              [i]['color'] ==
                                                          controller
                                                              .selectedColorCode
                                                              .value) {
                                                        controller
                                                                .selectedVarientId
                                                                .value =
                                                            int.parse(controller
                                                                .myData['data'][
                                                                    'selected_data']
                                                                    [i]['id']
                                                                .toString());

                                                        controller.specialPrice
                                                            .value = controller
                                                                        .myData[
                                                                    'data'][
                                                                'selected_data']
                                                            [i]['price'];
                                                        controller
                                                            .selectedVariantQty
                                                            .value = controller
                                                                        .myData[
                                                                    'data'][
                                                                'selected_data']
                                                            [i]['quantity'];
                                                        log(controller
                                                            .specialPrice
                                                            .toString());
                                                      }
                                                    },
                                                    minWidth: 80,
                                                    color: Colors.white,
                                                    elevation: 5,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5),
                                                      side: BorderSide(
                                                          color:
                                                              // AppColor.orange,
                                                              controller.selectedVarientId
                                                                          .value ==
                                                                      controller.myData['data']['selected_data']
                                                                              [
                                                                              i]
                                                                          ['id']
                                                                  ? AppColor
                                                                      .orange
                                                                  : Colors
                                                                      .white,
                                                          width: 2),
                                                    ),
                                                    padding: EdgeInsets.zero,
                                                    child: Text(
                                                        controller.myData[
                                                                    'data'][
                                                                'selected_data'][i]
                                                            [controller
                                                                .productdetail
                                                                .value
                                                                .attribute![
                                                                    index]
                                                                .toString()],
                                                        style: subtitleStyle
                                                            .copyWith(
                                                          color:
                                                              // AppColor.orange,

                                                              controller.selectedVarientId
                                                                          .value ==
                                                                      controller.myData['data']['selected_data']
                                                                              [
                                                                              i]
                                                                          ['id']
                                                                  ? AppColor
                                                                      .orange
                                                                  : Colors
                                                                      .black,
                                                        )),
                                                  ),
                                                )),
                                          ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
          //size selector
          // Center(
          //   child: SingleChildScrollView(
          //     scrollDirection: Axis.horizontal,
          //     child: Row(
          //       children: [
          //         ...List.generate(
          //             sizes.length,
          //             (index) => Obx(
          //                   () => buildSizeCard(
          //                     controller.selectedindex.value ==
          //                         sizes[index]['id'],
          //                     sizes[index]['size'],
          //                     () {
          //                       controller.selectedindex.value =
          //                           sizes[index]['id'];
          //                     },
          //                   ),
          //                 ))
          //       ],
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }

  String addThousandSeparators(int number) {
    return RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))')
        .allMatches(number.toString())
        .map((match) => '${match.group(1)},')
        .join()
        .toString();
  }
}
