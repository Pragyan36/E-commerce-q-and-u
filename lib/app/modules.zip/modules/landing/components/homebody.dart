import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:get/get.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:usoft/app/modules/cart/controllers/cart_controller.dart';
import 'package:usoft/app/modules/landing/controllers/landing_controller.dart';
import 'package:usoft/app/modules/login/controllers/login_controller.dart';
import 'package:usoft/app/modules/wishlist/controllers/wishlist_controller.dart';
import 'package:usoft/app/widgets/custom_shimmer.dart';
import 'package:usoft/app/widgets/loading_widget.dart';

import '../../../constants/constants.dart';
import '../../../database/app_storage.dart';
import '../../../widgets/product_card.dart';
import '../../../widgets/snackbar.dart';
import '../../../widgets/toast.dart';
import '../../home/components/sliver_grid.dart';
import '../../login/views/login_view.dart';
import '../../product_detail/views/product_detail_view.dart';

class HomeBody extends StatefulWidget {
  // const HomeBody({super.key, required this.scrollcon});

  // final ScrollController scrollcon;

  @override
  State<HomeBody> createState() => _HomeBodyState();
}

class _HomeBodyState extends State<HomeBody> {
  Key _key = const PageStorageKey({});
  bool _innerListIsScrolled = false;

  final controller = Get.put(LandingController());
  final wishlistcontroller = Get.put(WishlistController());
  final logcon = Get.put(LoginController());
  final cartController = Get.put(CartController());

  @override
  void initState() {
    // controller.fetchJustForYouBySlug(
    //     "ut-omnis-laborum-nihil-repellat-cumque-commodi-voluptas-molestiae");

    super.initState();

    SchedulerBinding.instance.scheduleFrameCallback((timeStamp) {
      controller.fetchJustForYou();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => controller.jfyLoading.isTrue
          ? SizedBox(
              height: 750,
              child: GridView.builder(
                  itemCount: 5,
                  // scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCountAndFixedHeight(
                    crossAxisCount: 2,
                    crossAxisSpacing: 5,
                    mainAxisSpacing: 5,
                    height: 190.0,
                  ),
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: CustomShimmer(
                        baseColor: Colors.grey.shade300,
                        highlightColor: Colors.grey.shade100,
                        widget: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                          ),
                          height: 750,
                          width: 150,
                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(5),
                          ),
                        ),
                      ),
                    );
                  }),
            )
          : GridView.builder(
              itemCount: controller.justForYouProductsList.length,
              // addAutomaticKeepAlives: true,
              // shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCountAndFixedHeight(
                crossAxisCount: 2,
                crossAxisSpacing: 5,
                mainAxisSpacing: 5,
                height: 270.0,
              ),
              itemBuilder: (context, index) {
                var data = controller.justForYouProductsList[index];
                print("new ${data.name}");
                return Obx(
                  () => Column(
                    children: [
                      ProductCard(
                        price: data.price,
                        productImg:
                            '${data.image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}',
                        productName: data.name,
                        rating: data.rating.toString(),
                        specialprice: data.specialPrice == '0'
                            ? data.price.toString()
                            : data.specialPrice.toString(),
                        ontap: () async {
                          if (await Connectivity().checkConnectivity() ==
                              ConnectivityResult.none) {
                            getSnackbar(
                                message: "No Internet Connection",
                                error: true,
                                bgColor: Colors.red);
                            return;
                          }
                          Get.to(() => ProductDetailView(
                                productname: data.name,
                                productprice: data.id.toString(),
                                slug: data.slug,
                                productid: data.id,
                              ));
                        },
                        isFav:
                            wishlistcontroller.wishListIdArray.contains(data.id)
                                ? true
                                : false,
                        ontapFavorite: () {
                          if (AppStorage.readIsLoggedIn != true) {
                            Get.to(() => LoginView());
                          } else {
                            if (logcon.logindata.value.read('USERID') != null) {
                              if (wishlistcontroller.wishListIdArray
                                  .contains(data.id)) {
                                //toastMsg(message: "remove");
                                wishlistcontroller.removeFromWishList(data.id);
                                wishlistcontroller.fetchWishlist();
                              } else {
                                //toastMsg(message: "add");
                                wishlistcontroller.addToWishList(data.id);
                                wishlistcontroller.fetchWishlist();
                              }
                            } else {
                              toastMsg(
                                  message: "Please Login to add to wishlist");
                            }
                          }
                        },
                        ontapCart: () {
                          if (AppStorage.readIsLoggedIn != true) {
                            Get.to(() => LoginView());
                          } else {
                            cartController.addToCart(
                              data.id,
                              data.price,
                              '1',
                              data.varient,
                            );
                          }
                        },
                        percent: data.percent == null
                            ? const SizedBox()
                            : Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 10),
                                child: Align(
                                    alignment: Alignment.topLeft,
                                    child: Container(
                                      alignment: Alignment.center,
                                      height: 30,
                                      width: 40,
                                      decoration: BoxDecoration(
                                          color: Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(06)),
                                      child: Text(
                                        '${data.percent}%',
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    )),
                              ),
                      ),
                    ],
                  ),
                );
              },
            ),

      // TabBarView(key: _key, children: [
      //   // AllProducts(
      //   //   scollcon: widget.scrollcon,
      //   // ),
      //   ...List<Widget>.generate(controller.justForYouTagsList.length,
      //       (int index) {
      //     return controller.jfyLoading.isFalse
      //         ? Text(controller.justForYouProductsList[0].slug.toString())
      //         : Text('Loading');
      //   }),
      // ]),
    );
  }
}

class AllProducts extends StatefulWidget {
  const AllProducts({
    super.key,
    this.scollcon,
  });

  final ScrollController? scollcon;

  @override
  State<AllProducts> createState() => _AllProductsState();
}

class _AllProductsState extends State<AllProducts> {
  final controller = Get.put(LandingController());

  final wishlistcontroller = Get.put(WishlistController());

  final logcon = Get.put(LoginController());

  final cartController = Get.put(CartController());

  @override
  void initState() {
    widget.scollcon?.addListener(_updateScrollPosition);
    super.initState();
  }

  void _updateScrollPosition() {
    print(widget.scollcon!.position.extentAfter);
    if (widget.scollcon!.position.extentAfter == 0.0) {
    } else if (widget.scollcon!.position.extentAfter > 0.0) {}
  }

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => controller.loading.value
          ? const LoadingWidget()
          : SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  // TextButton(
                  //     onPressed: () {
                  //       widget.scollcon?.animateTo(300,
                  //           duration: const Duration(
                  //             seconds: 1,
                  //           ),
                  //           curve: Curves.ease);
                  //     },
                  //     child: Text('load more')),

                  Obx(() => GridView.builder(
                      itemCount: controller.productsList.length,
                      addAutomaticKeepAlives: true,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 20),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCountAndFixedHeight(
                        crossAxisCount: 2,
                        crossAxisSpacing: 5,
                        mainAxisSpacing: 5,
                        height: 270.0,
                      ),
                      itemBuilder: (context, index) {
                        var data = controller.productsList[index];
                        return Obx(
                          () => ProductCard(
                            price: data.getPrice!.price.toString(),
                            productImg:
                                '${data.images?[0].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}',
                            productName: data.name,
                            rating: data.rating.toString(),
                            specialprice:
                                data.getPrice?.specialPrice.toString(),
                            ontap: () {
                              Get.to(() => ProductDetailView(
                                    productname: data.name,
                                    productprice: data.id.toString(),
                                    slug: data.slug,
                                    productid: data.id,
                                  ));
                            },
                            isFav: wishlistcontroller.wishListIdArray
                                    .contains(data.id)
                                ? true
                                : false,
                            ontapFavorite: () {
                              if (AppStorage.readIsLoggedIn != true) {
                                Get.to(() => LoginView());
                              } else {
                                if (logcon.logindata.value.read('USERID') !=
                                    null) {
                                  if (wishlistcontroller.wishListIdArray
                                      .contains(data.id)) {
                                    //toastMsg(message: "remove");
                                    wishlistcontroller
                                        .removeFromWishList(data.id);
                                    wishlistcontroller.fetchWishlist();
                                  } else {
                                    //toastMsg(message: "add");
                                    wishlistcontroller.addToWishList(data.id);
                                    wishlistcontroller.fetchWishlist();
                                  }
                                } else {
                                  toastMsg(
                                      message:
                                          "Please Login to add to wishlist");
                                }
                              }
                            },
                            ontapCart: () {
                              if (AppStorage.readIsLoggedIn != true) {
                                Get.to(() => LoginView());
                              } else {
                                cartController.addToCart(
                                    data.id,
                                    data.getPrice?.price,
                                    '1',
                                    // '1',
                                    data.varientId);
                              }
                            },
                            percent: data.percent == null
                                ? const SizedBox()
                                : Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 10),
                                    child: Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          alignment: Alignment.center,
                                          height: 30,
                                          width: 40,
                                          decoration: BoxDecoration(
                                              color: Colors.red,
                                              borderRadius:
                                                  BorderRadius.circular(06)),
                                          child: Text(
                                            '${data.percent}%',
                                            style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        )),
                                  ),
                          ),
                        );
                      })),
                  if (controller.loadingmore.isTrue)
                    Container(
                      height: 100,
                      width: double.infinity,
                      color: Colors.white,
                      child: Center(
                        child: Center(
                          child: LoadingAnimationWidget.discreteCircle(
                            color: AppColor.orange,
                            size: 40,
                          ),
                        ),
                      ),
                    ),

                  ////xxxxx
                  // TextButton(
                  //     onPressed: () {
                  //       controller.loadMore();
                  //       print("Scroll pos: " +
                  //           controller.scrollcon.value.position.pixels.toString());
                  //     },
                  //     child: Text('load more')),
                ],
              ),
            ),
    );
  }
}
