import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:badges/badges.dart' as badges;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:usoft/app/modules/category/controllers/category_controller.dart';
import 'package:usoft/app/modules/home/controllers/home_controller.dart';
import 'package:usoft/app/modules/landing/components/featured_products_view.dart';
import 'package:usoft/app/modules/landing/components/homebody.dart';
import 'package:usoft/app/modules/landing/components/top_offers_screen.dart';
import 'package:usoft/app/modules/landing/views/slider.dart';
import 'package:usoft/app/modules/product_detail/views/product_detail_view.dart';
import 'package:usoft/app/widgets/custom_shimmer.dart';
import 'package:usoft/app/widgets/loading_widget.dart';
import 'package:usoft/app/widgets/snackbar.dart';

import '../../../constants/constants.dart';
import '../../../routes/app_pages.dart';
import '../../../widgets/no_internet.dart';
import '../../../widgets/searchbar.dart';
import '../../department/views/department_view.dart';
import '../../department/views/department_viewall.dart';
import '../../home/components/map_view.dart';
import '../../home/controllers/map_controller.dart';
import '../controllers/landing_controller.dart';

class LandingView extends StatefulWidget {
  const LandingView({Key? key}) : super(key: key);

  @override
  State<LandingView> createState() => _LandingViewState();
}

class _LandingViewState extends State<LandingView>
    with TickerProviderStateMixin {
  final controller = Get.put(LandingController());
  final homeController = Get.put(HomeController()); //for notifications
  final mapcontroller = Get.put(MapViewController()); //for maps
  final categorycontroller = Get.put(CategoryController());
  int _imageCurrentIndex = 0;
  final PageController _pageController = PageController(initialPage: 0);

  // final appController = Get.put(AppC)

  late ScrollController scrollcontroller;
  var hasInternet = false.obs;

  late TabController _tabController;

  @override
  void initState() {
    log("LandingView:initState");

    checkInternet();
       // WidgetsBinding.instance.addPostFrameCallback((_) {
    // scrollcontroller = ScrollController()..addListener(_scrollListener);
    // });
    _tabController = TabController(
        vsync: this, length: controller.justForYouTagsList.length);

    Timer.periodic(const Duration(seconds: 10), (Timer timer) {
      if (_imageCurrentIndex < controller.adlist.length - 1) {
        _imageCurrentIndex++;
      } else {
        _imageCurrentIndex = 0;
      }
      _pageController.animateToPage(
        _imageCurrentIndex,
        duration: const Duration(milliseconds: 500),
        curve: Curves.ease,
      );
    });

    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    Get.delete<LandingController>();
    Get.delete<HomeController>();
    Get.delete<MapViewController>();
    scrollcontroller.dispose();
  }

  void _scrollListener() {
    // controller.loadMore();

    if (scrollcontroller.position.pixels ==
        (scrollcontroller.position.maxScrollExtent)) {
      log("_scrollListener:scrolledMax:${scrollcontroller.position.pixels}");
      // controller.numberOfPostsPerRequest.value += 4;
      // toastMsg(message: "Loading more ...");

      // controller.loadMore();
      // controller.loadMoreJustForYou(page, slug, perPage);
    }
    // if (scrollcontroller.position.extentAfter > 2300) {
    //   print('min scroll extent');
    //   controller.tapdown(true);
    // } else if (scrollcontroller.position.extentAfter < 2300) {
    //   controller.tapdown(false);
    // }
  }

  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      GlobalKey<RefreshIndicatorState>();

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    log("LandingView:onWidgetBuild");
    return SafeArea(
      child: Scaffold(
        body: DefaultTabController(
          length: 2,
          child: RefreshIndicator(
            // key: _refreshIndicatorKey,
            backgroundColor: Colors.white,
            color: Colors.orange,
            notificationPredicate: (notification) {
              // with NestedScrollView local(depth == 2) OverscrollNotification are not sent

              return notification.depth == 1;
            },
            onRefresh: () async {
              await Future.delayed(const Duration(seconds: 1));
              controller.onInit();
              categorycontroller.onInit();
            },
            child: Obx(() => hasInternet.value
                ? NestedScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    // physics: const AlwaysScrollableScrollPhysics(),
                    //     parent: BouncingScrollPhysics()),
                    // const BouncingScrollPhysics(),
                    // controller: scrollcontroller,

                    // // onlyOneScrollInBody: true,
                    // floatHeaderSlivers: false,
                    headerSliverBuilder: (context, value) {
                      return [
                        SliverToBoxAdapter(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(
                                height: 10,
                              ),
                              _buildHomeTop(),
                              const SizedBox(
                                height: 10,
                              ),
                              Obx(
                                () => controller.loading.isFalse
                                    ? ImageSliderWidget(
                                        sliderImage:
                                            controller!.sliderlist.value,
                                      )
                                    : CustomShimmer(
                                        baseColor: Colors.grey.shade300,
                                        highlightColor: Colors.grey.shade100,
                                        widget: Container(
                                          margin: const EdgeInsets.symmetric(
                                              horizontal: 8),
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 8,
                                          ),
                                          height: 160,
                                          width:
                                              MediaQuery.of(context).size.width,
                                          decoration: BoxDecoration(
                                            color: Colors.grey,
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                        ),
                                      ),
                              ),
                              // _buildLocation(),

                              // buildDiscoverSlider(),

                              Obx(() => controller.topOffersLoading.value
                                  ? Container()
                                  : Container(
                                      child: controller.topOffersData.isNotEmpty
                                          ? buildHeadertxt(
                                              'Our top offers', () {}, false)
                                          : Container(),
                                    )),
                              //  buildTopOffersSlider(),

                              const SizedBox(
                                height: 10,
                              ),
                              /*Obx(() => controller.adlist.isNotEmpty
                              ? _buildAdTile(controller
                                  .adlist[controller.adIndex.value].mobileImage
                                  ?.replaceAll(
                                      RegExp(r'http://127.0.0.1:8000'), url))
                              : Container()),*/
                              const SizedBox(
                                height: 10,
                              ),
                              buildHeadertxt('Shop by Department', () {
                                Get.to(
                                  () => const DepartmentViewAllView(),
                                );
                              }, false),
                              const SizedBox(
                                height: 20,
                              ),
                              buildDepartmentScroll(),
                              const SizedBox(
                                height: 20,
                              ),
                              FeaturedProductsView(),

                              const SizedBox(
                                height: 10,
                              ),
                              // Obx(() => controller.adsList.isNotEmpty
                              //     ? _buildAdTile(controller
                              //         .adsList[controller.adIndex.value]
                              //         .ads
                              //         ?.mobileImage
                              //         ?.replaceAll(
                              //             RegExp(r'http://127.0.0.1:8000'), url))
                              //     : Container()),
                              const SizedBox(
                                height: 10,
                              ),
                              Obx(() => controller.adlist.isNotEmpty
                                  ? _buildAdvertisement()
                                  : const SizedBox()),
                              const SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 20),
                                child: Text(
                                  'Just For You',
                                  style: titleStyle.copyWith(
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                            ],
                          ),
                        ),
                        SliverPersistentHeader(
                          floating: true,
                          pinned: true,
                          delegate: TestTabBarDelegate(),
                        ),

                        //This is Just For you Tabs
                      ];
                    },

                    //This is Tab Bar Body (Just For You Products Body)
                    body:
                        // Text('data')
                        // Obx(() =>
                        //     Text(controller.justForYouProductsList[0].name.toString()))

                        HomeBody(),
                  )
                : const NoInternetLayout()),
          ),
        ),
      ),
    );
  }

  _buildHomeTop() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        const SizedBox(
          width: 10,
        ),
        Image.asset(
          AppImages.logo,
          width: 50,
        ),
        const SizedBox(
          width: 5,
        ),
        const Flexible(child: CustomSearchBar()),
        const SizedBox(
          width: 5,
        ),
        CircleAvatar(
          backgroundColor: AppColor.mainClr,
          radius: 18,
          child: Center(
            child: Obx(
              () => badges.Badge(
                badgeContent: Text(
                  homeController.notifications.length.toString(),
                  style: const TextStyle(color: Colors.white),
                ),
                showBadge: homeController.notifications.isEmpty ? false : true,
                position: badges.BadgePosition.topEnd(end: -5, top: -5),

                //   badgeColor: AppColor.orange,
                child: IconButton(
                    onPressed: () {
                      Get.toNamed(Routes.NOTIFICATION);
                    },
                    padding: EdgeInsets.zero,
                    icon: Icon(
                      Iconsax.notification,
                      color: Colors.white,
                      size: 18.sp,
                    )),
              ),
            ),
          ),
        ),
        const SizedBox(
          width: 10,
        ),
      ],
    );
  }

  _buildLocation() {
    return TextButton(
      onPressed: () {
        Get.to(() => MapView());
      },
      child: Row(
        children: [
          Icon(
            Iconsax.location,
            size: 18.sp,
            color: Colors.black,
          ),
          const SizedBox(
            width: 10,
          ),
          Text(
            'Delivery To ',
            style: subtitleStyle.copyWith(fontWeight: FontWeight.w100),
          ),
          Obx(
            () => Text(
              mapcontroller.location.value,
              style: subtitleStyle.copyWith(fontWeight: FontWeight.bold),
            ),
          ),
          const Icon(
            Icons.arrow_drop_down_rounded,
            color: Colors.black,
            size: 30,
          )
        ],
      ),
    );
  }

  _buildAdvertisement() {
    return Obx(() => SizedBox(
          height: 120,
          width: double.infinity,
          child: PageView.builder(
            controller: _pageController,
            itemCount: controller.adlist.length,
            itemBuilder: (BuildContext context, int index) {
              return GestureDetector(
                onTap: () {
                  launch(controller.adlist[index].url!);
                },
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.network(
                      controller.adlist[index].mobileImage!,
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                ),
              );
            },
            onPageChanged: (int index) {
              setState(() {
                _imageCurrentIndex = index;
              });
            },
          ),
        ));
  }

  List<Widget> _buildPageIndicator() {
    List<Widget> list = [];
    for (int i = 0; i < controller.sliderlist.length; i++) {
      list.add(i == _imageCurrentIndex ? _indicator(true) : _indicator(false));
    }
    return list;
  }

  Widget sliderImageContent() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: _buildPageIndicator(),
    );
  }

  Widget _indicator(bool isActive) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4.0),
      height: 10,
      width: 10,
      decoration: BoxDecoration(
        color: isActive ? AppColor.mainClr : AppColor.orange,
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }

  _buildSlider() {
    return Obx(
      () => controller.loading.isFalse
          ? CarouselSlider(
              items: List.generate(controller.sliderlist.length, (index) {
                var data = controller.sliderlist[index];
                return Stack(
                  children: [
                    Container(
                      height: 160,
                      margin: const EdgeInsets.all(15),
                      width: MediaQuery.of(context).size.width,
                      child: GestureDetector(
                        onTap: () {
                          if (data.id == 7) {
                            homeController.makeUrl(data.link.toString());
                          } else {
                            var splitData = data.link.toString();
                            var split = splitData.split('/').last;
                            if (kDebugMode) {
                              print(split);
                            }
                            Get.to(() => ProductDetailView(
                                  productname: data.title,
                                  productprice: data.id.toString(),
                                  slug: split,
                                  productid: data.id,
                                ));
                          }
                        },
                        child: CachedNetworkImage(
                          imageUrl: data.altImage != null
                              ? data.altImage!.replaceAll(
                                  RegExp(r'http://127.0.0.1:8000'), url)
                              : '',
                          imageBuilder: (context, imageProvider) => Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              image: DecorationImage(
                                image: imageProvider,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          placeholder: (context, url) => SizedBox(
                              width: MediaQuery.of(context).size.width,
                              child: Container(
                                decoration:
                                    BoxDecoration(color: Colors.grey.shade300),
                                padding: const EdgeInsets.all(50),
                                child: Image.asset(
                                    "assets/images/Placeholder.png"),
                              )),
                          errorWidget: (context, url, error) => Image.asset(
                            "assets/images/Placeholder.png",
                            height: 70,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 30,
                      right: 10,
                      left: 10,
                      child: sliderImageContent(),
                      /*Padding(
                    padding: const EdgeInsets.only(top: 120, left: 30),
                    child: MaterialButton(
                        color: AppColor.orange,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5)),
                        child: Text(
                          'Explore',
                          style: subtitleStyle.copyWith(
                              color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        onPressed: () {}),
                  )*/
                    )
                  ],
                );
              }),
              options: CarouselOptions(
                autoPlay: true,
                viewportFraction: 1,
                enlargeCenterPage: true,
                height: 200,
                reverse: false,
                initialPage: controller.selectedbanner.value,
                onPageChanged: (i, reason) {
                  controller.selectedbanner.value = i;
                },
              ),
            )
          : CustomShimmer(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.grey.shade100,
              widget: Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                padding: const EdgeInsets.symmetric(
                  horizontal: 8,
                ),
                height: 200,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
            ),
    );
  }

  buildAdCard() {
    return Container(
      width: Device.orientation == Orientation.portrait ? double.infinity : 500,
      height: 180,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: AppColor.mainClr,
        borderRadius: BorderRadius.circular(0),
      ),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                RichText(
                    text: TextSpan(children: <TextSpan>[
                  TextSpan(
                      text: '60% ',
                      style: headingStyle.copyWith(
                          color: Colors.amber, fontStyle: FontStyle.italic)),
                  TextSpan(
                      text: 'OFF',
                      style: headingStyle.copyWith(
                          color: Colors.white, fontStyle: FontStyle.italic)),
                ])),
                Text(
                  'EVERYTHING',
                  style: headingStyle.copyWith(
                      color: Colors.white, fontStyle: FontStyle.italic),
                ),
                const SizedBox(
                  height: 10,
                ),
                MaterialButton(
                    color: AppColor.orange,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5)),
                    child: Text(
                      'Explore',
                      style: subtitleStyle.copyWith(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {})
              ],
            ),
          ),
          Image.asset(
            AppImages.shoes,
            height: 150,
          )
        ],
      ),
    );
  }

  buildHeadertxt(title, ontap, viewall) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: titleStyle.copyWith(fontWeight: FontWeight.bold),
          ),
          viewall
              ? TextButton(
                  onPressed: ontap,
                  child: Text(
                    'View all',
                    style: subtitleStyle,
                  ),
                )
              : Container()
        ],
      ),
    );
  }

  _buildAdTile(img) {
    if (controller.adlist.length - 1 > controller.adIndex.value) {
      controller.adIndex.value++;
    }
    log(controller.adIndex.value.toString());
    return Container(
      height: 80,
      color: Colors.grey.shade300,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Center(
        child: GestureDetector(
            onTap: () {
              //Get.to(() => const MyHome());
            },
            child: CachedNetworkImage(
              imageUrl: img.toString(),
              fit: BoxFit.cover,
              placeholder: (context, url) => SizedBox(
                  width: MediaQuery.of(context).size.width,
                  child: Container(
                    decoration: BoxDecoration(color: Colors.grey.shade300),
                    padding: const EdgeInsets.all(50),
                    child: Image.asset("assets/images/Placeholder.png"),
                  )),
            )),
      ),
    );
  }

  buildDepartmentScroll() {
    return Obx(
      () => categorycontroller.parentLoading.isTrue
          ? SizedBox(
              height: 100,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: ListView.builder(
                    itemCount: 5,
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return CustomShimmer(
                        baseColor: Colors.grey.shade300,
                        highlightColor: Colors.grey.shade100,
                        widget: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 8),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                          ),
                          height: 100,
                          width: 100,
                          decoration: const BoxDecoration(
                            color: Colors.grey,
                            shape: BoxShape.circle,
                          ),
                        ),
                      );
                    }),
              ),
            )
          : Align(
              alignment: Alignment.centerLeft,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ...List.generate(
                      controller.departmentlist.length,
                      (index) => Padding(
                        padding: const EdgeInsets.only(left: 15),
                        child: Column(
                          children: [
                            GestureDetector(
                              onTap: () async {
                                if (await Connectivity().checkConnectivity() ==
                                    ConnectivityResult.none) {
                                  getSnackbar(
                                      message: "No Internet Connection",
                                      error: true,
                                      bgColor: Colors.red);
                                  return;
                                }
                                Get.to(() => DepartmentView(
                                      title: controller
                                          .departmentlist[index].title,
                                      slug:
                                          controller.departmentlist[index].slug,
                                    ));
                              },
                              child: CircleAvatar(
                                radius: 40,
                                backgroundColor: Colors.grey.shade300,
                                backgroundImage: CachedNetworkImageProvider(
                                    '${controller.departmentlist[index].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}'),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              width: 80,
                              child: Center(
                                child: Text(
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  controller.departmentlist[index].title
                                      .toString(),
                                  style: subtitleStyle.copyWith(),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
    );
  }

  buildTopOffersSlider() {
    return Obx(() => controller.topOffersLoading.isTrue
        ? const SizedBox(
            height: 80,
            child: LoadingWidget(),
          )
        : controller.topOffersData.isNotEmpty
            ? SingleChildScrollView(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4, childAspectRatio: 0.8
                      // mainAxisSpacing: 10,
                      // crossAxisSpacing: 10,
                      ),
                  padding:
                      const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                  itemCount: controller.topOffersData.length,
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    return Column(
                      children: [
                        GestureDetector(
                          onTap: () async {
                            if (await Connectivity().checkConnectivity() ==
                                ConnectivityResult.none) {
                              getSnackbar(
                                  message: "No Internet Connection",
                                  error: true,
                                  bgColor: Colors.red);
                              return;
                            }
                            controller.slug =
                                controller.topOffersData[index].slug.toString();
                            Get.to(() => TopOffersScreen(
                                  title: controller.topOffersData[index].title
                                      .toString(),
                                  slug: controller.topOffersData[index].slug
                                      .toString(),
                                ));
                          },
                          child: CircleAvatar(
                            radius: 35,
                            backgroundColor: Colors.grey.shade300,
                            child: CachedNetworkImage(
                              imageUrl: controller.topOffersData[index].image
                                  .toString(),
                              imageBuilder: (context, imageProvider) =>
                                  Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                      image: imageProvider, fit: BoxFit.cover),
                                ),
                              ),
                              placeholder: (context, url) => SizedBox(
                                  width: MediaQuery.of(context).size.width,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade300,
                                      shape: BoxShape.circle,
                                    ),
                                    padding: const EdgeInsets.all(100),
                                    child: Image.asset(
                                        "assets/images/Placeholder.png"),
                                  )),
                              errorWidget: (context, url, error) => Image.asset(
                                "assets/images/Placeholder.png",
                                height: 40,
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          controller.topOffersData[index].title.toString(),
                          style: subtitleStyle,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        )
                      ],
                    );
                  },
                ),
              )
            : Container());
  }

  void checkInternet() async {
    log("LandingView:checkInternet");
    if (await Connectivity().checkConnectivity() == ConnectivityResult.none) {
      hasInternet.value = false;
    } else {
      hasInternet.value = true;
    }
  }
}

class TestTabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar? tabBar;
  final landingcon = Get.put(LandingController());

  TestTabBarDelegate({this.tabBar});

  @override
  double get minExtent => 100;

  @override
  double get maxExtent => 100;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    // landingcon.fetchJustForYou();
    // landingcon.fetchJustForYou();

    return Obx(() => Container(
          color: Colors.white,
          child: DefaultTabController(
            length: landingcon.justForYouTagsList.length,
            child: Obx(
              () => landingcon.tagsLoading.isTrue
                  ? DefaultTabController(
                      length: 3,
                      child: TabBar(
                        tabs: [
                          CustomShimmer(
                            baseColor: Colors.grey.shade300,
                            highlightColor: Colors.grey.shade100,
                            widget: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 8),
                              // padding: const EdgeInsets.symmetric(
                              //   horizontal: 5,
                              // ),
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                  color: Colors.grey, shape: BoxShape.circle),
                            ),
                          ),
                          CustomShimmer(
                            baseColor: Colors.grey.shade300,
                            highlightColor: Colors.grey.shade100,
                            widget: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 8),
                              // padding: const EdgeInsets.symmetric(
                              //   horizontal: 5,
                              // ),

                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                  color: Colors.grey, shape: BoxShape.circle),
                            ),
                          ),
                          CustomShimmer(
                            baseColor: Colors.grey.shade300,
                            highlightColor: Colors.grey.shade100,
                            widget: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 5),
                              // padding: const EdgeInsets.symmetric(
                              //   horizontal: 5,
                              // ),

                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                  color: Colors.grey, shape: BoxShape.circle),
                            ),
                          ),
                        ],
                      ),
                    )
                  : TabBar(
                      key: const PageStorageKey<Type>(TabBar),
                      labelColor: AppColor.orange,
                      indicatorColor: AppColor.orange,
                      indicatorSize: TabBarIndicatorSize.label,
                      labelStyle: subtitleStyle.copyWith(fontSize: 12.sp),
                      unselectedLabelColor: Colors.grey,
                      splashBorderRadius: BorderRadius.circular(50),
                      isScrollable: true,
                      padding: EdgeInsets.zero,
                      labelPadding: EdgeInsets.zero,
                      onTap: (value) async {
                        // print(value);
                        if (await Connectivity().checkConnectivity() ==
                            ConnectivityResult.none) {
                          getSnackbar(
                              message: "No Internet Connection",
                              error: true,
                              bgColor: Colors.red);
                          return;
                        }

                        print(landingcon.justForYouTagsList[value].slug);
                        landingcon.selectedSlug.value = landingcon
                            .justForYouTagsList[value].slug
                            .toString();
                        landingcon.fetchJustForYouBySlug(landingcon
                            .justForYouTagsList[value].slug
                            .toString());
                      },
                      tabs: [
                        ...List.generate(
                          landingcon.justForYouTagsList.length,
                          (index) => SizedBox(
                            height: 100,
                            width: 100,
                            child: Tab(
                              iconMargin: EdgeInsets.only(right: 40),
                              icon: Column(
                                children: [
                                  // CircleAvatar(
                                  //   radius: 40,
                                  //   backgroundColor: Colors.grey.shade300,
                                  //   backgroundImage: CachedNetworkImageProvider(
                                  //       '${landingcon.justForYouTagsList[index].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}'),
                                  // ),
                                  CachedNetworkImage(
                                    imageUrl: landingcon
                                        .justForYouTagsList[index].image
                                        .toString(),
                                    height: 68,
                                    imageBuilder: (context, imageProvider) =>
                                        Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        image: DecorationImage(
                                            image: imageProvider,
                                            scale: 3,
                                            fit: BoxFit.cover),
                                      ),
                                    ),
                                    placeholder: (context, url) => SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: Colors.grey.shade300),
                                          padding: const EdgeInsets.all(100),
                                          child: Image.asset(
                                            "assets/images/Placeholder.png",
                                            height: 20,
                                          ),
                                        )),
                                    errorWidget: (context, url, error) =>
                                        Image.asset(
                                      "assets/images/Placeholder.png",
                                      height: 20,
                                    ),
                                    fit: BoxFit.cover,
                                  ),
                                  const SizedBox(
                                    height: 02,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8.0),
                                    child: Text(
                                      landingcon.justForYouTagsList[index].title
                                              .toString()[0]
                                              .toUpperCase() +
                                          landingcon
                                              .justForYouTagsList[index].title
                                              .toString()
                                              .substring(1),
                                      maxLines: 1,
                                      textAlign: TextAlign.center,
                                      overflow: TextOverflow.ellipsis,
                                      style: subtitleStyle.copyWith(
                                          overflow: TextOverflow.ellipsis),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ));
  }

  @override
  bool shouldRebuild(covariant TestTabBarDelegate oldDelegate) {
    return false;
  }
}
