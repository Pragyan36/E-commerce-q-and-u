import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:usoft/app/data/models/home_model.dart';
import 'package:usoft/app/data/models/justforyou_model.dart';
import 'package:usoft/app/data/models/justforyouproduct_model.dart';
import 'package:usoft/app/data/models/top_offer_product_model.dart';
import 'package:usoft/app/data/models/topoffers_model.dart';
import 'package:usoft/app/data/services/home_service.dart';

import '../../../data/models/specfic_featured_model.dart';
import '../../../model/product_model.dart';

class LandingController extends GetxController {
  var homeData = HomeModelData().obs;
  var sliderlist = <Sliders>[].obs;
  var adlist = <Advertisements>[].obs;
  var departmentlist = <FeaturedCategory>[].obs;
  var featuredlist = <FeaturedSection>[].obs;
  final productsList = <Data>[].obs;
  final specificfeaturedList = <FeaturedProductsList>[].obs;

  final selectedbanner = 0.obs;
  final loading = false.obs;
  var adIndex = 0.obs;
  var numberOfPostsPerRequest = 6.obs;

  var isListview = false.obs;

  //Just for you variables
  var justForYouTagsList = <JustForYouTags>[].obs;
  var tagsLoading = false.obs;

  var justForYouProductsList = <JustForYouProductModelProducts>[].obs;
  var selectedSlug = ''.obs;
  var jfyLoading = false.obs;
  var deparmentshop = false.obs;

  @override
  void onInit() {
    log("LandingController:onInit");
    fetchHome();
    fetchTopOffers();
    fetchJustForYou();
    fetchSpecificFeaturedProducts(specificId);
    fetchProducts();
    fetchTopOffers();
    fetchJustForYouBySlug('');
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  fetchHome() async {
    loading(true);
    var data = await HomeService().getHome();

    if (data != null) {
      // log("LandingController:homeSlider ${data['data']['sliders']}");
      loading(false);
      departmentlist.clear();
      featuredlist.clear();
      sliderlist.clear();
      homeData.value = HomeModelData.fromJson(data['data']);

      data['data']['sliders']
          .forEach((v) => sliderlist.add(Sliders.fromJson(v)));
      data['data']['advertisements']
          .forEach((v) => adlist.add(Advertisements.fromJson(v)));
      data['data']['featured_category']
          .forEach((v) => departmentlist.add(FeaturedCategory.fromJson(v)));
      data['data']['featured_section']
          .forEach((v) => featuredlist.add(FeaturedSection.fromJson(v)));
      if (data['error'] == false) {}
    }
  }

  var page = 1.obs;

  fetchProducts() async {
    loading(true);
    var data = await HomeService().getAllProducts(page.value);
    // log("LandingController:fetchProducts:${data['data']}");
    log("LandingController:fetchProducts:dataReceived}");
    if (data != null) {
      loading(false);
      productsList.clear();
      data['data'].forEach((v) => productsList.add(Data.fromJson(v)));
    }
  }

  var loadingmore = false.obs;

  Rx<ScrollController> scrollcon = ScrollController().obs;

  loadMore() async {
    if (loading.isFalse && loadingmore.isFalse) {
      loadingmore(true);
      page.value += 1;
      var data = await HomeService().getAllProducts(page.value);
      // log(data['data'].toString());
      if (data != null) {
        loadingmore(false);
        data['data'].forEach((v) => productsList.add(Data.fromJson(v)));
      }
    }
  }

  var specificloading = false.obs;

  var specificId = 1.obs;

  fetchSpecificFeaturedProducts(id) async {
    specificloading(true);
    var data = await HomeService().getSpecificFeatured(id);
    log("LandingController:fetchSpecificFeaturedProducts:success");
    // log("LandingController:specific data:$data");
    // log("getSpecificFeaturedProducts :$data");
    // if (data != null) {
    specificloading(false);
    specificfeaturedList.clear();

    if (data['data'] != null) {
      data['data']['product'].forEach(
          (v) => specificfeaturedList.add(FeaturedProductsList.fromJson(v)));
      //  }
    }
  }

  var topOffersData = <TopOfferModelData>[];
  var topOffersLoading = false.obs;

  fetchTopOffers() async {
    topOffersLoading(true);
    var data = await HomeService().getTopOffers();
    // log("LandingController:top offers:$data");
    // log("getSpecificFeaturedProducts :$data");
    if (data != null) {
      topOffersLoading(false);

      topOffersData.clear();
      data['data']
          .forEach((v) => topOffersData.add(TopOfferModelData.fromJson(v)));
    }
  }

  var topOffersProductData = <OfferProducts>[];
  var topOffersProductsLoading = false.obs;
  var slug = '';

  fetchTopOffersProduct() async {
    topOffersProductsLoading(true);
    var data = await HomeService().getTopOffersProducts(slug);
    // log("LandingController:top offers products $data");
    // log("getSpecificFeaturedProducts :$data");
    if (data != null) {
      topOffersProductsLoading(false);

      topOffersProductData.clear();
      data['data']["offer_products"]
          .forEach((v) => topOffersProductData.add(OfferProducts.fromJson(v)));
    }
  }

  fetchJustForYou() async {
    tagsLoading(true);
    var data = await HomeService().getJustForYou();
    log("LandingController:fetchJustForYou:received");
    log("LandingController:fetchJustForYou:data:$data");
    justForYouTagsList.clear();
    if (data != null) {
      tagsLoading(false);

      data['data']['tags']
          .forEach((v) => justForYouTagsList.add(JustForYouTags.fromJson(v)));
    }
    fetchJustForYouBySlug(justForYouTagsList[0].slug);
  }

  fetchJustForYouBySlug(jfySlug) async {
    jfyLoading(true);
    var data = await HomeService()
        .getJustForYouBySlug(jfySlug ?? justForYouTagsList[0].slug.toString());
    log('LandingController:fetchJustForYouBySlug:$data');
    log('LandingController:fetchJustForYouBySlug:dataReceived');

    justForYouProductsList.clear();
    if (data != null) {
      jfyLoading(false);

      data['data']['products'].forEach((v) => justForYouProductsList
          .add(JustForYouProductModelProducts.fromJson(v)));
    }
  }
}
