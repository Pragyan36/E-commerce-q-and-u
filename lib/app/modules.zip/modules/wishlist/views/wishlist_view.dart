import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/widgets/custom_appbar.dart';
import 'package:usoft/app/widgets/custom_shimmer.dart';
import 'package:usoft/app/widgets/loading_widget.dart';
import 'package:usoft/app/widgets/nodata.dart';

import '../../../constants/constants.dart';
import '../../cart/controllers/cart_controller.dart';
import '../../product_detail/views/product_detail_view.dart';
import '../controllers/wishlist_controller.dart';

class WishlistView extends GetView<WishlistController> {
  WishlistView({Key? key}) : super(key: key);

  @override
  final controller = Get.put(WishlistController());
  final cartcontroller = Get.put(CartController());

  @override
  Widget build(BuildContext context) {
    controller.fetchWishlist();
    return Obx(() => Scaffold(
          backgroundColor: Colors.white,
          appBar: CustomAppbar(
            leading: Container(),
            title: 'Wishlist(${controller.wishlistitems.length})',
            trailing: TextButton(
                onPressed: () {
                  controller.deleteAllWishlsit();
                  // controller.fetchWishlist();
                  print('object');
                },
                child: Text(
                  'Delete All',
                  style: subtitleStyle.copyWith(color: AppColor.orange),
                )),
          ),
          body: RefreshIndicator(
            color: AppColor.orange,
            onRefresh: () async {
              await Future.delayed(const Duration(seconds: 1));

              controller.fetchWishlist();
            },
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics()),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Obx(
                  () => controller.isLoading.isFalse
                      ? controller.wishlistitems.isNotEmpty
                          ? Column(
                              children: [
                                ...List.generate(
                                    controller.wishlistitems.length, (index) {
                                  var data = controller.wishlistitems[index];
                                  return _buildWishlistTile(
                                      index: index,
                                      slug: data.slug.toString(),
                                      id: data.id,
                                      img:
                                          '${data.images![0].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}',
                                      name: data.name.toString(),
                                      price: data.getPrice?.specialPrice ??
                                          data.getPrice?.price,
                                      rating: data.rating.toString(),
                                      varientId: data.varientId);
                                }),
                                const SizedBox(
                                  width: 20,
                                ),
                                /*SizedBox(
                                width: double.infinity,
                                child: CustomButton(
                                    label: 'Add to cart',
                                    btnClr: AppColor.orange,
                                    txtClr: Colors.white,
                                    ontap: () {}),
                              )*/
                              ],
                            )
                          : const NoDataView(text: 'Empty Wishlist')
                      : ListView.builder(
                          itemCount: 5,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return CustomShimmer(
                              baseColor: Colors.grey.shade300,
                              highlightColor: Colors.grey.shade100,
                              widget: Container(
                                margin: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 10),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                ),
                                height: 100,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: Colors.grey,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                            );
                          }),
                ),
              ),
            ),
          ),
        ));
  }

  _buildWishlistTile({index, id, slug, img, name, price, rating, varientId}) {
    return ListTile(
      onTap: () {
        Get.to(() => ProductDetailView(
              productname: name,
              productprice: price.toString(),
              slug: slug,
            ));
      },
      visualDensity: const VisualDensity(vertical: 4),
      contentPadding: const EdgeInsets.only(bottom: 10),
      leading: Container(
          height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Colors.grey.shade200,
          ),
          child: CachedNetworkImage(
            imageUrl: img,
            fit: BoxFit.contain,
            height: 120,
            width: 100,
            placeholder: (ctx, t) {
              return Image.asset(
                'assets/images/Placeholder.png',
                fit: BoxFit.contain,
              );

              // const Center(child: CircularProgressIndicator());
            },
          )
          //  Image.network(
          //   img,
          //   height: 120,
          //   width: 100,
          // ),
          ),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
            width: 40.w,
            child: Text(
              name.toString(),
              style: subtitleStyle,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
          ),
          IconButton(
            onPressed: () async {
              await controller.removeFromWishList(id.toString());
              log("_buildWishlistTile id: $id and index: $index");
              controller.wishlistitems.removeAt(index);
              controller.fetchWishlist();
              //update page after removing an item
            },
            icon: const Icon(
              Icons.close,
            ),
          ),
        ],
      ),
      subtitle: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            children: [
              Text(
                "Rs.$price",
                style: subtitleStyle.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(
                width: 20,
              ),
              const Icon(
                Icons.star,
                color: Colors.amber,
              ),
              Text(
                rating,
                style: subtitleStyle,
              ),
            ],
          ),
          const Spacer(),
          IconButton(
            onPressed: () {
              // print(varientId.toString());
              cartcontroller.addToCart(
                id,
                price,
                '1',
                varientId,
              );
            },
            icon: Icon(
              Iconsax.shopping_cart,
              size: 20.sp,
            ),
          ),
        ],
      ),
    );

    // Container(
    //   // margin: const EdgeInsets.symmetric(horizontal: 10),
    //   width: double.infinity,
    //   child:

    //   Row(
    //     mainAxisAlignment: MainAxisAlignment.start,
    //     crossAxisAlignment: CrossAxisAlignment.start,
    //     children: [
    //       Container(
    //         margin: const EdgeInsets.only(bottom: 10),
    //         height: 100,
    //         decoration: BoxDecoration(
    //           borderRadius: BorderRadius.circular(10),
    //           // color: Colors.grey.shade200,
    //         ),
    //         child: Image.asset(
    //           AppImages.shoes,
    //           height: 120,
    //         ),
    //       ),
    //       const SizedBox(
    //         width: 20,
    //       ),
    //       Column(
    //         crossAxisAlignment: CrossAxisAlignment.start,
    //         mainAxisAlignment: MainAxisAlignment.start,
    //         children: [
    //           Text(
    //             'Nike Sportswear Club Fleece',
    //             style: subtitleStyle,
    //           ),
    //           const SizedBox(
    //             height: 10,
    //           ),
    //           Row(
    //             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    //             children: [
    //               Text(
    //                 '49,00 €',
    //                 style: subtitleStyle.copyWith(fontWeight: FontWeight.bold),
    //               ),
    //               const Icon(
    //                 Icons.star,
    //                 color: Colors.amber,
    //               ),
    //               Text(
    //                 '4.8',
    //                 style: subtitleStyle,
    //               ),
    //               Align(
    //                 alignment: Alignment.centerRight,
    //                 child: Icon(
    //                   Iconsax.shopping_cart,
    //                   size: 20.sp,
    //                 ),
    //               )
    //             ],
    //           ),
    //         ],
    //       )
    //     ],
    //   ),
    // );
  }
}
