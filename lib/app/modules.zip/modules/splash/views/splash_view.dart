import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:usoft/app/constants/constants.dart';

import '../controllers/splash_controller.dart';

class SplashView extends GetView<SplashController> {
  SplashView({Key? key}) : super(key: key);
  @override
  final controller = Get.put(SplashController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
              child: Image.asset(AppImages.splash,
                  height: MediaQuery.of(context).size.height,
                  fit: BoxFit.cover)),
          // const SizedBox(
          //   height: 20,
          // ),
          // Text(
          //   'Start your journey with Jhigu Store',
          //   style: titleStyle.copyWith(
          //       fontSize: 24.sp, fontWeight: FontWeight.w400),
          //   textAlign: TextAlign.center,
          // )
        ],
      ),
      // bottomNavigationBar: Padding(
      //   padding: const EdgeInsets.all(20),
      //   child: Row(
      //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //     children: [
      //       CustomButton(
      //         label: 'Register',
      //         txtClr: Colors.white,
      //         btnClr: AppColor.orange,
      //         ontap: () {
      //           Get.toNamed(Routes.REGISTER);
      //         },
      //       ),
      //       CustomButton(
      //         label: 'Login',
      //         btnClr: Colors.white,
      //         txtClr: AppColor.orange,
      //         ontap: () {
      //           if (controller.result.isTrue) {
      //             Get.toNamed(Routes.LOGIN);
      //           } else {
      //             controller.checkInternet();
      //           }
      //         },
      //       ),
      //     ],
      //   ),
      // ),
    );
  }
}
