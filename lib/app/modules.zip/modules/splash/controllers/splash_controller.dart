// ignore_for_file: unnecessary_overrides

import 'dart:developer';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:usoft/app/modules/home/views/home_view.dart';

import '../../../../main.dart';
import '../../../widgets/snackbar.dart';

class SplashController extends GetxController {
  var result = false.obs;

  @override
  void onInit() {
    super.onInit();
    checkInternet();
    nextScreen();
    Future.delayed(const Duration(seconds: 2), () {
      getToken();
    });
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  var firetoken = ''.obs;

  getToken() async {
    log("2. SplashController:getToken:isFirebaseInitialized:$isFirebaseInitialized");
    if (isFirebaseInitialized) {
      log("3. SplashController:getToken:isFirebaseInitialized:isTrue");
      firetoken.value = (await FirebaseMessaging.instance.getToken())!;
    } else {
      /*Initialize Firebase app*/
      await Firebase.initializeApp();
      firetoken.value = (await FirebaseMessaging.instance.getToken())!;
    }
  }

  checkInternet() async {
    result.value = (await InternetConnectionChecker().hasConnection);
    if (result.value == true) {
    } else {
      getSnackbar(bgColor: Colors.red, message: "No internet connection", error: true);
    }
  }

  nextScreen() async {
    await Future.delayed(const Duration(seconds: 2), () {
      Get.offAll(() => const HomeView());
    });
  }
}
