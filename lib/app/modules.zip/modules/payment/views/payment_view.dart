// ignore_for_file: unused_element

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/modules/payment/components/khalti_payment.dart';
import 'package:usoft/app/modules/shipping/controllers/shipping_controller.dart';
import 'package:usoft/app/widgets/custom_appbar.dart';
import 'package:usoft/app/widgets/custom_buttons.dart';

import '../../../widgets/inputfield.dart';
import '../../../widgets/loading_widget.dart';
import '../../../widgets/snackbar.dart';
import '../../cart/controllers/cart_controller.dart';
import '../../shipping/views/purchase_view.dart';
import '../components/esewa_payment.dart';
import '../controllers/payment_controller.dart';
import 'package:intl/intl.dart';

class PaymentView extends GetView<PaymentController> {
  PaymentView({Key? key}) : super(key: key);
  @override
  final controller = Get.put(PaymentController());
  var formatter = NumberFormat('#,###');
  final paymentResponse = Get.put(PaymentController());
  final cartController = Get.put(CartController());
  var couponTextController = TextEditingController();
  final controllerShipping = Get.put(ShippingController());
  final List<Map> paymentTypes = [
    {
      'name': 'Cash',
      'id': 3,
      'icon': const AssetImage("assets/images/payment-method.png"),
      'subtitle': 'Pay by Debit Cash on Delivery'
    },
    {
      'name': 'Esewa',
      'id': 2,
      'icon': const AssetImage("assets/images/Esewa.png"),
      'subtitle': 'Pay online by Esewa'
    },
    {
      'name': 'Khalti',
      'id': 1,
      'icon': const AssetImage("assets/images/Khalti.png"),
      'subtitle': 'Pay online by Khalti'
    },
  ];

  var addressData = Get.arguments;

  @override
  Widget build(BuildContext context) {
    int shippingCharge = addressData[3];
    log("PaymentView:ReceivedArguments:$addressData");
    return Scaffold(
      appBar: CustomAppbar(title: 'Payment'),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ...List.generate(
              paymentTypes.length,
              (index) => GetBuilder<PaymentController>(
                builder: (_) {
                  return RadioListTile(
                      title: Text(
                        paymentTypes[index]['name'],
                        style: titleStyle,
                      ),
                      subtitle: Text(
                        paymentTypes[index]['subtitle'],
                        style: subtitleStyle.copyWith(color: Colors.grey),
                      ),
                      secondary: Image(
                        image: paymentTypes[index]['icon'],
                        height: 20,
                        width: 20,
                      ),
                      value: paymentTypes[index]['id'].toString(),
                      groupValue: controller.select,
                      onChanged: (val) {
                        print(val);
                        controller.setSelectedRadio(val);
                        controller.selected.value = int.parse(val.toString());
                      });
                },
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            /*TextButton(
                onPressed: () {},
                child: Text(
                  '+ Add new card',
                  style: titleStyle,
                )),*/
            /*Row(
              children: <Widget>[
                Expanded(
                  flex: 8,
                  child: MyInputField(
                    hint: 'Email',
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: IconButton(
                      onPressed: () {},
                      icon: Icon(Icons.arrow_right_alt_sharp)),
                ),
              ],
            ),*/
            Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Add Coupon Code',
                  style: subtitleStyle,
                ),
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            ListTile(
              horizontalTitleGap: 0.0,
              title: MyInputField(
                hint: "Check Coupon Code",
                controller: couponTextController,
              ),
              trailing: Container(
                decoration: BoxDecoration(
                  color: Colors.grey,
                  border: Border.all(
                      color: const Color.fromRGBO(0, 0, 0, 0.1), width: 0.0),
                  borderRadius: const BorderRadius.only(
                      topLeft: Radius.zero,
                      topRight: Radius.circular(10),
                      bottomRight: Radius.circular(10)),
                ),
                child: IconButton(
                  onPressed: () async {
                    // print(couponTextController.text);
                    await controller.verifyCouponCode(
                        couponTextController.text, shippingCharge);
                    controller.total_price.value = controller.couponResponse
                            .value.data!.totalCartAmountAfterDiscount!
                            .toInt() +
                        shippingCharge;
                  },
                  icon: const Icon(Icons.arrow_circle_right),
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Obx(
              () => _buildTotal(context),
            )
          ],
        ),
      ),
    );
  }

  _buildRadioListtile(title, subtitle, icon, int val, grpval, onchange) {
    return RadioListTile(
        title: Text(
          title,
          style: titleStyle,
        ),
        subtitle: Text(
          subtitle,
          style: subtitleStyle.copyWith(color: Colors.grey),
        ),
        secondary: Icon(icon),
        value: val,
        groupValue: grpval,
        onChanged: onchange);
  }

  _buildAmountTile(title, total) {
    return ListTile(
      dense: true,
      visualDensity: const VisualDensity(vertical: -3),
      title: Text(
        title,
        style: subtitleStyle.copyWith(color: Colors.grey),
      ),
      trailing: Text(
        total,
        style: subtitleStyle.copyWith(fontWeight: FontWeight.w500),
      ),
    );
  }

  _buildTotal(context) {
    //for sub total
    int? totalPrice = cartController.cartSummary.value.totalAmount!;
    int? totalDiscount = cartController.cartDataList.first.totalDiscount!;
    int? subtotal = totalPrice! + totalDiscount;

    //for total price

    int? couponDiscountPrice =
        controller.couponResponse.value.data?.discountAmount != null
            ? controller!.couponResponse!.value!.data!.discountAmount!.toInt()
            : 0;

    return Obx(() => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            _buildAmountTile(
              'Sub-total',
              'Rs. ${formatter.format(subtotal)}',
            ),
            _buildAmountTile(
              'Vat(%)',
              '${formatter.format(cartController.cartSummary.value.vat)}',
            ),
            _buildAmountTile(
              'Shipping charge',
              'Rs.${formatter.format(addressData[3])}',
            ),
            Obx(
              () => _buildAmountTile(
                'Discount',
                'Rs. ${formatter.format(cartController.cartDataList.first.totalDiscount)}',
              ),
            ),
            Obx(() =>
                controller.couponResponse.value.data?.discountAmount != null
                    ? _buildAmountTile(
                        'Discount from Coupon',
                        'Rs. ${formatter.format(controller.couponResponse.value.data?.discountAmount)}',
                      )
                    : const SizedBox()),
            const Divider(
              thickness: 1.5,
              indent: 20,
              endIndent: 20,
            ),
            Obx(
              () => _buildAmountTile(
                'Total',
                'Rs. ${formatter.format((cartController.cartSummary.value.grandTotal! + controllerShipping.charge.value) - couponDiscountPrice)}',
              ),
            ),
            // Obx(
            //   () => _buildAmountTile(
            //     'Total',
            //     'Rs. ${(controller.couponResponse.value.data?.totalCartAmountAfterDiscount != null ? controller.couponResponse.value.data!.totalCartAmountAfterDiscount! + addressData[3] : controller.total_price + addressData[3])}',
            //     //  ${controller.total_price + addressData[3]}',
            //   ),
            // ),
            const SizedBox(
              height: 20,
            ),
            Obx(
              (() => controller.selected.value == 1
                  ? KhaltiPayment(
                      shippingId: addressData[0].value,
                      billingId: addressData[1].value,
                      same: addressData[2].value,
                      couponCode: couponTextController.text == "" ||
                              controller.couponResponse.value.data
                                      ?.discountAmount ==
                                  null
                          ? ""
                          : couponTextController.text,
                      couponDiscountAmt: controller
                          .couponResponse.value.data?.discountAmount
                          .toString(),
                      shippingcharge: addressData[3],
                    )
                  : controller.selected.value == 2
                      ? EsewaPaymentUI(
                          shippingId: addressData[0].value,
                          billingId: addressData[1].value,
                          same: addressData[2].value,
                          couponCode: couponTextController.text == "" ||
                                  controller.couponResponse.value.data
                                          ?.discountAmount ==
                                      null
                              ? ""
                              : couponTextController.text,
                          couponDiscountAmt: controller
                              .couponResponse.value.data?.discountAmount
                              .toString(),
                          shippingcharge: addressData[3],
                        )
                      : controller.selected.value == 3
                          ? CustomButtons(
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 15),
                              width: double.infinity,
                              label: 'Cash on Delivery',
                              btnClr: AppColor.orange,
                              txtClr: Colors.white,
                              ontap: () async {
                                controller.isCashPaymentConfirmed.value
                                    ? null
                                    : await controller.payByCash(
                                        addressData[0].value,
                                        addressData[1].value,
                                        addressData[2].value,
                                        couponTextController.text == "" ||
                                                controller.couponResponse.value
                                                        .data?.discountAmount ==
                                                    null
                                            ? ""
                                            : couponTextController.text,
                                        controller.couponResponse.value.data
                                            ?.discountAmount);
                                Get.defaultDialog(
                                    title: 'Loading',
                                    content: const LoadingWidget(),
                                    barrierDismissible: false);

                                //to close dialog loading
                                Get.back();
                                if (controller.isCashPaymentConfirmed.value ==
                                    true) {
                                  log("Anish dAKA");
                                  log("kasto" + controller.refId.toString());
                                  // log("lalalala");
                                  Get.to(PurchaseView(
                                    downloadUrl:
                                    paymentResponse.dowloadUrls.toString(),
                                    refId: controller.refId.toString(),
                                    shippingcharge: addressData[3],
                                    couponDiscountPrice:
                                        couponDiscountPrice.toString(),
                                  ));
                                } else {
                                  getSnackbar(
                                      message: "Oops! Something went wrong",
                                      error: true,
                                      bgColor: Colors.red);
                                }
                              })
                          : CustomButtons(
                              width: double.infinity,
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 15),
                              label: /*'Visa'*/ 'Cash on Delivery',
                              btnClr: AppColor.orange,
                              txtClr: Colors.white,
                              ontap: () async {
                                controller.isCashPaymentConfirmed.value
                                    ? null
                                    : await controller.payByCash(
                                        addressData[0].value,
                                        addressData[1].value,
                                        addressData[2].value,
                                        couponTextController.text == "" ||
                                                controller.couponResponse.value
                                                        .data?.discountAmount ==
                                                    null
                                            ? ""
                                            : couponTextController.text,
                                        controller.couponResponse.value.data
                                            ?.discountAmount);
                                Get.defaultDialog(
                                    title: 'Loading',
                                    content: const LoadingWidget(),
                                    barrierDismissible: false);

                                //to close dialog loading
                                Get.back();
                                if (controller.isCashPaymentConfirmed.value ==
                                    true) {
                                  Get.off(PurchaseView(
                                    downloadUrl:
                                        paymentResponse.dowloadUrls.toString(),
                                    refId: controller.refId.toString(),
                                    shippingcharge: addressData[3],
                                    couponDiscountPrice:
                                        couponDiscountPrice.toString(),
                                  ));
                                } else {
                                  getSnackbar(
                                      message: "Oops! Something went wrong",
                                      error: true,
                                      bgColor: Colors.red);
                                }
                              })),
            ),
            const SizedBox(
              height: 20,
            ),
          ],
        ));
  }
}
