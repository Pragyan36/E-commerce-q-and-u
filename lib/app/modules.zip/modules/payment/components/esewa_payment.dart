import 'package:esewa_flutter_sdk/esewa_config.dart';
import 'package:esewa_flutter_sdk/esewa_flutter_sdk.dart';
import 'package:esewa_flutter_sdk/esewa_payment.dart';
import 'package:esewa_flutter_sdk/esewa_payment_success_result.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/widgets/custom_buttons.dart';
import 'package:usoft/app/widgets/custom_dialog.dart';

import '../../../widgets/snackbar.dart';
import '../../../widgets/toast.dart';
import '../../shipping/views/purchase_view.dart';
import '../controllers/payment_controller.dart';

class EsewaPaymentUI extends StatefulWidget {
  const EsewaPaymentUI({
    Key? key,
    required this.shippingId,
    required this.billingId,
    required this.same,
    this.couponCode,
    this.couponDiscountAmt,
    this.shippingcharge,
  }) : super(key: key);

  final int shippingId;
  final int billingId;
  final bool same;
  final String? couponCode;
  final String? couponDiscountAmt;
  final int? shippingcharge;

  @override
  State<EsewaPaymentUI> createState() => _EsewaPaymentUIState();
}

class _EsewaPaymentUIState extends State<EsewaPaymentUI> {
  late EsewaConfig _config;
  final paymentController = Get.put(PaymentController());
  final String TAG = "EsewaPaymentUI";

  @override
  void initState() {
    _config = EsewaConfig(
        clientId: "MB8RBQBTOAofEVMxEgIbBQoVChQcTQ8GBwk=",
        secretId: "WBYWEhYSRRAVEQEEWRIcDRE=",
        environment: Environment.live);
    super.initState();
  }

  esewa() {
    try {
      EsewaFlutterSdk.initPayment(
        esewaConfig: _config,
        esewaPayment: EsewaPayment(
          productId:
              paymentController.orderDetail.value.data!.billId.toString(),
          productName:
              "Zhigu-${paymentController.orderDetail.value.data!.billId}",
          productPrice: paymentController.total_price.toString(),
          // "10",
          callbackUrl: "www.test-url.com",
        ),
        onPaymentSuccess: (EsewaPaymentSuccessResult data) async {
          await paymentController.verifyEsewaPayment(
              data.productId,
              data.productName,
              data.totalAmount,
              data.environment,
              data.code,
              data.merchantName,
              data.message,
              data.status,
              data.refId,
              widget.couponCode,
              widget.couponDiscountAmt,
              widget.shippingId,
              widget.billingId,
              widget.same);
          if (paymentController.isEsewaPaymentVerified.value) {
            Get.off(PurchaseView(
              shippingcharge: widget.shippingcharge!.toInt(),
              couponDiscountPrice: widget.couponDiscountAmt ?? "0",
              refId: paymentController.refId.toString(),
            ));
          } else {
            getSnackbar(
              message: "Esewa Payment couldn't be verified !!!",
              bgColor: Colors.red,
              error: true,
            );
          }
        },
        onPaymentFailure: (data) {},
        onPaymentCancellation: (data) {
          getSnackbar(bgColor: Colors.red, message: data, error: true);
        },
      );
    } on Exception catch (e) {
      debugPrint("EXCEPTION : ${e.toString()}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return CustomButtons(
        margin: const EdgeInsets.symmetric(horizontal: 15),
        width: double.infinity,
        label: 'Pay With Esewa',
        btnClr: Colors.green.shade600,
        txtClr: Colors.white,
        ontap: () async {
          paymentController.esewaLoading.value=true;
          paymentController.isEsewaPaymentVerified.value
              ? null
              : await paymentController.fetchOrderDetail();
          paymentController.esewaLoading.value=false;
          // print(paymentController.orderDetail.value.data?.billId);

          // ignore: use_build_context_synchronously
          CustomDialog().showDialog(
            context: context,
            title:
                'Your order successfully placed. Now proceed for payment !!!',
            // subtitle: paymentController.billId,
            actions: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  CustomButtons(
                    width: 100,
                    label: 'Cancel',
                    btnClr: AppColor.orange,
                    txtClr: Colors.white,
                    ontap: () {
                      const cancelsnackBar = SnackBar(
                        content: Text('Payment Cancelled'),
                      );
                      ScaffoldMessenger.of(context).showSnackBar(cancelsnackBar);
                      Get.back();
                    },
                  ),

                  CustomButtons(
                    width: 100,
                    label: 'Ok',
                    btnClr: const Color(0xff5D3AC1),
                    txtClr: Colors.white,
                    ontap: () {
                      Get.close(1);
                      toastMsg(message: "Esewa payment");
                      esewa();
                    },
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),

              const SizedBox(
                height: 20,
              ),
            ],
          );

          // Get.defaultDialog(
          //     title: "Order Generated !!!",
          //     content: Text(
          //       paymentController.billId,
          //       style: const TextStyle(
          //           color: Colors.red, fontWeight: FontWeight.bold),
          //     ),
          //     onConfirm: () {
          //       Get.close(1);
          //       toastMsg(message: "Esewa payment");
          //       esewa();
          //     },
          //     onCancel: () {
          //       Get.close(1);
          //       toastMsg(message: "Cancelled");
          //     });

          // paymentController.verifyEsewaPayment(
          //     "productId",
          //     "productName",
          //     "totalAmount",
          //     "environment",
          //     "code",
          //     "merchantName",
          //     "message",
          //     "date",
          //     "status",
          //     "refId",
          //     "shippingAddressId",
          //     "billingAddressId",
          //     "same");
        });
  }
}
