// ignore_for_file: import_of_legacy_library_into_null_safe, depend_on_referenced_packages, library_prefixes, avoid_print

import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:latlong2/latlong.dart' as latLng;
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:usoft/app/modules/home/controllers/map_controller.dart';

import '../../../constants/constants.dart';
import '../../../model/address.dart';
import '../../../widgets/custom_button.dart';
import '../controllers/home_controller.dart';

class MapView extends StatelessWidget {
  MapView({Key? key}) : super(key: key);

  final controller = Get.put(MapViewController());
  final homecontroller = Get.put(HomeController());
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          height: MediaQuery.of(context).size.height,
          child: Stack(
            children: [
              Obx(
                () => FlutterMap(
                  options: MapOptions(
                      center: latLng.LatLng(27.7172, 85.3240),
                      zoom: 12,
                      onTap: (pos, latLng) async {
                        List<Placemark> placemarks =
                            await placemarkFromCoordinates(
                                latLng.latitude, latLng.longitude);
                        List<Address> address = [
                          Address(
                              adminArea: placemarks.last.administrativeArea,
                              subAdminArea: placemarks.last.subLocality,
                              postalCode: placemarks.last.postalCode,
                              addressLine: placemarks.last.locality,
                              featureName: placemarks.last.name,
                              countryName: placemarks.last.country,
                              coordinates: Coordinates(
                                  latLng.latitude, latLng.longitude))
                        ];
                        controller.address.value = address;
                        // controller.address.value = await Geocoder.local
                        //     .findAddressesFromCoordinates(
                        //         Coordinates(latLng.latitude, latLng.longitude));
                        controller.lat.value = latLng.latitude;
                        controller.lon.value = latLng.longitude;
                        log(controller.address.first.addressLine.toString());
                        // Get.defaultDialog(content: Text(latLng.latitude.toString()));
                      }),
                  layers: [
                    TileLayerOptions(
                      urlTemplate:
                          "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                      userAgentPackageName: 'com.example.app',
                      backgroundColor: Colors.white,
                    ),
                    MarkerLayerOptions(
                      markers: [
                        Marker(
                          width: 80.0,
                          height: 80.0,
                          point: latLng.LatLng(
                              controller.lat.value, controller.lon.value),
                          builder: (ctx) => Icon(Icons.location_on_outlined,
                              size: 25.sp, color: Colors.red),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10, left: 20, right: 20),
                child: Obx(
                  () => Card(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(10),
                      leading: Icon(
                        Icons.location_on_outlined,
                        size: 24.sp,
                        color: Colors.black54,
                      ),
                      title: Text(
                        // controller.location.value,
                        controller.address.isNotEmpty
                            ? controller.address.first.featureName!
                            : 'Choose location',
                        style: titleStyle,
                      ),
                      // subtitle: Text(
                      //   'data',
                      //   style: subtitleStyle,
                      // ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 85, right: 20),
                child: Align(
                  alignment: Alignment.bottomRight,
                  child: SizedBox(
                    width: 130,
                    child: MaterialButton(
                        elevation: 5,
                        height: 40,
                        color: Colors.green.shade700,
                        onPressed: () async {
                          Position position =
                              await controller.getGeoLocationPosition();
                          var location =
                              'Lat: ${position.latitude} , Long: ${position.longitude}';
                          log(location);
                          controller.lat.value = position.latitude;
                          controller.lon.value = position.longitude;
                          List<Placemark> placemarks =
                              await placemarkFromCoordinates(
                                  position.latitude, position.longitude);
                          List<Address> address = [
                            Address(
                                adminArea: placemarks.last.administrativeArea,
                                subAdminArea: placemarks.last.subLocality,
                                postalCode: placemarks.last.postalCode,
                                addressLine: placemarks.last.locality,
                                featureName: placemarks.last.name,
                                countryName: placemarks.last.country,
                                coordinates: Coordinates(
                                    position.latitude, position.longitude))
                          ];
                          controller.address.value = address;
                          // controller.address.value = await Geocoder.local
                          //     .findAddressesFromCoordinates(Coordinates(
                          //         position.latitude, position.longitude));
                          controller.getAddressFromLatLong(position);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.location_on_sharp,
                              color: Colors.white,
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              'Locate Me',
                              style:
                                  subtitleStyle.copyWith(color: Colors.white),
                            ),
                          ],
                        )),
                  ),
                ),
              )
            ],
          ),
        ),
        floatingActionButton: Padding(
          padding: const EdgeInsets.all(20),
          child: SizedBox(
            width: double.infinity,
            child: CustomButton(
                label: 'Confirm Location',
                btnClr: AppColor.orange,
                txtClr: Colors.white,
                ontap: () {
                  controller.location.value =
                      controller.address.first.featureName!;
                  homecontroller.location(
                      controller.address.first.featureName.toString());
                  // print(controller.location.value);
                  Get.back();
                }),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }
}
