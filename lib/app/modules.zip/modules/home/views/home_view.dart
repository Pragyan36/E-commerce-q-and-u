import 'dart:developer';
import 'dart:io';
import 'dart:ui';

import 'package:badges/badges.dart' as bag;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_facebook_keyhash/flutter_facebook_keyhash.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';
import 'package:usoft/app/constants/constants.dart';
import 'package:usoft/app/modules/account/views/account_view.dart';
import 'package:usoft/app/modules/cart/controllers/cart_controller.dart';
import 'package:usoft/app/modules/cart/views/cart_view.dart';
import 'package:usoft/app/modules/category/views/category_view.dart';
import 'package:usoft/app/modules/landing/views/landing_view.dart';
import 'package:usoft/app/modules/wishlist/controllers/wishlist_controller.dart';
import 'package:usoft/app/modules/wishlist/views/wishlist_view.dart';
import 'package:usoft/app/widgets/custom_buttons.dart';

import '../../../database/app_storage.dart';
import '../controllers/home_controller.dart';

class HomeView extends StatefulWidget {
  const HomeView({Key? key}) : super(key: key);

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final controller = Get.put(HomeController());

  // final landingController = Get.put(LandingController());
  final wishListController = Get.put(WishlistController());
  final cartcontroller = Get.put(CartController());
  int _imageCurrentIndex = 0;
  final PageController _pageController = PageController(initialPage: 0);

  // var _children = <Widget>[];

  final List<Widget> screens = [
    // const Home(),
    const LandingView(),
    const CategoryView(),
    CartView(),
    WishlistView(),
    AccountView()
  ];

  @override
  void initState() {
    log("HomeView:initState");
    log("TOKEN:HomeView${AppStorage.readAccessToken}");

    SchedulerBinding.instance.scheduleFrameCallback((timeStamp) {
      wishListController.fetchWishlist();
    });
    printKeyHash();
    // wishListController.fetchWishlist();
    super.initState();
  }

  TextStyle _textStyle = TextStyle(
    color: Colors.black,
  );

  void printKeyHash() async {
    String? key = await FlutterFacebookKeyhash.getFaceBookKeyHash ??
        'Unknown platform version';
    print("hash key is ${key ?? ""}");
  }

  @override
  Widget build(BuildContext context) {
    log("HomeView:onWidgetBuild");
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        // Status bar color
        statusBarColor: Colors.white,
        //for black text and icons on Android
        statusBarIconBrightness: Brightness.dark,

        statusBarBrightness: Brightness.light, //for black text and icons on IOS
      ),
      child: Obx(
        () => WillPopScope(
          onWillPop: () async {
            final shoulpop = await Get.defaultDialog<bool>(
              backgroundColor: Colors.transparent,
              contentPadding: EdgeInsets.zero,
              titlePadding: const EdgeInsets.symmetric(horizontal: 20),
              title: '',
              content: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 1, sigmaY: 1),
                child: Wrap(
                  children: [
                    Stack(
                      children: [
                        Container(
                          alignment: Alignment.topCenter,
                          margin: const EdgeInsets.only(top: 30),
                          padding: const EdgeInsets.only(
                              top: 50, left: 20, right: 20),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20)),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Column(
                                children: [
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10.0),
                                    child: Text(
                                      'Do You Want to Exit the App?',
                                      // maxLines: 1,
                                      style: Theme.of(context)
                                          .textTheme
                                          .headlineSmall
                                          ?.copyWith(
                                              fontWeight: FontWeight.w700,
                                              fontSize: 13,
                                              letterSpacing: 2,
                                              color: Colors.black),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                ],
                              ),
                              // SizedBox(height: buttonHeight ?? 20),
                              SizedBox(
                                height: 20,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Container(
                                      width: 100,
                                      child: ElevatedButton(
                                        child: Text('No'),
                                        style: ElevatedButton.styleFrom(
                                          primary: Colors.green, // Set the button's background color
                                        ),
                                        onPressed: () {
                                          Navigator.of(context).pop(
                                              false); // Return false to prevent exiting
                                        },
                                      ),
                                    ),
                                    SizedBox(
                                      width: 30,
                                    ),
                                    Container(
                                      width: 100,
                                      child: ElevatedButton(
                                        child: Text('Yes'),
                                        style: ElevatedButton.styleFrom(
                                          primary: AppColor
                                              .orange, // Set the button's background color
                                        ),
                                        onPressed: () {
                                          exit(0); // Return true to exit
                                        },
                                      ),
                                    ),
                                    SizedBox(
                                      height: 15,
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),

                        //For displaying the emoji
                        // Positioned(
                        //     right: 0,
                        //     left: 0,
                        //     top: 0,
                        //     child: CircleAvatar(
                        //       radius: 48 + 2,
                        //       backgroundColor: Colors.white,
                        //       child: CircleAvatar(
                        //         radius: 48,
                        //         backgroundColor: Colors.white,
                        //         child: CircleAvatar(
                        //             radius: 35,
                        //             child: Image.asset(
                        //               'assets/images/appicon.png',
                        //               width: 100,
                        //               height: 100,
                        //               fit: BoxFit.cover,
                        //             )),
                        //       ),
                        //     ))
                      ],
                    ),
                  ],
                ),
              ),
            );
            // final shoulpop = await Get.defaultDialog<bool>(
            //     radius: 15,
            //     title: 'Exit App',
            //     middleText: 'Do you want to exit?',
            //     cancel: TextButton(
            //         onPressed: () {
            //           Get.back();
            //         },
            //         child: Text(
            //           'No',
            //           style: titleStyle,
            //         )),
            //     confirm: TextButton(
            //         onPressed: () {
            //           exit(0);
            //         },
            //         child: Text(
            //           'Yes',
            //           style: titleStyle,
            //         )),
            //     onConfirm: () {
            //       log('object');
            //     });
            return shoulpop!;
          },
          child: Scaffold(
            backgroundColor: Colors.white,
            body: IndexedStack(
              index: controller.selectedindex.value,
              children: screens,
            ),
            bottomNavigationBar: BottomNavigationBar(
              backgroundColor: Colors.white,
              selectedItemColor: Colors.black,
              elevation: 5,
              selectedIconTheme: IconThemeData(color: Colors.black),
              selectedLabelStyle: const TextStyle(color: Colors.black),
              // enableFeedback: true,
              showUnselectedLabels: false,
              // type: BottomNavigationBarType.fixed,
              items: <BottomNavigationBarItem>[
                const BottomNavigationBarItem(
                  icon: Icon(
                    Iconsax.home,
                    color: Colors.black,
                  ),
                  label: 'Home',
                ),
                const BottomNavigationBarItem(
                  icon: Icon(
                    Iconsax.category,
                    color: Colors.black,
                  ),
                  label: 'Category',
                ),
                BottomNavigationBarItem(
                  icon: bag.Badge(
                    badgeContent: Text(
                      '${cartcontroller.cartAssetsList.length}',
                      style: const TextStyle(color: Colors.white),
                    ),
                    child: const Icon(
                      Iconsax.shopping_cart,
                      color: Colors.black,
                    ),
                  ),
                  label: 'Cart',
                ),
                const BottomNavigationBarItem(
                  icon: Icon(
                    Iconsax.heart,
                    color: Colors.black,
                  ),
                  label: 'Wishlist',
                ),
                const BottomNavigationBarItem(
                  icon: Icon(
                    Iconsax.more_circle,
                    color: Colors.black,
                  ),
                  label: 'More',
                ),
              ],

              currentIndex: controller.selectedindex.value,
              unselectedItemColor: Colors.grey,
              onTap: controller.onItemTapped,
            ),
          ),
        ),
      ),
    );
  }
}

//===============================================================
//===============================================================
//===============================================================
//===============================================================
//===============================================================
//===============================================================

/*class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final controller = Get.put(HomeController());

  final wishlistcontroller = Get.put(WishlistController());
  final cartcontroller = Get.put(CartController());
  final categorycontroller = Get.put(CategoryController());

  final mapcontroller = Get.put(MapViewController());
  late ScrollController scrollcontroller;

  final List<String> departments = [
    'Sale',
    'Women',
    'Men',
    'Kids',
    'Young',
    'old',
    'Shoes'
  ];

  @override
  void initState() {
    scrollcontroller = ScrollController()..addListener(_scrollListener);
    controller.fetchSlider();
    controller.fetchTopRanked();
    categorycontroller.fetchParentCategory();
    cartcontroller.fetchCart();
    super.initState();
  }

  // @override
  // void dispose() {
  //   scrollcontroller.removeListener(_scrollListener);

  //   super.dispose();
  // }

  void _scrollListener() {
    log("-__${scrollcontroller.position.extentAfter}");
    if (scrollcontroller.position.extentAfter < 100) {
      //log('object');
      controller.numberOfPostsPerRequest.value += 4;
      controller.fetchProducts();
    }
    // if (scrollcontroller.position.extentAfter > 2300) {
    //   log('min scroll extent');
    //   controller.tapdown(true);
    // } else if (scrollcontroller.position.extentAfter < 2300) {
    //   controller.tapdown(false);
    // }
  }

  @override
  Widget build(BuildContext context) {
    // final List<Map> banners = [
    //   {'banner': buildAdCard(), 'id': 0},
    //   {'banner': buildAdCard(), 'id': 1},
    //   {'banner': buildAdCard(), 'id': 2},
    // ];
    log("${controller.adsList}");

    // controller.fetchAds();
    // categorycontroller.fetchParentCategory();
    // controller.fetchParentCategory();

    return SafeArea(
      child: DefaultTabController(
        length: 8,
        child: ExtendedNestedScrollView(
            controller: scrollcontroller,
            physics: const BouncingScrollPhysics(),
            onlyOneScrollInBody: true,
            floatHeaderSlivers: true,
            headerSliverBuilder: (context, value) {
              return [
                SliverToBoxAdapter(
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 10,
                      ),
                      _buildHomeTop(),
                      _buildLocation(),

                      _buildSlider(),
                      const SizedBox(
                        height: 10,
                      ),

                      // buildDiscoverSlider(),
                      const SizedBox(
                        height: 10,
                      ),
                      buildHeadertxt('Our top offers', () {}, false),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            ...List.generate(
                                5,
                                (index) => Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 10, horizontal: 10),
                                      child: Column(
                                        children: [
                                          Column(
                                            children: [
                                              const CircleAvatar(
                                                radius: 35,
                                                backgroundColor: Colors.orange,
                                                backgroundImage: AssetImage(
                                                    AppImages.bestSeller),
                                              ),
                                              const SizedBox(height: 10),
                                              Text(
                                                'Best Price',
                                                style: subtitleStyle,
                                              )
                                            ],
                                          ),
                                          const SizedBox(height: 20),
                                          Column(
                                            children: [
                                              const CircleAvatar(
                                                radius: 35,
                                                backgroundColor: Colors.red,
                                                backgroundImage: AssetImage(
                                                    AppImages.bestSeller),
                                              ),
                                              const SizedBox(height: 10),
                                              Text(
                                                'Best Price',
                                                style: subtitleStyle,
                                              )
                                            ],
                                          ),
                                        ],
                                      ),
                                    ))
                          ],
                        ),
                      ),
                      // Obx(
                      //   () => DotsIndicator(
                      //     dotsCount: banners.length,
                      //     position: controller.selectedbanner.value.toDouble(),
                      //     decorator:
                      //         const DotsDecorator(activeColor: AppColor.orange),
                      //   ),
                      // ),
                      const SizedBox(
                        height: 10,
                      ),
                      Obx(() => controller.adsList.isNotEmpty
                          ? _buildAdTile(controller
                              .adsList[controller.adIndex.value]
                              .ads
                              ?.mobileImage
                              ?.replaceAll(
                                  RegExp(r'http://127.0.0.1:8000'), url))
                          : Container()),
                      const SizedBox(
                        height: 10,
                      ),
                      buildHeadertxt('Shop by Department', () {
                        Get.to(
                          () => const DepartmentViewAllView(),
                        );
                      }, false),
                      const SizedBox(
                        height: 20,
                      ),
                      buildDepartmentScroll(),
                      const SizedBox(
                        height: 20,
                      ),
                      FeaturedProductsView(),
                      // const SizedBox(
                      //   height: 20,
                      // ),
                      // buildRecommendedScroll(),
                      const SizedBox(
                        height: 10,
                      ),
                      // Obx(() => controller.adsList.isNotEmpty
                      //     ? _buildAdTile(controller
                      //         .adsList[controller.adIndex.value]
                      //         .ads
                      //         ?.mobileImage
                      //         ?.replaceAll(
                      //             RegExp(r'http://127.0.0.1:8000'), url))
                      //     : Container()),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        'Just For You',
                        style: titleStyle,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                    ],
                  ),
                ),
                SliverPersistentHeader(
                    floating: true,
                    pinned: true,
                    delegate: TestTabBarDelegate()),
                // SliverAppBar(
                //   floating: true,
                //   pinned: true,
                //   toolbarHeight: 0,
                //   backgroundColor: Colors.white,
                //   elevation: 0,
                //   bottom: PreferredSize(
                //       preferredSize: const Size(double.infinity, 75),
                //       child: Container(
                //         color: Colors.white,
                //         child: TabBar(
                //           labelColor: AppColor.orange,
                //           indicatorColor: AppColor.orange,
                //           indicatorSize: TabBarIndicatorSize.label,
                //           labelStyle: subtitleStyle.copyWith(fontSize: 12.sp),
                //           unselectedLabelColor: Colors.grey,
                //           splashBorderRadius: BorderRadius.circular(50),
                //           isScrollable: true,
                //           tabs: const [
                //             SizedBox(
                //               width: 40,
                //               child: Tab(
                //                 icon: Icon(
                //                   Icons.home,
                //                   size: 20,
                //                 ),
                //                 text: 'All',
                //               ),
                //             ),
                //             SizedBox(
                //               width: 40,
                //               child: Tab(
                //                 icon: Icon(
                //                   Icons.local_mall,
                //                   size: 20,
                //                 ),
                //                 text: 'Mall',
                //               ),
                //             ),
                //             Tab(
                //               icon: Icon(
                //                 Iconsax.shop5,
                //                 size: 20,
                //               ),
                //               text: 'Fashion',
                //             ),
                //             Tab(
                //               icon: Icon(
                //                 Icons.girl,
                //                 size: 20,
                //               ),
                //               text: 'Beauty',
                //             ),
                //             Tab(
                //               icon: Icon(
                //                 Icons.radar,
                //                 size: 20,
                //               ),
                //               text: 'Asar ko Bahra',
                //             ),
                //             Tab(
                //               icon: Icon(
                //                 Icons.scale_sharp,
                //                 size: 20,
                //               ),
                //               text: 'Sales',
                //             ),
                //             Tab(
                //               icon: Icon(
                //                 Icons.money,
                //                 size: 20,
                //               ),
                //               text: 'dicounts',
                //             ),
                //             Tab(
                //               icon: Icon(
                //                 Iconsax.sun,
                //                 size: 20,
                //               ),
                //               text: 'Summer',
                //             ),
                //           ],
                //         ),
                //       )),
                // ),
              ];
            },
            body:
                // Container()
                TestHomePageBody(
              scrollController: scrollcontroller,
            )
            // TabBarView(children: List.generate(8, (index) => _buildTabs())),
            // Container(
            //   width: double.infinity,
            //   height: double.infinity,
            //   color: Colors.white,
            //   child: Column(
            //     children: [
            //       Expanded(
            //         child: TabBarView(children: [
            //           // _buildWrap(),
            //           // _buildWrap(),
            //           // _buildWrap(),
            //           // _buildWrap(),
            //           // _buildWrap(),
            //           // _buildWrap(),
            //           // _buildWrap(),
            //           // _buildWrap(),
            //           _buildTabs(),
            //           _buildTabs(),
            //           _buildTabs(),
            //           _buildTabs(),
            //           _buildTabs(),
            //           _buildTabs(),
            //           _buildTabs(),
            //           _buildTabs(),
            //         ]),
            //       ),
            //     ],
            //   ),
            // ),
            ),
      ),
    );
  }

  _buildHomeTop() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        const SizedBox(
          width: 10,
        ),
        Image.asset(
          AppImages.logo,
          width: 80,
        ),
        const Flexible(child: CustomSearchBar()),
        const SizedBox(
          width: 5,
        ),
        CircleAvatar(
          backgroundColor: AppColor.mainClr,
          radius: 18,
          child: Center(
            child: Obx(
              () => Badge(
                badgeContent: Text(
                  controller.notifications.length.toString(),
                  style: const TextStyle(color: Colors.white),
                ),
                showBadge: controller.notifications.isEmpty ? false : true,
                position: BadgePosition.topEnd(end: -5, top: -5),
                badgeColor: AppColor.orange,
                child: IconButton(
                    onPressed: () {
                      Get.toNamed(Routes.NOTIFICATION);
                    },
                    padding: EdgeInsets.zero,
                    icon: Icon(
                      Iconsax.notification,
                      color: Colors.white,
                      size: 18.sp,
                    )),
              ),
            ),
          ),
        ),
        const SizedBox(
          width: 10,
        ),
      ],
    );
  }

  buildAdCard() {
    return Container(
      width: Device.orientation == Orientation.portrait ? double.infinity : 500,
      height: 180,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: AppColor.mainClr,
        borderRadius: BorderRadius.circular(0),
      ),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                RichText(
                    text: TextSpan(children: <TextSpan>[
                  TextSpan(
                      text: '60% ',
                      style: headingStyle.copyWith(
                          color: Colors.amber, fontStyle: FontStyle.italic)),
                  TextSpan(
                      text: 'OFF',
                      style: headingStyle.copyWith(
                          color: Colors.white, fontStyle: FontStyle.italic)),
                ])),
                Text(
                  'EVERYTHING',
                  style: headingStyle.copyWith(
                      color: Colors.white, fontStyle: FontStyle.italic),
                ),
                const SizedBox(
                  height: 10,
                ),
                MaterialButton(
                    color: AppColor.orange,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5)),
                    child: Text(
                      'Explore',
                      style: subtitleStyle.copyWith(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {})
              ],
            ),
          ),
          Image.asset(
            AppImages.shoes,
            height: 150,
          )
        ],
      ),
    );
  }

  buildHeadertxt(title, ontap, viewall) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: titleStyle.copyWith(fontWeight: FontWeight.bold),
          ),
          viewall
              ? TextButton(
                  onPressed: ontap,
                  child: Text(
                    'View all',
                    style: subtitleStyle,
                  ),
                )
              : Container()
        ],
      ),
    );
  }

  buildDepartmentScroll() {
    return Obx(
      () => Align(
        alignment: Alignment.centerLeft,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ...List.generate(
                categorycontroller.parentcategoryList.length,
                (index) => Padding(
                  padding: const EdgeInsets.only(left: 15),
                  child: Column(
                    children: [
                      GestureDetector(
                        onTap: (() => Get.to(() => DepartmentView(
                              title: categorycontroller
                                  .parentcategoryList[index].title,
                              slug: categorycontroller
                                  .parentcategoryList[index].slug,
                            ))),
                        child: CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.grey.shade300,
                            backgroundImage: CachedNetworkImageProvider(
                                '${categorycontroller.parentcategoryList[index].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}')),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        width: 80,
                        child: Center(
                          child: Text(
                            categorycontroller.parentcategoryList[index].title
                                .toString(),
                            style: subtitleStyle,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  // _buildTabs() {
  //   return Obx(() => GestureDetector(
  //         // onPanUpdate: (details) {
  //         //   if (details.delta.dy > 0) {
  //         //     log('beoo');
  //         //   }
  //         // },
  //         child: GridView.builder(
  //             itemCount: controller.productsList.length,
  //             addAutomaticKeepAlives: true,
  //             controller: scrollcontroller,
  //             shrinkWrap: true,
  //             physics: const NeverScrollableScrollPhysics(),
  //             padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
  //             gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
  //               crossAxisCount: 2,
  //               childAspectRatio:
  //                   Device.orientation == Orientation.portrait ? 1 / 1.45 : 1.4,
  //               crossAxisSpacing: 10,
  //               mainAxisSpacing: 15,
  //             ),
  //             itemBuilder: (context, index) {
  //               var data = controller.productsList[index];
  //
  //               return ProductCard(
  //                 price: data.id.toString(),
  //                 productImg:
  //                     '${data.images?[0].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}',
  //                 productName: data.name,
  //                 rating: data.rating.toString(),
  //               );
  //             }),
  //       ));
  // }

  // This is unused widget
  // _buildWrap() {
  //   return Align(
  //       alignment: Alignment.topCenter,
  //       child: Obx(() => Wrap(
  //             crossAxisAlignment: WrapCrossAlignment.start,
  //             runAlignment: WrapAlignment.start,
  //             runSpacing: 10,
  //             spacing: 10,
  //             children: [
  //               // SizedBox(
  //               //     height: (controller.productsList.length) * 145,
  //               //     child: ListView.builder(
  //               //         itemCount: controller.productsList.length,
  //               //         itemBuilder: (context, index) {
  //               //           var data = controller.productsList[index];
  //
  //               //           return SizedBox(
  //               //             width: 45.w,
  //               //             child: ProductCard(
  //               //               price: data.price.toString(),
  //               //               productImg: data.image,
  //               //               productName: data.title,
  //               //               rating: data.rating!.rate.toString(),
  //               //               ontapFavorite: () {
  //               //                 wishlistcontroller.addToWishList(
  //               //                   data.id,
  //               //                   data.image,
  //               //                   data.price,
  //               //                   data.title,
  //               //                 );
  //               //                 toastMsg(message: 'Added to wishlist');
  //               //               },
  //               //               ontap: () {
  //               //                 Get.to(() => ProductDetailView(
  //               //                     productname: data.title,
  //               //                     productprice: data.price.toString()));
  //               //               },
  //               //             ),
  //               //           );
  //               //         })),
  //
  //               ...List.generate(controller.productsList.length, (index) {
  //                 var data = controller.productsList[index];
  //
  //                 return SizedBox(
  //                   width: 45.w,
  //                   child: ProductCard(
  //                     price: data.id.toString(),
  //                     productImg:
  //                         '${data.images?[0].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}',
  //                     productName: data.name,
  //                     rating: data.rating.toString(),
  //                     ontapFavorite: () {
  //                       wishlistcontroller.addToWishList(
  //                         data.id,
  //                       );
  //                       toastMsg(message: 'Added to wishlist');
  //                     },
  //                     ontap: () {
  //                       Get.to(() => ProductDetailView(
  //                           productname: data.name,
  //                           productprice: data.id.toString()));
  //                     },
  //                   ),
  //                 );
  //               })
  //             ],
  //           )));
  // }

  _buildLocation() {
    return TextButton(
      onPressed: () {
        Get.to(() => MapView());
      },
      child: Row(
        children: [
          Icon(
            Iconsax.location,
            size: 18.sp,
            color: Colors.black,
          ),
          const SizedBox(
            width: 10,
          ),
          Text(
            'Delivery To ',
            style: subtitleStyle.copyWith(fontWeight: FontWeight.w100),
          ),
          Obx(
            () => Text(
              mapcontroller.location.value,
              style: subtitleStyle.copyWith(fontWeight: FontWeight.bold),
            ),
          ),
          const Icon(
            Icons.arrow_drop_down_rounded,
            color: Colors.black,
            size: 30,
          )
        ],
      ),
    );
  }

  _buildSlider() {
    return Obx(
      () => CarouselSlider(
        items: List.generate(controller.sliderList.length, (index) {
          return Stack(
            children: [
              SizedBox(
                // height: 160,
                width: MediaQuery.of(context).size.width,
                child: CachedNetworkImage(
                  imageUrl: controller.sliderList[index].image!
                      .replaceAll(RegExp(r'http://127.0.0.1:8000'), url),
                  placeholder: (context, url) => const SizedBox(
                      height: 50,
                      width: 50,
                      child: CircularProgressIndicator()),
                  errorWidget: (context, url, error) => const Icon(Icons.error),
                  fit: BoxFit.cover,
                ),
              ),
              // Padding(
              //   padding: const EdgeInsets.only(top: 120, left: 30),
              //   child: MaterialButton(
              //       color: AppColor.orange,
              //       shape: RoundedRectangleBorder(
              //           borderRadius: BorderRadius.circular(5)),
              //       child: Text(
              //         'Explore',
              //         style: subtitleStyle.copyWith(
              //             color: Colors.white, fontWeight: FontWeight.bold),
              //       ),
              //       onPressed: () {}),
              // )
            ],
          );
        }),
        options: CarouselOptions(
            autoPlay: true,
            viewportFraction: 1,
            enlargeCenterPage: false,
            height: 200,
            initialPage: controller.selectedbanner.value,
            onPageChanged: (i, reason) {
              controller.selectedbanner.value = i;
            }),
      ),
    );
  }

  _buildAdTile(img) {
    if (controller.adsList.length - 1 > controller.adIndex.value) {
      controller.adIndex.value++;
    }
    log("${controller.adIndex.value}");
    return Container(
      height: 80,
      color: Colors.grey.shade300,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Center(
        child: GestureDetector(
            onTap: () {
              //Get.to(() => const MyHome());
            },
            child: CachedNetworkImage(
              imageUrl: img.toString(),
              fit: BoxFit.fitWidth,
            )),
      ),
    );
  }

  buildDiscoverSlider() {
    final List<MaterialColor> colors = [
      Colors.red,
      Colors.green,
      Colors.purple,
      Colors.blue
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          const SizedBox(
            width: 5,
          ),
          ...List.generate(
            4,
            (index) => Container(
              margin: const EdgeInsets.symmetric(horizontal: 5),
              padding: const EdgeInsets.symmetric(horizontal: 8),
              height: 55,
              width: 110,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: colors[index],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Discover',
                    style: subtitleStyle.copyWith(
                      color: Colors.white,
                    ),
                  ),
                  FittedBox(
                    child: Text(
                      'New Products',
                      style: subtitleStyle.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 15.sp,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}*/

/*class TestTabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabController? controller;

  TestTabBarDelegate({this.controller});

  @override
  double get minExtent => kToolbarHeight;

  @override
  double get maxExtent => kToolbarHeight;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Theme.of(context).cardColor,
      height: kToolbarHeight,
      child: TabBar(
        key: const PageStorageKey<Type>(TabBar),
        labelColor: AppColor.orange,
        indicatorColor: AppColor.orange,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: subtitleStyle.copyWith(fontSize: 12.sp),
        unselectedLabelColor: Colors.grey,
        splashBorderRadius: BorderRadius.circular(50),
        isScrollable: true,
        tabs: const [
          SizedBox(
            width: 40,
            child: Tab(
              icon: Icon(
                Icons.home,
                size: 20,
              ),
              text: 'All',
            ),
          ),
          SizedBox(
            width: 40,
            child: Tab(
              icon: Icon(
                Icons.local_mall,
                size: 20,
              ),
              text: 'Mall',
            ),
          ),
          Tab(
            icon: Icon(
              Iconsax.shop5,
              size: 20,
            ),
            text: 'Fashion',
          ),
          Tab(
            icon: Icon(
              Icons.girl,
              size: 20,
            ),
            text: 'Beauty',
          ),
          Tab(
            icon: Icon(
              Icons.radar,
              size: 20,
            ),
            text: 'Asar ko Bahra',
          ),
          Tab(
            icon: Icon(
              Icons.scale_sharp,
              size: 20,
            ),
            text: 'Sales',
          ),
          Tab(
            icon: Icon(
              Icons.money,
              size: 20,
            ),
            text: 'dicounts',
          ),
          Tab(
            icon: Icon(
              Iconsax.sun,
              size: 20,
            ),
            text: 'Summer',
          ),
        ],
      ),
    );
  }

  @override
  bool shouldRebuild(covariant TestTabBarDelegate oldDelegate) {
    return oldDelegate.controller != controller;
  }
}*/

/*class TestHomePageBody extends StatefulWidget {
  const TestHomePageBody({super.key, this.scrollController});

  final ScrollController? scrollController;

  @override
  TestHomePageBodyState createState() => TestHomePageBodyState();
}*/

/*class TestHomePageBodyState extends State<TestHomePageBody> {
  Key _key = const PageStorageKey({});
  bool _innerListIsScrolled = false;
  final wishlistcontroller = Get.put(WishlistController());
  final cartController = Get.put(CartController());
  final logcon = Get.put(LoginController());

  void _updateScrollPosition() {
    log("${widget.scrollController!.position.extentAfter}");
    if (!_innerListIsScrolled &&
        widget.scrollController!.position.extentAfter == 0.0) {
      setState(() {
        _innerListIsScrolled = true;
      });
    } else if (_innerListIsScrolled &&
        widget.scrollController!.position.extentAfter > 0.0) {
      setState(() {
        _innerListIsScrolled = false;
        // Reset scroll positions of the TabBarView pages
        _key = const PageStorageKey({});
        controller.numberOfPostsPerRequest.value += 4;
        controller.fetchProducts();
      });
    }
  }

  @override
  void initState() {
    widget.scrollController?.addListener(_updateScrollPosition);
    super.initState();
  }

  @override
  void dispose() {
    widget.scrollController?.removeListener(_updateScrollPosition);
    super.dispose();
  }

  final controller = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    var wishListIdArray = wishlistcontroller.wishListIdArray;
    log("WishList Id Collection: $wishListIdArray");
    return Obx(
      () => TabBarView(
        key: _key,
        children: List<Widget>.generate(8, (int index) {
          return GridView.builder(
              itemCount: controller.productsList.length,
              addAutomaticKeepAlives: true,
              key: PageStorageKey<int>(index),

              // controller: scrollcontroller,
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
              gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCountAndFixedHeight(
                crossAxisCount: 2,
                crossAxisSpacing: 5,
                mainAxisSpacing: 5,
                height: 270.0,
              ),
              // SliverGridDelegateWithFixedCrossAxisCount(
              //   crossAxisCount: 2,
              //   childAspectRatio:
              //       Device.orientation == Orientation.portrait ? 1 / 1.7 : 1.4,
              //   crossAxisSpacing: 10,
              //   mainAxisSpacing: 15,
              // ),
// This is tabs product  gridview
              itemBuilder: (context, index) {
                var data = controller.productsList[index];
                return Obx(
                  () => ProductCard(
                    price: data.getPrice!.price.toString(),
                    productImg:
                        '${data.images?[0].image?.replaceAll(RegExp(r'http://127.0.0.1:8000'), url)}',
                    productName: data.name,
                    rating: data.rating.toString(),
                    specialprice: data.getPrice?.specialPrice.toString(),
                    ontap: () {
                      Get.to(() => ProductDetailView(
                            productname: data.name,
                            productprice: data.id.toString(),
                            slug: data.slug,
                            productid: data.id,
                          ));
                    },
                    isFav: wishlistcontroller.wishListIdArray.contains(data.id)
                        ? true
                        : false,
                    ontapFavorite: () {
                      if (AppStorage.isloggedin != true) {
                        Get.to(() => LoginView());
                      } else {
                        if (logcon.logindata.value.read('USERID') != null) {
                          if (wishlistcontroller.wishListIdArray
                              .contains(data.id)) {
                            //toastMsg(message: "remove");
                            wishlistcontroller.removeFromWishList(data.id);
                            wishlistcontroller.fetchWishlist();
                          } else {
                            //toastMsg(message: "add");
                            wishlistcontroller.addToWishList(data.id);
                            wishlistcontroller.fetchWishlist();
                          }
                        } else {
                          toastMsg(message: "Please Login to add to wishlist");
                        }
                      }
                    },
                    ontapCart: () {
                      if (AppStorage.isloggedin != true) {
                        Get.to(() => LoginView());
                      } else {
                        cartController.addToCart(
                          data.id,
                          data.getPrice?.price,
                          '1',
                          '1',
                        );
                      }
                    },
                  ),
                );
              });
        }),
      ),
    );
  }
}*/
